# Nextor Cord — Full Restore + Desktop + 10s Startup

This package is based on the original `NextorCord-Enhanced-Controls.zip` project.
It deliberately keeps the original full `nextor-engine.js`, Android manifest,
Gradle configuration, microphone keep-alive service, resources, and native
control-sheet implementation.

## What was merged
- Original enhanced WebAudio engine and its full in-page control panel.
- Desktop Discord WebView setup from the later desktop update.
- 10-second local startup animation (`startup.html`) with 0–100% progress.
- Uploaded red Nextor Cord artwork replacing the floating N button.
- Limiter ceiling slider now controls the DSP limiter threshold.
- The two later uploaded small HTML/JS files are retained as `legacy-*` files
  for reference; they do NOT replace the original full DSP engine.

## Features implemented in the original enhanced engine
- Microphone capture interception (best-effort WebView `getUserMedia`).
- Mic gain, power boost, output gain.
- Noise gate and 80 Hz high-pass filter.
- 10-band peaking EQ.
- Compressor and final dynamics limiter.
- Drive / waveshaper saturation.
- Echo delay, time and feedback.
- Input/output/clip meters and six built-in presets.
- Panic reset, bypass, and JSON preset export.
- Floating logo opens the full Nextor control panel.

## Important limitations (not advertised as working)
The original prototype does NOT implement real pitch/formant shifting,
robot/alien voice morph, spectral noise subtraction, de-hum/de-hiss,
convolution reverb, true LUFS/true-peak metering, or guaranteed Discord
WebRTC interception. Some voice/effect buttons in the UI are presets or
placeholders. Discord/WebView changes can bypass microphone interception.
The engine falls back to the raw mic stream if DSP initialization fails.
Start with low gain and test in a private voice channel.

## Build
Open the `NextorCord` folder in Android Studio with JDK 17 and Android SDK 35,
then build `app:assembleDebug`. The GitHub workflow can also build the project
if its project path points to this `NextorCord` directory.
