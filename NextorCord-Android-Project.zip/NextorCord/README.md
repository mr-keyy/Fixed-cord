# Nextor Cord — Full Restore + Desktop + 10s Startup

This package is based on the original `NextorCord-Enhanced-Controls.zip` project.
It deliberately keeps the original full `nextor-engine.js`, Android manifest,
Gradle configuration, microphone keep-alive service, resources, and native
control-sheet implementation.

## What was merged
- Original enhanced WebAudio engine and its full in-page control panel.
- Desktop Discord WebView setup from the later desktop update.
- 10-second local startup animation (`startup.html`) with 0–100% progress.
- Uploaded red Nextor Cord artwork replacing the floating N button.
- Limiter ceiling slider now controls the DSP limiter threshold.
- The two later uploaded small HTML/JS files are retained as `legacy-*` files
  for reference; they do NOT replace the original full DSP engine.

## Features implemented in the original enhanced engine
- Microphone capture interception (best-effort WebView `getUserMedia`).
- Mic gain, power boost, output gain.
- Noise gate and 80 Hz high-pass filter.
- 10-band peaking EQ.
- Compressor and final dynamics limiter.
- Drive / waveshaper saturation.
- Echo delay, time and feedback.
- Input/output/clip meters and six built-in presets.
- Panic reset, bypass, and JSON preset export.
- Floating logo opens the full Nextor control panel.

## Important limitations (not advertised as working)
The original prototype does NOT implement real pitch/formant shifting,
robot/alien voice morph, spectral noise subtraction, de-hum/de-hiss,
convolution reverb, true LUFS/true-peak metering, or guaranteed Discord
WebRTC interception. Some voice/effect buttons in the UI are presets or
placeholders. Discord/WebView changes can bypass microphone interception.
The engine falls back to the raw mic stream if DSP initialization fails.
Start with low gain and test in a private voice channel.

## Build
Open the `NextorCord` folder in Android Studio with JDK 17 and Android SDK 35,
then build `app:assembleDebug`. The GitHub workflow can also build the project
if its project path points to this `NextorCord` directory.


## BLOOD.XD integration update
- The supplied red Nextor Cord HTML is now the floating-button control panel (inside a WebView iframe).
- The supplied BLOOD.XD audio hook is bundled in `bloodxd-engine.js` and loaded by `nextor-engine.js`; its competing extension panel/FAB is disabled.
- X24, GOD MODE, talking sets, gain, rage, EQ, reverb, delay, chorus, distortion, gate, high-pass and vocal-clarity controls are bridged where the source engine exposes processing for them.
- The `tony` talking-set key and +25 dB DSP setting are preserved; its displayed label is now **EXTREME LOUD TALKING**.
- Repair controls that the supplied source does not implement (spectral de-noise, de-esser, de-hum, click removal) are not represented as working effects; the panel exposes only gate, high-pass and vocal clarity.
- This is a source integration package, not a device-tested APK. WebView microphone permission, Discord's WebRTC routing, and the extension hook's track replacement still require a real-device voice-channel test.


## BLOOD.XD audio integration / right-side Nextor panel
- The Nextor Cord HTML control panel is mounted as a right-side slide-in drawer from the floating Nextor logo launcher.
- The extension's supplied `suppresor_hook_by_tony_and_veil.js` is adapted as `bloodxd-engine.js`; its duplicate BLOOD.XD panel and T launcher are suppressed.
- `window.NextorBloodXD` bridges the Nextor UI to the extension DSP graph: mic gain, power/rage level, X24 toggle, talking sets, voice profiles, 15-band EQ, reverb, delay, chorus, flanger, distortion, saturation, bitcrush, gate, clarity, high-pass, limiter and live RMS meter.
- The TONY talking-set label is changed to **EXTREME LOUD TALKING**; its source +25 dB setting remains, with the runtime preamp and output chain bounded and a final limiter retained.
- Discord/WebView may change its WebRTC capture flow; the engine can only process streams it successfully intercepts. Actual voice-channel verification is still required.
- This package is source code, not a prebuilt or device-tested APK. Build with the included GitHub Actions workflow and test the voice channel at a low listening volume.
