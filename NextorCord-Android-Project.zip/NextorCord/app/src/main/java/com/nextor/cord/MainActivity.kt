package com.nextor.cord

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.content.ActivityNotFoundException
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var preampDb = 24
    private var engineReady = false
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val desktopUrl = "https://discord.com/app"
    private val startupDurationMs = 10_000L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var startupTransitionScheduled = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestRuntimePermissions()

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 9, 12))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = false
                allowFileAccess = true
                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            addJavascriptInterface(NextorBridge(), "NextorNative")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val audio = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray()
                        if (audio.isNotEmpty() && hasAudioPermission()) request.grant(audio) else request.deny()
                    }
                }
                override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = callback
                    return try {
                        val intent = params?.createIntent() ?: return false
                        startActivityForResult(intent, 72)
                        true
                    } catch (_: ActivityNotFoundException) {
                        uploadCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    val scheme = request.url.scheme?.lowercase() ?: return true
                    if (scheme in listOf("intent", "market", "discord")) return true
                    if (scheme != "https" && scheme != "http") return true
                    val host = request.url.host?.lowercase() ?: return true
                    val discordHost = host == "discord.com" || host.endsWith(".discord.com") || host == "discordapp.com" || host.endsWith(".discordapp.com")
                    if (!discordHost) return true
                    if (url.contains("/download", true) || url.contains("/mobile", true) || url.contains("/app-download", true)) {
                        view.post { view.loadUrl(desktopUrl) }
                        return true
                    }
                    return false
                }
                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    android.util.Log.e("NEXTOR", "WebView renderer exited; crashed=${detail.didCrash()}")
                    try {
                        (view.parent as? android.view.ViewGroup)?.removeView(view)
                        view.destroy()
                    } catch (_: Exception) { }
                    if (!isFinishing) {
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Discord page stopped. Restart Nextor Cord.", Toast.LENGTH_LONG).show()
                        }
                    }
                    return true
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    // Keep the local 10-second startup screen separate from Discord page setup.
                    if (url.startsWith("file:///android_asset/startup.html", ignoreCase = true)) {
                        if (!startupTransitionScheduled) {
                            startupTransitionScheduled = true
                            // Start the 10-second display timer only after the local animation page is loaded.
                            mainHandler.postDelayed({
                                if (!isFinishing && ::web.isInitialized) web.loadUrl(desktopUrl)
                            }, startupDurationMs)
                        }
                        return
                    }
                    if (url.contains("discord.com/download", true) || url.contains("get-the-app", true)) {
                        view.post { view.loadUrl(desktopUrl) }
                        return
                    }
                    if (url.startsWith("https://discord.com", ignoreCase = true) ||
                        url.startsWith("https://www.discord.com", ignoreCase = true)) {
                        forceDesktopViewport(view)
                        injectEngine()
                        CookieManager.getInstance().flush()
                    }
                }
            }
        }
        // Optional compatibility shim: never let a missing/broken asset crash app startup.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                val shim = assets.open("desktop-compat.js").bufferedReader().use { it.readText() }
                WebViewCompat.addDocumentStartJavaScript(
                    web,
                    shim,
                    setOf("https://discord.com", "https://*.discord.com")
                )
            } catch (e: Exception) {
                android.util.Log.e("NEXTOR", "desktop-compat.js unavailable; continuing without shim", e)
            }
        }
        setContentView(web)
        // Show the bundled startup animation first; its 10-second timer starts when the asset finishes loading.
        web.loadUrl("file:///android_asset/startup.html")
        startMicService()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                // The user chooses whether to exempt the app; no automatic settings mutation.
                Toast.makeText(this, "For longer background sessions, review battery optimization settings.", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 72) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        try {
            requestPermissions(permissions.toTypedArray(), 41)
        } catch (e: Exception) {
            android.util.Log.e("NEXTOR", "Could not request runtime permissions", e)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && hasAudioPermission()) startMicService()
    }

    private fun hasAudioPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startMicService() {
        if (!hasAudioPermission()) return
        try {
            val intent = Intent(this, MicKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            android.util.Log.w("NEXTOR", "Foreground microphone service could not start: ${e.message}")
        }
    }

    private fun forceDesktopViewport(view: WebView) {
        // Discord's desktop user-agent alone still sees a phone-sized CSS viewport.
        // Widen the viewport so Discord renders its full desktop multi-column layout.
        val script = """(function(){
            try {
              var m=document.querySelector('meta[name=viewport]');
              if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
              m.setAttribute('content','width=1280, initial-scale=0.50, minimum-scale=0.25, maximum-scale=2.0, user-scalable=yes');
              document.documentElement.style.minWidth='1280px';
              if(document.body) document.body.style.minWidth='1280px';
              window.dispatchEvent(new Event('resize'));
            } catch(e) { if(window.NextorNative) NextorNative.log('Desktop viewport adjustment: '+e); }
        })();"""
        view.evaluateJavascript(script, null)
        view.postDelayed({
            if (!isFinishing) view.evaluateJavascript(script, null)
        }, 700L)
    }

    private fun injectEngine() {
        try {
            val engine = assets.open("bloodxd-engine.js").bufferedReader().use { it.readText() }
            val html = assets.open("nextor-cord-app.html").bufferedReader().use { it.readText() }
            val logoBytes = assets.open("nextor-logo.png").use { it.readBytes() }
            val logoData = "data:image/png;base64," + android.util.Base64.encodeToString(logoBytes, android.util.Base64.NO_WRAP)
            val htmlLiteral = JSONObject.quote(html)
            val logoLiteral = JSONObject.quote(logoData)
            val overlay = """
                (function(){
                  if(window.__nextorCordDrawerMounted)return;
                  window.__nextorCordDrawerMounted=true;
                  var source=$htmlLiteral;
                  var logo=$logoLiteral;
                  var frame=document.createElement('iframe');
                  frame.id='nextor-cord-right-drawer';
                  frame.title='Nextor Cord audio controls';
                  frame.setAttribute('allow','microphone; autoplay');
                  frame.style.cssText='position:fixed;z-index:2147483000;top:0;right:0;width:min(430px,92vw);height:100dvh;height:100vh;border:0;border-left:1px solid rgba(255,45,55,.55);background:#050303;box-shadow:-18px 0 48px rgba(0,0,0,.7);transform:translateX(105%);transition:transform .28s ease;pointer-events:none;';
                  var open=false;
                  function setOpen(v){open=!!v;frame.style.transform=open?'translateX(0)':'translateX(105%)';frame.style.pointerEvents=open?'auto':'none';launcher.style.opacity=open?'0':'1';launcher.style.pointerEvents=open?'none':'auto';}
                  var launcher=document.createElement('button');launcher.id='nextor-cord-launcher';launcher.type='button';launcher.setAttribute('aria-label','Open Nextor Cord controls');
                  launcher.style.cssText='position:fixed;z-index:2147483001;right:14px;bottom:22%;width:58px;height:58px;padding:0;border:2px solid #ff3846;border-radius:50%;background:#100405;box-shadow:0 0 18px rgba(255,25,45,.75);overflow:hidden;display:grid;place-items:center;';
                  var img=document.createElement('img');img.src=logo;img.alt='Nextor';img.style.cssText='width:100%;height:100%;object-fit:cover;border-radius:50%;';launcher.appendChild(img);launcher.addEventListener('click',function(){setOpen(true)});
                  window.addEventListener('message',function(e){if(e.source===frame.contentWindow&&e.data&&e.data.type==='NEXTOR_CLOSE')setOpen(false)});
                  source=source.replace('</head>','<style>html,body{background:#050303!important}.app{max-width:none!important;width:100%!important;margin:0!important}.panel{max-height:calc(100vh - 300px);overflow:auto}</style></head>');
                  frame.srcdoc=source;
                  document.documentElement.appendChild(frame);document.documentElement.appendChild(launcher);
                  window.__nextorCordDrawer={open:function(){setOpen(true)},close:function(){setOpen(false)}};
                })();
            """.trimIndent()
            web.evaluateJavascript(engine, null)
            web.evaluateJavascript(overlay, null)
            engineReady = true
        } catch (e: Exception) {
            engineReady = false
            android.util.Log.e("NEXTOR", "BLOOD.XD engine or Nextor panel asset unavailable", e)
            runOnUiThread {
                Toast.makeText(this, "Nextor audio controls could not load: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class NextorBridge {
        @android.webkit.JavascriptInterface
        fun log(message: String) { android.util.Log.d("NEXTOR", message.take(1500)) }
        @android.webkit.JavascriptInterface
        fun openControls() { runOnUiThread { showControls() } }
        @android.webkit.JavascriptInterface
        fun setPreamp(value: Int) { preampDb = value.coerceIn(0, 72) }
    }

    private fun showControls() {
        val dialog = Dialog(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(18, 18, 18))
        }
        val heading = TextView(this).apply {
            text = "NEXTOR CONTROL DECK"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
        }
        layout.addView(heading)
        val valueText = TextView(this).apply {
            text = "PREAMP  $preampDb dB"
            textSize = 15f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 18, 0, 8)
        }
        layout.addView(valueText)
        val slider = SeekBar(this).apply {
            max = 72
            progress = preampDb
        }
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    preampDb = progress
                    valueText.text = "PREAMP  $preampDb dB"
                    web.evaluateJavascript("window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        layout.addView(slider)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun action(label: String, js: String) {
            val b = Button(this).apply { text = label; setOnClickListener { web.evaluateJavascript(js, null) } }
            row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        action("PANIC", "window.NextorEngine && window.NextorEngine.panic()")
        action("BYPASS", "window.NextorEngine && window.NextorEngine.setConfig({bypass:true})")
        action("LIVE", "window.NextorEngine && window.NextorEngine.setConfig({bypass:false})")
        layout.addView(row)
        val note = TextView(this).apply {
            text = "Audio processing starts when Discord requests microphone access. Keep this app foregrounded for reliable voice sessions."
            setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; setPadding(0, 14, 0, 0)
        }
        layout.addView(note)
        dialog.setContentView(layout)
        dialog.show()
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.window?.setGravity(Gravity.BOTTOM)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) {
            web.goBack()
        } else {
            android.app.AlertDialog.Builder(this)
                .setTitle("Exit Nextor Cord?")
                .setMessage("Your Discord voice session will close.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Exit") { _, _ -> finish() }
                .show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            preampDb = (preampDb + if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 2 else -2).coerceIn(0, 72)
            if (::web.isInitialized) web.evaluateJavascript(
                "window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null
            )
            Toast.makeText(this, "Nextor preamp: $preampDb dB", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onPause() {
        if (::web.isInitialized) web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            try {
                web.stopLoading()
                web.loadUrl("about:blank")
                web.removeJavascriptInterface("NextorNative")
                web.webChromeClient = null
                web.webViewClient = WebViewClient()
                web.destroy()
            } catch (e: Exception) {
                android.util.Log.w("NEXTOR", "WebView cleanup failed", e)
            }
        }
        super.onDestroy()
    }
}
