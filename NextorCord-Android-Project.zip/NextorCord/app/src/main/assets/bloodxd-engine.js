// ████████████████████████████████████████████████████████████████████████
  // BLOOD.XD v4.6.0 — CLEAN ROOM / VOICE FX AUDIO HOOK — created by Stam God Tony
// Features: X24 Module · God Mode · 15-Band EQ · MP3 Player
//           Voice Changer · Rage Engine · 10 Themes · Full Effects
// ████████████████████████████████████████████████████████████████████████
(function () {
  'use strict';
  if (window.__suppressorLoaded) return;
  window.__suppressorLoaded = true;

  // ══════════════════════════════════════════════
  //  STATE
  // ══════════════════════════════════════════════
  var S = {
    active:       false,
    gainDb:       12,        // clear starting level; raise it only when needed
    outputTrimDb: -6,        // leave headroom for loud talking sets and effects
    x16Active:    false,     // internal flag; UI exposes the 24× module
    godMode:      false,     // GOD MODE — absolute max
    rageLevel:    0,
    compThreshold: -18, compRatio: 4, limiterCeiling: -6,
    talkingSet:   'normal',
    voiceMode:    'normal',
    pitchShift:   0,
    bassBoost:    false,
    bassBoss:     false,
    eqGains:      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    eqPreset:     'Flat',
    // Reverb is audible out of the box; the old default was literally 0%.
    reverb:       0.24, reverbSize: 4.8, reverbDamping: 0.65, reverbPreDelay: 0.035,
    delay:        0, delayTime:  0.25,
    chorusAmount: 0, chorusRate: 1.5,
    flangerAmount:0, flangerRate: 0.5,
    distortion:   0, saturation: 0,
    bitcrush:     0,
    vocalClarity: true, clarityGain: 8, clarityMix: 0.35,
    highpass:     true,
    noiseGate:    false,     // GG GATE is manual; ambience stays open by default
    gateThreshold:0.022,
    // A closed GG GATE must remove the room signal, not leave an audible bed.
    gateFloor:    0.0001,
    gateAttack:   0.012,
    gateRelease:  0.32,
    spatial:      'center',
    haaswider:    false, haasAmount: 1.0,
    widerAmount:  0,
    mp3Vol:       0.8,
    mp3Loop:      false,
    mp3Playing:   false,
    theme:        'dark',
    backgroundEffect: 'none',
  };
  var DEFAULT_STATE = JSON.parse(JSON.stringify(S));

  // Browser-compatible translation of the supplied waittt.txt chain:
  // GGate + rnnoise are represented by the manual GG GATE button, while the
  // CRTIV/ReverbSolo VST chunks are represented by this dense stereo room
  // profile. DLL/VST chunks cannot be loaded inside a Chrome extension.
  var PC_REVERB_PROFILE = {
    label: 'WAITTT / CRTIV ROOM',
    size: 4.8,
    damping: 0.65,
    preDelay: 0.035,
    wet: 0.30,
    earlyTaps: [0.027, 0.043, 0.068, 0.097, 0.137, 0.181, 0.233, 0.301],
  };

  // ── Talking Sets ──
  var TALKING_SETS = {
    normal:    { preamp: 1.0,               label: 'NORMAL',    sub: 'clean' },
    talk:      { preamp: dbToLinear(5),     label: 'TALK',      sub: '+5 dB' },
    loudTalk:  { preamp: dbToLinear(15),    label: 'LOUD TALK', sub: '+15 dB' },
    tony:      { preamp: dbToLinear(25),    label: 'EXTREME LOUD TALKING', sub: '+25 dB' },
  };

  // ── Rage Table: [gainMult, compThresh, compRatio, waveshapeK, label, color] ──
  var RAGE_TABLE = [
    [1,    -50, 1,   0,  'OFF',         '#444444'],
    [2,    -36, 3,   5,  'RAGE',        '#ff4400'],
    [5,    -28, 5,   18, 'RAGE V2',     '#ff0066'],
    [10,   -20, 7,   35, 'MEGA',        '#aa00ff'],
    [20,   -14, 10,  55, 'ULTRA',       '#0088ff'],
    [40,   -8,  14,  80, 'GOD RAGE',    '#ffee00'],
    [80,   -4,  18,  110,'10 MILLION',  '#ff2222'],
  ];
  var POSTGAIN = [1, 1.2, 1.5, 2.0, 2.8, 3.5, 5.0];

  // ── EQ ──
  var EQ_BANDS = [
    {freq:25,   type:'lowshelf' },
    {freq:40,   type:'peaking'  },
    {freq:63,   type:'peaking'  },
    {freq:100,  type:'peaking'  },
    {freq:160,  type:'peaking'  },
    {freq:250,  type:'peaking'  },
    {freq:400,  type:'peaking'  },
    {freq:630,  type:'peaking'  },
    {freq:1000, type:'peaking'  },
    {freq:1600, type:'peaking'  },
    {freq:2500, type:'peaking'  },
    {freq:4000, type:'peaking'  },
    {freq:6300, type:'peaking'  },
    {freq:10000,type:'peaking'  },
    {freq:16000,type:'highshelf'},
  ];
  var EQ_LABELS = ['25','40','63','100','160','250','400','630','1k','1.6k','2.5k','4k','6.3k','10k','16k'];
  var EQ_PRESETS = {
    'Flat':       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    'Bass Boost': [8,7,6,4,2,0,0,0,0,-1,-1,-1,-1,-2,-2],
    'Vocal':      [-2,-1,0,1,2,3,3,2,4,5,6,5,4,3,1],
    'Loud':       [5,4,3,2,2,2,2,2,3,3,4,4,3,2,2],
    'God Tier':   [10,9,8,7,5,4,4,4,5,6,7,8,7,6,5],
    'Crisp':      [-3,-2,0,0,0,1,2,3,4,5,6,7,8,8,7],
    'Radio':      [-5,-3,-1,2,4,5,5,4,3,2,-1,-2,-3,-4,-4],
    'Dark':       [6,6,5,4,3,2,1,0,-1,-1,0,1,1,0,0],
    'V-Shape':    [7,5,3,0,-2,-4,-4,-2,0,2,4,5,6,6,5],
    'Bass Boss':  [12,11,9,6,3,0,-1,-2,-2,-2,-1,0,0,-1,-2],
    'Megaphone':  [-8,-6,-4,0,4,6,6,5,4,2,0,-2,-4,-6,-8],
    'X24 Mode':   [8,8,7,6,5,5,5,5,6,6,7,8,7,6,5],
  };

  // ── Voice Profiles ──
  var VOICE_PROFILES = {
    normal: { bassGain:0,   highGain:0,   midFreq:1000, midGain:0,  modRate:0,   modDepth:0,    drive:0,  label:'NORMAL' },
    deep:   { bassGain:10,  highGain:-4,  midFreq:800,  midGain:5,  modRate:2,   modDepth:.12, drive:12, label:'DEEP'   },
    girl:   { bassGain:-5,  highGain:6,   midFreq:1300, midGain:-4, modRate:6,   modDepth:.16, drive:10, label:'GIRL'   },
    kid:    { bassGain:-7,  highGain:8,   midFreq:1500, midGain:-6, modRate:9,   modDepth:.22, drive:12, label:'KID'    },
    robot:  { bassGain:3,   highGain:5,   midFreq:900,  midGain:10, modRate:26,  modDepth:.58, drive:34, label:'ROBOT'  },
    demon:  { bassGain:12,  highGain:-6,  midFreq:700,  midGain:12, modRate:4,   modDepth:.28, drive:62, label:'DEMON'  },
    alien:  { bassGain:-3,  highGain:7,   midFreq:1100, midGain:6,  modRate:12,  modDepth:.38, drive:24, label:'ALIEN'  },
    giant:  { bassGain:14,  highGain:-8,  midFreq:600,  midGain:14, modRate:1.5, modDepth:.18, drive:22, label:'GIANT'  },
    ghost:  { bassGain:4,   highGain:4,   midFreq:2000, midGain:8,  modRate:3,   modDepth:.32, drive:16, label:'GHOST'  },
    titan:  { bassGain:16,  highGain:-10, midFreq:500,  midGain:16, modRate:1,   modDepth:.22, drive:30, label:'TITAN'  },
  };

  // ── Themes ──
  var THEMES = [
    {id:'dark',    label:'DARK',     bg:'#000000',  border:'rgba(255,255,255,0.22)', accent:'#ffffff', glow:'rgba(255,255,255,0.05)'},
    {id:'slate',   label:'SLATE',    bg:'#080e1a',  border:'rgba(80,140,255,0.45)',  accent:'#5a9eff', glow:'rgba(80,140,255,0.08)'},
    {id:'crimson', label:'CRIMSON',  bg:'#0d0004',  border:'rgba(220,30,60,0.5)',    accent:'#ff2244', glow:'rgba(220,30,60,0.08)'},
    {id:'matrix',  label:'MATRIX',   bg:'#000e00',  border:'rgba(0,255,65,0.45)',    accent:'#00ff41', glow:'rgba(0,255,65,0.06)'},
    {id:'purple',  label:'PURPLE',   bg:'#07000f',  border:'rgba(170,0,255,0.5)',    accent:'#bb22ff', glow:'rgba(170,0,255,0.08)'},
    {id:'gold',    label:'GOLD',     bg:'#0d0900',  border:'rgba(255,200,0,0.5)',    accent:'#ffd700', glow:'rgba(255,200,0,0.07)'},
    {id:'ice',     label:'ICE',      bg:'#000d12',  border:'rgba(0,220,255,0.45)',   accent:'#00ddff', glow:'rgba(0,220,255,0.07)'},
    {id:'toxic',   label:'TOXIC',    bg:'#040e00',  border:'rgba(130,255,0,0.45)',   accent:'#88ff00', glow:'rgba(130,255,0,0.06)'},
    {id:'sunset',  label:'SUNSET',   bg:'#0f0600',  border:'rgba(255,120,30,0.5)',   accent:'#ff7820', glow:'rgba(255,120,30,0.07)'},
    {id:'sakura',  label:'SAKURA',   bg:'#0f0009',  border:'rgba(255,100,180,0.5)',  accent:'#ff64b4', glow:'rgba(255,100,180,0.07)'},
    {id:'rainbow', label:'RAINBOW',  bg:'linear-gradient(135deg,#130018,#001827,#1a0810)', border:'rgba(255,255,255,0.5)', accent:'#ff75e6', glow:'rgba(255,80,220,0.14)'},
    {id:'fire',    label:'FIRE',     bg:'linear-gradient(135deg,#160300,#271000,#090203)', border:'rgba(255,95,25,0.58)', accent:'#ff9a3d', glow:'rgba(255,55,10,0.16)'},
    {id:'aurora',  label:'AURORA',   bg:'linear-gradient(135deg,#001a1c,#07112b,#16051f)', border:'rgba(87,255,221,0.48)', accent:'#57ffdd', glow:'rgba(50,240,205,0.13)'},
    {id:'blood',   label:'BLOOD',    bg:'linear-gradient(135deg,#210006,#3a000d,#090003)', border:'rgba(255,45,88,0.62)', accent:'#ff365f', glow:'rgba(255,25,70,0.18)'},
    {id:'plasma',  label:'PLASMA',   bg:'linear-gradient(135deg,#16002b,#26005d,#080018)', border:'rgba(224,85,255,0.58)', accent:'#e879ff', glow:'rgba(202,54,255,0.17)'},
    {id:'ultraviolet',label:'UV',     bg:'linear-gradient(135deg,#050014,#18005b,#001539)', border:'rgba(126,102,255,0.6)', accent:'#9c8cff', glow:'rgba(100,80,255,0.16)'},
    {id:'neon',    label:'NEON LIME', bg:'linear-gradient(135deg,#041500,#092b00,#001113)', border:'rgba(172,255,42,0.56)', accent:'#b8ff36', glow:'rgba(120,255,30,0.14)'},
    {id:'pearl',   label:'PEARL',    bg:'linear-gradient(135deg,#13222c,#25344a,#190e25)', border:'rgba(214,246,255,0.58)', accent:'#d9ffff', glow:'rgba(190,240,255,0.14)'},
  ];

  // ══════════════════════════════════════════════
  //  AUDIO NODES
  // ══════════════════════════════════════════════
  var audioCtx=null,
      preampNode=null, gainNode=null, postGainNode=null, x16GainNode=null,
      eqNodes=[],
      bassFilter=null, bassBossFilter=null, voiceFilter=null, voiceModNode=null,
      voiceModOsc=null, voiceModDepth=null, voiceShapeNode=null, highFilter=null,
      hpFilter=null, rumbleFilter=null, presenceFilter=null, airFilter=null,
      clarityDry=null, clarityWet=null, clarityFlt=null,
      gateGainNode=null, gateAnalyser=null, gateTimer=null,
      satNode=null, distNode=null, bitcrushNode=null,
      compressor=null, waveshaper=null, limiterNode=null,
      panNode=null, widthSplitter=null, widthMerger=null, haasL=null, haasR=null,
      reverbPreDelayNode=null, reverbNode=null, reverbDry=null, reverbGain=null,
      delayNode=null, delayGain=null,
      chorusDelay=null, chorusOsc=null, chorusOscGain=null, chorusMixNode=null,
      flangerDelay=null, flangerOsc=null, flangerOscGain=null, flangerMixNode=null,
      outputGain=null, analyserNode=null, mp3GainNode=null;

  var origStream=null, procStream=null, procTrack=null;
  var peerConns=[];
  var chainBuilt=false;

  // MP3
  var mp3AudioEl=null, mp3Src=null, mp3File=null, mp3ObjectUrl=null;
  var repeaterRecorder=null, repeaterChunks=[], repeaterAudioEl=null, repeaterUrl=null, repeaterSrc=null;
  var reverbIrSize=0, reverbIrDamping=-1;
  var gateEnvelope=0, gateOpen=false, gateHoldUntil=0;

  // ══════════════════════════════════════════════
  //  UTILS
  // ══════════════════════════════════════════════
  function dbToLinear(db){return Math.pow(10, db/20);}
  function clamp(v,lo,hi){return Math.max(lo,Math.min(hi,isFinite(v)?v:lo));}
  function accentRgb(hex){
    var h=String(hex||'').replace('#','');
    if(h.length===3)h=h.split('').map(function(c){return c+c;}).join('');
    if(!/^[0-9a-f]{6}$/i.test(h))return '87,255,221';
    return parseInt(h.slice(0,2),16)+','+parseInt(h.slice(2,4),16)+','+parseInt(h.slice(4,6),16);
  }
  function makeCurve(k){
    var n=2048,c=new Float32Array(n);
    for(var i=0;i<n;i++){var x=(i*2)/n-1;c[i]=k===0?x:((Math.PI+k)*x)/(Math.PI+k*Math.abs(x));}
    return c;
  }
  function makeVoiceCurve(drive){
    var n=2048,c=new Float32Array(n),amount=Math.max(0,drive||0),g=1+amount*0.08;
    var norm=Math.tanh(g)||1;
    for(var i=0;i<n;i++){
      var x=(i*2)/n-1;
      var shaped=Math.tanh(x*g)/norm;
      c[i]=x*0.16+shaped*0.84;
    }
    return c;
  }
  function makeLimCurve(threshold){
    var n=1024,c=new Float32Array(n),th=threshold||0.85;
    for(var i=0;i<n;i++){var x=(i*2)/n-1;var ax=Math.abs(x);c[i]=ax<=th?x:(x/ax)*(th+(ax-th)/(1+(((ax-th)/(1-th))*((ax-th)/(1-th)))));}
    return c;
  }
  function makeSatCurve(k){
    var n=2048,c=new Float32Array(n),m=Math.max(0,k);
    for(var i=0;i<n;i++){var x=(i*2)/n-1;c[i]=m===0?x:Math.tanh((1+m*3)*x);}
    return c;
  }
  function makeBitcrushCurve(bits){
    var n=2048,c=new Float32Array(n);
    var steps=bits<=0?0:Math.pow(2,Math.floor(bits*8));
    for(var i=0;i<n;i++){var x=(i*2)/n-1;c[i]=steps>0?Math.round(x*steps)/steps:x;}
    return c;
  }
  function buildReverbIR(ctx,size,damp){
    var sr=ctx.sampleRate;
    var roomSize=clamp(size||PC_REVERB_PROFILE.size,0.1,14);
    var damping=clamp(damp==null?PC_REVERB_PROFILE.damping:damp,0,1);
    var len=Math.floor(sr*roomSize);
    var buf=ctx.createBuffer(2,len,sr);
    for(var ch=0;ch<2;ch++){
      var d=buf.getChannelData(ch);
      var seed=0x13579bdf+(ch*0x2468);
      var low=0, lower=0;
      // A strong direct reflection plus a stereo-spread early field makes
      // short rooms audible. The previous IR put most of its energy into a
      // tail that was too quiet to survive Discord's voice path.
      for(var ti=0;ti<PC_REVERB_PROFILE.earlyTaps.length;ti++){
        var tap=Math.floor(sr*PC_REVERB_PROFILE.earlyTaps[ti]);
        var stereo=(ch===0?1:(0.86+ti*0.018));
        var amp=(0.34-ti*0.027)*stereo;
        var spread=Math.max(1,Math.floor(sr*0.00018));
        for(var ei=-spread;ei<=spread;ei++){
          var ep=tap+ei;
          if(ep>=0&&ep<len)d[ep]+=(amp/(spread+1))*(1-Math.abs(ei)/(spread+1));
        }
      }
      // Longer filtered diffusion tail. Damping now behaves correctly:
      // more damping shortens the bright tail instead of making it longer.
      var tailSeconds=clamp(0.45+roomSize*0.18+(1-damping)*0.75,0.65,4.8);
      for(var i=0;i<len;i++){
        seed=(seed*1664525+1013904223)>>>0;
        var random=(seed/4294967296)*2-1;
        low=low*0.965+random*0.035;
        lower=lower*0.992+low*0.008;
        var decay=Math.exp(-i/(sr*tailSeconds));
        // Two diffusion rates avoid a metallic single-pole tail while
        // keeping the room smooth instead of producing white-noise hiss.
        var air=Math.pow(1-damping,0.65);
        d[i]+=(low*0.14+lower*0.10)*decay*(0.45+air*0.55);
      }
    }
    return buf;
  }
  function speechGateMode(){
    // GG GATE is deliberately manual. X24, GOD and Rage never change it.
    return !!S.noiseGate;
  }
  function killAGC(c){
    if(!c||!c.audio)return c;
    var a=(c.audio===true)?{}:JSON.parse(JSON.stringify(c.audio));
    a.autoGainControl=false;a.googAutoGainControl=false;a.googAutoGainControl2=false;
    // Browser cleanup follows the manual GG GATE switch. The Web Audio gate
    // below remains the authoritative live on/off control.
    var speechOnly=speechGateMode();
    a.noiseSuppression=speechOnly;a.googNoiseSuppression=speechOnly;
    a.echoCancellation=speechOnly;a.googEchoCancellation=speechOnly;
    a.googHighpassFilter=true;a.autoGainControl=false;
    a.channelCount=1;a.sampleRate=48000;
    return Object.assign({},c,{audio:a});
  }
  function applyCaptureNoiseControl(){
    if(!origStream||!origStream.getAudioTracks)return;
    var track=origStream.getAudioTracks()[0];
    if(!track||!track.applyConstraints)return;
    // Keep the browser's own cleanup aligned with the manual GG GATE switch.
    // The Web Audio gate remains authoritative, so unsupported constraints
    // cannot break the live chain.
    track.applyConstraints({
      autoGainControl:false,
      noiseSuppression:speechGateMode(),
      echoCancellation:speechGateMode()
    }).catch(function(){});
  }

  // ══════════════════════════════════════════════
  //  LIVE-UPDATE HELPERS (no rebuild needed)
  // ══════════════════════════════════════════════
  function computeGainValue(){
    var rl=clamp(S.rageLevel,0,RAGE_TABLE.length-1);
    var rageMult=RAGE_TABLE[rl][0];
    var ts=TALKING_SETS[S.talkingSet]||TALKING_SETS.normal;
    if(S.godMode) return Math.min(8, dbToLinear(12));
    return Math.min(8, dbToLinear(clamp(S.gainDb, -20, 12)) * rageMult);
  }
  function applyGain(){
    if(!chainBuilt)return;
    var rl=clamp(S.rageLevel,0,RAGE_TABLE.length-1);
    var ts=TALKING_SETS[S.talkingSet]||TALKING_SETS.normal;
    if(preampNode)   preampNode.gain.value   = S.godMode?4:Math.min(4, ts.preamp);
    if(gainNode)     gainNode.gain.value     = computeGainValue();
    if(postGainNode) postGainNode.gain.value = S.godMode?1.5:Math.min(2, POSTGAIN[Math.min(rl,POSTGAIN.length-1)]);
    if(x16GainNode)  x16GainNode.gain.value  = S.x16Active?(S.godMode?4:4):1;
  }
  function applyOutput(){
    if(!chainBuilt||!outputGain)return;
    outputGain.gain.value=dbToLinear(clamp(S.outputTrimDb,-18,0));
  }
  function applyRage(){
    if(!chainBuilt)return;
    var rl=clamp(S.rageLevel,0,RAGE_TABLE.length-1);
    if(compressor){
      compressor.threshold.value = S.godMode?0:clamp(S.compThreshold,-40,-6);
      compressor.ratio.value     = S.godMode?20:clamp(S.compRatio,1,12);
    }
    if(waveshaper) waveshaper.curve=makeCurve(S.godMode?200:RAGE_TABLE[rl][3]);
    applyGain();
  }
  function applyEQ(){
    if(!chainBuilt)return;
    eqNodes.forEach(function(n,i){if(n)n.gain.value=S.eqGains[i]||0;});
  }
  function applyVoice(){
    if(!chainBuilt)return;
    var vp=VOICE_PROFILES[S.voiceMode]||VOICE_PROFILES.normal;
    if(bassFilter){bassFilter.gain.value=(vp.bassGain||0)+(S.bassBoost?8:0)+(S.bassBoss?16:0);}
    if(highFilter){highFilter.gain.value=vp.highGain||0;}
    if(voiceFilter){
      voiceFilter.frequency.value=clamp((vp.midFreq||1000)+(S.pitchShift||0)*55,300,4200);
      voiceFilter.gain.value=vp.midGain||0;
    }
    if(voiceModOsc){
      voiceModOsc.frequency.value=clamp((vp.modRate||0)+(S.pitchShift||0)*1.2,0.5,50);
    }
    if(voiceModDepth){
      voiceModDepth.gain.value=clamp((vp.modDepth||0)*(S.voiceMode==='normal'?0:1),0,0.62);
    }
    if(voiceShapeNode){
      voiceShapeNode.curve=makeVoiceCurve(clamp((vp.drive||0)+Math.abs(S.pitchShift||0)*1.5,0,80));
    }
    if(bassBossFilter){bassBossFilter.gain.value=S.bassBoss?12:0;}
  }
  function applySpatial(){
    if(!chainBuilt)return;
    if(panNode){panNode.pan.value=S.spatial==='right'?1:S.spatial==='left'?-1:0;}
    if(haasL&&haasR){
      haasL.delayTime.value=0;
      var width=S.widerAmount>0?S.widerAmount/100:S.haasAmount;
      haasR.delayTime.value=S.spatial==='behind'?0.045:(S.haaswider?clamp(width,0.1,5)*0.018:0);
    }
  }
  function applyReverb(){
    if(!chainBuilt)return;
    if(reverbGain)reverbGain.gain.value=clamp(S.reverb,0,1);
    if(reverbPreDelayNode)reverbPreDelayNode.delayTime.value=S.reverbPreDelay;
    if(reverbNode&&audioCtx&&(reverbIrSize!==S.reverbSize||reverbIrDamping!==S.reverbDamping)){
      reverbNode.buffer=buildReverbIR(audioCtx,S.reverbSize,S.reverbDamping);
      reverbIrSize=S.reverbSize;
      reverbIrDamping=S.reverbDamping;
    }
  }
  function applyDelay(){
    if(!chainBuilt)return;
    if(delayNode)delayNode.delayTime.value=clamp(S.delayTime,0,2);
    if(delayGain)delayGain.gain.value=clamp(S.delay,0,1);
  }
  function applyChorus(){
    if(!chainBuilt)return;
    if(chorusMixNode)chorusMixNode.gain.value=clamp(S.chorusAmount,0,1);
    if(chorusOsc)chorusOsc.frequency.value=S.chorusRate;
  }
  function applyFlanger(){
    if(!chainBuilt)return;
    if(flangerMixNode)flangerMixNode.gain.value=clamp(S.flangerAmount,0,1);
    if(flangerOsc)flangerOsc.frequency.value=S.flangerRate;
  }
  function applyDistortion(){
    if(!chainBuilt)return;
    if(distNode)distNode.curve=makeCurve(S.distortion*120);
    if(satNode) satNode.curve=makeSatCurve(S.saturation);
    if(bitcrushNode)bitcrushNode.curve=makeBitcrushCurve(S.bitcrush);
  }
  function applyHighpass(){
    if(!chainBuilt)return;
    if(rumbleFilter)rumbleFilter.frequency.value=S.highpass?55:20;
    if(hpFilter)    hpFilter.frequency.value    =S.highpass?100:20;
  }
  function applyClarity(){
    if(!chainBuilt)return;
    if(clarityFlt)clarityFlt.gain.value=S.vocalClarity?S.clarityGain:0;
    if(clarityWet)clarityWet.gain.value=S.vocalClarity?clamp(S.clarityMix,0,1):0;
    if(clarityDry)clarityDry.gain.value=1-clamp(S.clarityMix,0,1);
  }
  function applyNoiseGate(){
    if(!gateGainNode||!audioCtx)return;
    if(!speechGateMode()){
      gateOpen=false;gateEnvelope=0;gateHoldUntil=0;
      gateGainNode.gain.cancelScheduledValues(audioCtx.currentTime);
      gateGainNode.gain.setTargetAtTime(1,audioCtx.currentTime,0.02);
      var openState=D.getElementById('sup-gate-state');
      if(openState){
        openState.textContent='GG GATE OFF — AMBIENCE OPEN';
        openState.className='sup-gate-state open';
      }
      return;
    }
    // The timer below owns the envelope while the gate is enabled. This
    // immediate target prevents a just-activated mic from staying muted.
    gateOpen=true;gateHoldUntil=Date.now()+120;
    gateGainNode.gain.cancelScheduledValues(audioCtx.currentTime);
    gateGainNode.gain.setTargetAtTime(1,audioCtx.currentTime,Math.max(0.005,S.gateAttack/2));
  }
  function updateNoiseGate(){
    if(!gateAnalyser||!gateGainNode||!audioCtx||!chainBuilt)return;
    if(!speechGateMode()){
      gateGainNode.gain.cancelScheduledValues(audioCtx.currentTime);
      gateGainNode.gain.setTargetAtTime(1,audioCtx.currentTime,0.02);
      var ambienceState=D.getElementById('sup-gate-state');
      if(ambienceState){
        ambienceState.textContent='GG GATE OFF — AMBIENCE OPEN';
        ambienceState.className='sup-gate-state open';
      }
      return;
    }
    var sum=0,i,sample;
    if(typeof gateAnalyser.getFloatTimeDomainData==='function'){
      var floatBuf=new Float32Array(gateAnalyser.fftSize);
      gateAnalyser.getFloatTimeDomainData(floatBuf);
      for(i=0;i<floatBuf.length;i++){sample=floatBuf[i];sum+=sample*sample;}
      sum=Math.sqrt(sum/floatBuf.length);
    }else{
      var byteBuf=new Uint8Array(gateAnalyser.fftSize);
      gateAnalyser.getByteTimeDomainData(byteBuf);
      for(i=0;i<byteBuf.length;i++){sample=(byteBuf[i]-128)/128;sum+=sample*sample;}
      sum=Math.sqrt(sum/byteBuf.length);
    }
    // Smooth the detector, then use separate open/close thresholds. This
    // prevents the gate from chattering on consonants and room hiss.
    gateEnvelope=Math.max(sum,gateEnvelope*0.78);
    var threshold=clamp(S.gateThreshold,0.002,0.2);
    var closeThreshold=threshold*0.55;
    var now=Date.now();
    var shouldOpen=gateEnvelope>=threshold;
    var shouldClose=gateEnvelope<closeThreshold&&now>=gateHoldUntil;
    if(shouldOpen){
      gateOpen=true;
      gateHoldUntil=now+140;
    }else if(shouldClose){
      gateOpen=false;
    }
    var target=gateOpen?1:clamp(S.gateFloor,0,0.01);
    var time=gateOpen?clamp(S.gateAttack,0.005,0.2):clamp(S.gateRelease,0.08,1);
    gateGainNode.gain.cancelScheduledValues(audioCtx.currentTime);
    gateGainNode.gain.setTargetAtTime(target,audioCtx.currentTime,
      Math.max(0.006,gateOpen?time/3:time/5));
    var gateState=D.getElementById('sup-gate-state');
    if(gateState){
      gateState.textContent=gateOpen?'OPEN — VOICE PASSING':'CLOSED — ROOM NOISE HELD';
      gateState.className='sup-gate-state '+(gateOpen?'open':'closed');
    }
  }
  function startNoiseGate(){
    stopNoiseGate();
    if(speechGateMode())gateTimer=setInterval(updateNoiseGate,24);
  }
  function stopNoiseGate(){
    if(gateTimer){clearInterval(gateTimer);gateTimer=null;}
  }

  function recorderMimeType(){
    if(!window.MediaRecorder||!MediaRecorder.isTypeSupported)return '';
    var types=['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus','audio/mp4'];
    for(var i=0;i<types.length;i++){if(MediaRecorder.isTypeSupported(types[i]))return types[i];}
    return '';
  }
  function replaceMp3Element(){
    if(!mp3File||!mp3ObjectUrl)return null;
    if(mp3AudioEl){
      try{mp3AudioEl.pause();mp3AudioEl.removeAttribute('src');mp3AudioEl.load();}catch(_){}
    }
    mp3AudioEl=D.createElement('audio');
    mp3AudioEl.preload='auto';
    mp3AudioEl.crossOrigin='anonymous';
    mp3AudioEl.loop=!!S.mp3Loop;
    mp3AudioEl.src=mp3ObjectUrl;
    mp3Src=null;
    return mp3AudioEl;
  }
  function routeMp3(){
    if(!mp3AudioEl||!audioCtx||!mp3GainNode)return;
    try{
      if(!mp3Src){
        mp3Src=audioCtx.createMediaElementSource(mp3AudioEl);
        mp3Src.connect(mp3GainNode);
      }
    }catch(e){console.warn('[BLOOD.XD] MP3 routing error',e);}
  }
  function routeRepeater(){
    if(!repeaterAudioEl||!audioCtx||!mp3GainNode)return;
    try{
      if(!repeaterSrc){
        repeaterSrc=audioCtx.createMediaElementSource(repeaterAudioEl);
        repeaterSrc.connect(mp3GainNode);
      }
    }catch(e){console.warn('[BLOOD.XD] repeater routing error',e);}
  }
  function startRepeaterRecording(onStatus){
    if(repeaterRecorder&&repeaterRecorder.state==='recording')return;
    var stream=procStream||origStream;
    if(!stream||!window.MediaRecorder){
      if(onStatus)onStatus('WAITING FOR DISCORD MIC','#ffaa00');
      return;
    }
    repeaterChunks=[];
    try{
      var mime=recorderMimeType();
      repeaterRecorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);
      repeaterRecorder.ondataavailable=function(e){if(e.data&&e.data.size)repeaterChunks.push(e.data);};
      repeaterRecorder.onstop=function(){
        if(!repeaterChunks.length)return;
        if(repeaterUrl)URL.revokeObjectURL(repeaterUrl);
        var type=(repeaterRecorder&&repeaterRecorder.mimeType)||mime||'audio/webm';
        repeaterUrl=URL.createObjectURL(new Blob(repeaterChunks,{type:type}));
        if(!repeaterAudioEl){
          repeaterAudioEl=D.createElement('audio');
          repeaterAudioEl.crossOrigin='anonymous';
          repeaterAudioEl.loop=true;
        }
        repeaterAudioEl.src=repeaterUrl;
        if(chainBuilt)routeRepeater();
        if(onStatus)onStatus('REPEATER CLIP READY — PRESS LOOP PLAY','#57ffdd');
      };
      repeaterRecorder.onerror=function(){if(onStatus)onStatus('REPEATER RECORDING ERROR','#ff5555');};
      repeaterRecorder.start(100);
      if(onStatus)onStatus('RECORDING REPEATER CLIP…','#ffb15c');
    }catch(_){
      if(onStatus)onStatus('RECORDER NOT AVAILABLE IN THIS BROWSER','#ff5555');
    }
  }
  function stopRepeaterRecording(onStatus){
    if(repeaterRecorder&&repeaterRecorder.state==='recording'){
      repeaterRecorder.stop();
      if(onStatus)onStatus('PROCESSING REPEATER CLIP…','#ffb15c');
    }else if(onStatus)onStatus('NOT RECORDING','#ffaa00');
  }
  function playRepeater(onStatus){
    if(!repeaterAudioEl||!repeaterAudioEl.src){
      if(onStatus)onStatus('RECORD A REPEATER CLIP FIRST','#ffaa00');
      return;
    }
    repeaterAudioEl.loop=true;
    repeaterAudioEl.play().then(function(){
      if(onStatus)onStatus('REPEATER LOOP ACTIVE','#57ffdd');
    }).catch(function(){if(onStatus)onStatus('CLICK AGAIN TO START REPEATER','#ffaa00');});
  }
  function stopRepeater(onStatus){
    if(repeaterAudioEl){repeaterAudioEl.pause();repeaterAudioEl.currentTime=0;}
    if(onStatus)onStatus('REPEATER STOPPED','#ffaa00');
  }

  // ══════════════════════════════════════════════
  //  BUILD AUDIO CHAIN
  // ══════════════════════════════════════════════
  function buildChain(stream){
    if(!stream||!stream.getAudioTracks().length){setStatus('NO MIC STREAM','#ff4444');return null;}
    try{
      if(audioCtx&&audioCtx.state!=='closed'){try{audioCtx.close();}catch(_){}}
      chainBuilt=false;
      mp3Src=null;
      repeaterSrc=null;
      audioCtx=new(window.AudioContext||window.webkitAudioContext)({latencyHint:'balanced'});
      audioCtx.onstatechange=function(){
        if(S.active&&audioCtx&&audioCtx.state==='suspended'){
          audioCtx.resume().catch(function(){});
        }
      };
      audioCtx.resume().catch(function(){});
      var src=audioCtx.createMediaStreamSource(stream);
      var rl=clamp(S.rageLevel,0,RAGE_TABLE.length-1);
      var ts=TALKING_SETS[S.talkingSet]||TALKING_SETS.normal;

      // ── Create all nodes ──
      preampNode     =audioCtx.createGain();preampNode.gain.value=ts.preamp;
      rumbleFilter   =audioCtx.createBiquadFilter();rumbleFilter.type='highpass';rumbleFilter.frequency.value=S.highpass?55:20;
      hpFilter       =audioCtx.createBiquadFilter();hpFilter.type='highpass';hpFilter.frequency.value=S.highpass?100:20;
      bassFilter     =audioCtx.createBiquadFilter();bassFilter.type='lowshelf';bassFilter.frequency.value=200;bassFilter.gain.value=0;
      bassBossFilter =audioCtx.createBiquadFilter();bassBossFilter.type='peaking';bassBossFilter.frequency.value=80;bassBossFilter.Q.value=1.5;bassBossFilter.gain.value=0;
      voiceFilter    =audioCtx.createBiquadFilter();voiceFilter.type='peaking';voiceFilter.frequency.value=1000;voiceFilter.Q.value=0.9;voiceFilter.gain.value=0;
      // Voice profiles use a real modulation + waveshaping stage, not just
      // a label or a small EQ change. Normal keeps both stages transparent;
      // Robot/Alien/Ghost get an audible character from the modulation.
      voiceModNode  =audioCtx.createGain();voiceModNode.gain.value=1;
      voiceModOsc   =audioCtx.createOscillator();voiceModOsc.type='sine';voiceModOsc.frequency.value=0.5;
      voiceModDepth =audioCtx.createGain();voiceModDepth.gain.value=0;
      voiceModOsc.connect(voiceModDepth);voiceModDepth.connect(voiceModNode.gain);voiceModOsc.start();
      voiceShapeNode=audioCtx.createWaveShaper();voiceShapeNode.curve=makeCurve(0);voiceShapeNode.oversample='none';
      highFilter     =audioCtx.createBiquadFilter();highFilter.type='highshelf';highFilter.frequency.value=5000;highFilter.gain.value=0;
      presenceFilter =audioCtx.createBiquadFilter();presenceFilter.type='peaking';presenceFilter.frequency.value=3500;presenceFilter.Q.value=0.8;presenceFilter.gain.value=5;
      airFilter      =audioCtx.createBiquadFilter();airFilter.type='highshelf';airFilter.frequency.value=9000;airFilter.gain.value=3;

      // EQ
      eqNodes=EQ_BANDS.map(function(b,i){
        var f=audioCtx.createBiquadFilter();
        f.type=b.type;f.frequency.value=b.freq;f.Q.value=b.type==='peaking'?1.4:0.7;f.gain.value=S.eqGains[i]||0;return f;
      });
      for(var qi=1;qi<eqNodes.length;qi++)eqNodes[qi-1].connect(eqNodes[qi]);

      // Clarity
      clarityDry=audioCtx.createGain();clarityDry.gain.value=1-clamp(S.clarityMix,0,1);
      clarityWet=audioCtx.createGain();clarityWet.gain.value=S.vocalClarity?clamp(S.clarityMix,0,1):0;
      clarityFlt=audioCtx.createBiquadFilter();clarityFlt.type='peaking';clarityFlt.frequency.value=3000;clarityFlt.Q.value=0.8;clarityFlt.gain.value=S.vocalClarity?S.clarityGain:0;

      // Waveshaping / processing
      // Keep the real-time chain light enough for Discord's audio thread.
      // The old 4× oversampling on every inactive shaper could cause brief
      // under-runs on ordinary laptops even when the effects were at zero.
      satNode    =audioCtx.createWaveShaper();satNode.curve=makeSatCurve(S.saturation);satNode.oversample='none';
      distNode   =audioCtx.createWaveShaper();distNode.curve=makeCurve(S.distortion*120);distNode.oversample='none';
      bitcrushNode=audioCtx.createWaveShaper();bitcrushNode.curve=makeBitcrushCurve(S.bitcrush);bitcrushNode.oversample='none';

      // Noise gate sits before every boost. This keeps room hiss from being
      // multiplied by the talking set, rage gain, X24 and output trim.
      gateGainNode=audioCtx.createGain();
      gateGainNode.gain.value=speechGateMode()?S.gateFloor:1;
      gateAnalyser=audioCtx.createAnalyser();
      gateAnalyser.fftSize=512;
      gateAnalyser.smoothingTimeConstant=0.12;

      // Gain stages
      gainNode    =audioCtx.createGain();gainNode.gain.value=computeGainValue();
      x16GainNode =audioCtx.createGain();x16GainNode.gain.value=S.x16Active?4:1;

      // Compressor + waveshaper (rage)
      compressor=audioCtx.createDynamicsCompressor();
      compressor.threshold.value=S.godMode?0:RAGE_TABLE[rl][1];
      compressor.knee.value=S.godMode?0:6;
      compressor.ratio.value=S.godMode?20:RAGE_TABLE[rl][2];
      compressor.attack.value=0.002;compressor.release.value=0.08;
      waveshaper=audioCtx.createWaveShaper();waveshaper.curve=makeCurve(S.godMode?200:RAGE_TABLE[rl][3]);waveshaper.oversample='none';
      // Real final safety limiter. The old waveshaper ceiling hard-clipped
      // loud talking sets and GOD/X24 peaks, which sounded like crashes.
      limiterNode=audioCtx.createDynamicsCompressor();
      limiterNode.threshold.value=clamp(S.limiterCeiling,-12,-1);
      limiterNode.knee.value=0;
      limiterNode.ratio.value=20;
      limiterNode.attack.value=0.001;
      limiterNode.release.value=0.12;
      postGainNode=audioCtx.createGain();postGainNode.gain.value=S.godMode?10:POSTGAIN[Math.min(rl,POSTGAIN.length-1)];

      // Spatial
      panNode=audioCtx.createStereoPanner();panNode.pan.value=S.spatial==='right'?1:S.spatial==='left'?-1:0;
      widthSplitter=audioCtx.createChannelSplitter(2);
      widthMerger=audioCtx.createChannelMerger(2);
      haasL=audioCtx.createDelay(0.05);haasL.delayTime.value=0;
      haasR=audioCtx.createDelay(0.05);haasR.delayTime.value=S.haaswider?S.haasAmount*0.018:0;

      // Reverb
      reverbPreDelayNode=audioCtx.createDelay(0.5);reverbPreDelayNode.delayTime.value=S.reverbPreDelay||PC_REVERB_PROFILE.preDelay;
      reverbNode=audioCtx.createConvolver();reverbNode.buffer=buildReverbIR(audioCtx,S.reverbSize,S.reverbDamping);
      reverbIrSize=S.reverbSize;reverbIrDamping=S.reverbDamping;
      reverbDry=audioCtx.createGain();reverbDry.gain.value=1;
      reverbGain=audioCtx.createGain();reverbGain.gain.value=clamp(S.reverb,0,1);

      // Delay
      delayNode=audioCtx.createDelay(2);delayNode.delayTime.value=clamp(S.delayTime,0,2);
      delayGain=audioCtx.createGain();delayGain.gain.value=clamp(S.delay,0,1);

      // Chorus
      chorusDelay=audioCtx.createDelay(0.05);chorusDelay.delayTime.value=0.015;
      chorusOsc=audioCtx.createOscillator();chorusOsc.type='sine';chorusOsc.frequency.value=S.chorusRate;
      chorusOscGain=audioCtx.createGain();chorusOscGain.gain.value=0.005;
      chorusOsc.connect(chorusOscGain);chorusOscGain.connect(chorusDelay.delayTime);chorusOsc.start();
      chorusMixNode=audioCtx.createGain();chorusMixNode.gain.value=clamp(S.chorusAmount,0,1);

      // Flanger
      flangerDelay=audioCtx.createDelay(0.02);flangerDelay.delayTime.value=0.005;
      flangerOsc=audioCtx.createOscillator();flangerOsc.type='sine';flangerOsc.frequency.value=S.flangerRate;
      flangerOscGain=audioCtx.createGain();flangerOscGain.gain.value=0.003;
      flangerOsc.connect(flangerOscGain);flangerOscGain.connect(flangerDelay.delayTime);flangerOsc.start();
      flangerMixNode=audioCtx.createGain();flangerMixNode.gain.value=clamp(S.flangerAmount,0,1);

      // Output
      outputGain=audioCtx.createGain();outputGain.gain.value=dbToLinear(clamp(S.outputTrimDb,-18,0));
      analyserNode=audioCtx.createAnalyser();analyserNode.fftSize=512;analyserNode.smoothingTimeConstant=0.75;
      mp3GainNode=audioCtx.createGain();mp3GainNode.gain.value=S.mp3Vol;

      var dest=audioCtx.createMediaStreamDestination();

      // ── Wire the chain ──
      // src → gate → preamp → rumble → hp → bass → bassBoss → voice → high → presence → air
      src.connect(gateAnalyser);
      gateAnalyser.connect(gateGainNode);
      gateGainNode.connect(preampNode);
      preampNode.connect(rumbleFilter);
      rumbleFilter.connect(hpFilter);
      hpFilter.connect(bassFilter);
      bassFilter.connect(bassBossFilter);
      bassBossFilter.connect(voiceFilter);
      voiceFilter.connect(voiceModNode);
      voiceModNode.connect(voiceShapeNode);
      voiceShapeNode.connect(highFilter);
      highFilter.connect(presenceFilter);
      presenceFilter.connect(airFilter);

      // Clarity split: air → clarityDry → sat
      //               air → clarityFlt → clarityWet → sat
      airFilter.connect(clarityDry);
      airFilter.connect(clarityFlt);
      clarityFlt.connect(clarityWet);
      clarityDry.connect(satNode);
      clarityWet.connect(satNode);

      // sat → EQ → gain → x24 → comp → waveshaper → dist → bitcrush
      // → postGain → limiter → pan. Limiting last prevents post-gain peaks
      // from turning into clipped syllables.
      satNode.connect(eqNodes[0]);
      eqNodes[eqNodes.length-1].connect(gainNode);
      gainNode.connect(x16GainNode);
      x16GainNode.connect(compressor);
      compressor.connect(waveshaper);
      waveshaper.connect(distNode);
      distNode.connect(bitcrushNode);
      bitcrushNode.connect(postGainNode);
      postGainNode.connect(limiterNode);
      limiterNode.connect(panNode);

      // pan → Haas stereo image → parallel effects
      // The old build created these delay nodes but never connected them,
      // so Wider/Haas could not change the outgoing signal.
      panNode.connect(widthSplitter);
      widthSplitter.connect(haasL,0);
      widthSplitter.connect(haasR,1);
      haasL.connect(widthMerger,0,0);
      haasR.connect(widthMerger,0,1);

      // stereo image → reverb
      widthMerger.connect(reverbDry);
      widthMerger.connect(reverbPreDelayNode);
      reverbPreDelayNode.connect(reverbNode);
      reverbNode.connect(reverbGain);

      // stereo image → delay
      widthMerger.connect(delayNode);
      delayNode.connect(delayGain);

      // stereo image → chorus
      widthMerger.connect(chorusDelay);
      chorusDelay.connect(chorusMixNode);

      // stereo image → flanger
      widthMerger.connect(flangerDelay);
      flangerDelay.connect(flangerMixNode);

      // All paths → outputGain → analyser → dest
      reverbDry.connect(outputGain);
      reverbGain.connect(outputGain);
      delayGain.connect(outputGain);
      chorusMixNode.connect(outputGain);
      flangerMixNode.connect(outputGain);
      outputGain.connect(analyserNode);
      analyserNode.connect(dest);

      // Keep the media gain connected even when a file is loaded later.
      mp3GainNode.connect(preampNode);
      if(mp3File){replaceMp3Element();routeMp3();}
      if(repeaterUrl){
        repeaterAudioEl=D.createElement('audio');
        repeaterAudioEl.crossOrigin='anonymous';
        repeaterAudioEl.loop=true;
        repeaterAudioEl.src=repeaterUrl;
        routeRepeater();
      }

      chainBuilt=true;
      applyNoiseGate();
      startNoiseGate();
      applyVoice();applySpatial();applyEQ();

      var pTracks=dest.stream.getAudioTracks();
      if(!pTracks.length){setStatus('NO OUTPUT TRACK','#ff4444');return null;}
      procTrack=pTracks[0];
      procStream=new MediaStream([procTrack]);
      setStatus('ACTIVE ✓ — CHAIN RUNNING','#22c55e');
      startVU();
      return procStream;
    }catch(e){
      console.error('[BLOOD.XD] buildChain error',e);
      setStatus('CHAIN ERROR: '+e.message,'#ff4444');
      return null;
    }
  }

  // ══════════════════════════════════════════════
  //  ACTIVATION — 3-WAY MIC CAPTURE
  // ══════════════════════════════════════════════
  function tryGetMicStream(cb){
    // 1. Already have origStream
    if(origStream&&origStream.getAudioTracks().length) return cb(origStream);
    // 2. Steal from existing RTCPeerConnection senders
    for(var i=0;i<peerConns.length;i++){
      try{
        var senders=peerConns[i].getSenders();
        for(var j=0;j<senders.length;j++){
          if(senders[j].track&&senders[j].track.kind==='audio'){
            origStream=new MediaStream([senders[j].track.clone()]);
            console.log('[BLOOD.XD] Got mic from sender');
            return cb(origStream);
          }
        }
      }catch(_){}
    }
    // 3. Fresh getUserMedia
    setStatus('REQUESTING MIC…','#ffaa00');
    var speechOnly=speechGateMode();
    var c={audio:{autoGainControl:false,noiseSuppression:speechOnly,echoCancellation:speechOnly,sampleRate:48000,channelCount:1}};
    navigator.mediaDevices.getUserMedia(c).then(function(s){origStream=s;cb(s);}).catch(function(e){
      setStatus('MIC DENIED — '+e.message,'#ff4444');
    });
  }

  function activate(force){
    if(!S.active)return;
    if(!force&&chainBuilt&&procStream&&procTrack&&procTrack.readyState==='live'){
      setStatus('ALREADY ACTIVE — AUDIO STABLE','#22c55e');
      return;
    }
    setStatus('ACTIVATING…','#ffaa00');
    if(!audioCtx||audioCtx.state==='closed'){
      try{audioCtx=new(window.AudioContext||window.webkitAudioContext)({sampleRate:48000});}catch(_){}
    }
    try{if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();}catch(_){}
    tryGetMicStream(function(stream){
      var ns=buildChain(stream);
      if(ns){
        injectAllConns(ns);
        setStatus('ACTIVE ✓  |  '+peerConns.length+' conn(s)  |  '+Math.round(S.gainDb)+'dB'+(S.x16Active?' + X24':'')+(S.godMode?' + GOD':''),'#22c55e');
        refreshFAB();
      }else{
        setStatus('BUILT BUT NOTHING TO INJECT — REJOIN CHANNEL','#ff8800');
      }
    });
  }

  function deactivate(){
    chainBuilt=false;stopVU();stopNoiseGate();
    if(procTrack){try{procTrack.stop();}catch(_){}}
    procStream=null;procTrack=null;
    if(audioCtx&&audioCtx.state!=='closed'){try{audioCtx.close();}catch(_){}}
    audioCtx=null;
    gateGainNode=null;gateAnalyser=null;
    restoreAllConns();
    setStatus('INACTIVE','rgba(255,255,255,0.3)');
    refreshFAB();
  }

  function injectAllConns(stream){
    peerConns.forEach(function(pc){
      try{pc.getSenders().forEach(function(sender){
        if(sender.track&&sender.track.kind==='audio'){
          var t=stream.getAudioTracks()[0];
          if(t)sender.replaceTrack(t).catch(function(){});
        }
      });}catch(_){}
    });
  }

  function restoreAllConns(){
    if(!origStream)return;
    peerConns.forEach(function(pc){
      try{pc.getSenders().forEach(function(sender){
        if(sender.track&&sender.track.kind==='audio'&&origStream.getAudioTracks().length)
          sender.replaceTrack(origStream.getAudioTracks()[0]).catch(function(){});
      });}catch(_){}
    });
  }

  // ══════════════════════════════════════════════
  //  MIC / PEER HOOKS
  // ══════════════════════════════════════════════
  var OrigGUM=navigator.mediaDevices&&navigator.mediaDevices.getUserMedia
    ?navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices):null;
  if(OrigGUM){
    navigator.mediaDevices.getUserMedia=function(c){
      return OrigGUM(killAGC(c)).then(function(stream){
        if(!stream.getAudioTracks().length)return stream;
        origStream=stream;
        console.log('[BLOOD.XD] getUserMedia intercepted');
        if(S.active){
          // Discord can ask for another mic stream during renegotiation.
          // Rebuilding the graph there briefly removed the live track, which
          // sounded like random voice cuts. Keep the current graph alive and
          // let FORCE RECONNECT explicitly opt into a rebuild.
          if(chainBuilt&&procStream&&procTrack&&procTrack.readyState==='live'){
            return procStream;
          }
          var ps=buildChain(stream);
          if(ps){setTimeout(function(){injectAllConns(ps);},100);}
          return ps||stream;
        }
        return stream;
      });
    };
  }

  var OrigPC=window.RTCPeerConnection;
  if(OrigPC){
    window.RTCPeerConnection=function(cfg){var pc=new OrigPC(cfg);trackPC(pc);return pc;};
    try{Object.setPrototypeOf(window.RTCPeerConnection,OrigPC);}catch(_){}
    window.RTCPeerConnection.prototype=OrigPC.prototype;
    var _oAT=OrigPC.prototype.addTrack;
    OrigPC.prototype.addTrack=function(track){
      trackPC(this);
      var r=_oAT.apply(this,arguments);
      if(S.active&&track&&track.kind==='audio'&&procStream){
        var self=this;
        setTimeout(function(){
          try{self.getSenders().forEach(function(s){
            if(s.track&&s.track.kind==='audio'&&procStream)s.replaceTrack(procStream.getAudioTracks()[0]).catch(function(){});
          });}catch(_){}
        },150);
      }
      return r;
    };
  }

  function trackPC(pc){
    if(!pc||peerConns.indexOf(pc)!==-1)return;
    peerConns.push(pc);
    console.log('[BLOOD.XD] Tracking PC. Total:',peerConns.length);
    pc.addEventListener('connectionstatechange',function(){
      if(pc.connectionState==='closed'||pc.connectionState==='failed'){
        var idx=peerConns.indexOf(pc);if(idx!==-1)peerConns.splice(idx,1);
      }
    });
    if(S.active&&procStream){
      setTimeout(function(){
        try{pc.getSenders().forEach(function(s){
          if(s.track&&s.track.kind==='audio'&&procStream)s.replaceTrack(procStream.getAudioTracks()[0]).catch(function(){});
        });}catch(_){}
      },300);
    }
  }

  // ══════════════════════════════════════════════
  //  VU METER
  // ══════════════════════════════════════════════
  var vuRaf=null;
  function startVU(){
    stopVU();if(!analyserNode)return;
    var buf=new Uint8Array(analyserNode.frequencyBinCount);
    function tick(){
      if(!analyserNode||!chainBuilt){stopVU();return;}
      analyserNode.getByteTimeDomainData(buf);
      var rms=0;for(var i=0;i<buf.length;i++){var v=(buf[i]-128)/128;rms+=v*v;}
      rms=Math.sqrt(rms/buf.length);
      updateVUBar(rms);
      vuRaf=requestAnimationFrame(tick);
    }
    vuRaf=requestAnimationFrame(tick);
  }
  function stopVU(){if(vuRaf){cancelAnimationFrame(vuRaf);vuRaf=null;}updateVUBar(0);}
  function updateVUBar(rms){
    var bar=document.getElementById('sup-vu-bar');
    if(!bar)return;
    var pct=Math.min(100,rms*350);
    bar.style.width=pct+'%';
    bar.style.background=pct>85?'#ff456e':pct>55?'#ffbf5a':currentTheme.accent;
  }
  function refreshSignalMap(){
    var gate=D.getElementById('sup-map-gate');
    var model=D.getElementById('sup-map-model');
    var set=D.getElementById('sup-map-set');
    var power=D.getElementById('sup-map-power');
    var auto=D.getElementById('sup-auto-pill');
    if(gate)gate.textContent=S.noiseGate?'GG GATE ON':'GG GATE OFF';
    if(model){
      var vp=VOICE_PROFILES[S.voiceMode]||VOICE_PROFILES.normal;
      model.textContent=vp.label;
    }
    if(set){
      var ts=TALKING_SETS[S.talkingSet]||TALKING_SETS.normal;
      set.textContent=ts.label;
    }
    if(power)power.textContent=S.active?'LIVE / INJECTED':'STANDBY';
    if(auto)auto.classList.toggle('live',!!S.active);
  }

  // ══════════════════════════════════════════════
  //  UI HELPERS
  // ══════════════════════════════════════════════
  var D=document;
  var panel=null,panelVisible=false,currentTab='Main';
  var drag={active:false,ox:0,oy:0},panelDragged=false;
  var currentTheme=THEMES[0];

  function mk(tag,cls,txt){
    var el=D.createElement(tag);if(cls)el.className=cls;if(txt!=null)el.textContent=txt;return el;
  }
  function setStatus(msg,color){
    var el=D.getElementById('sup-status-val');
    if(el){el.textContent=msg;el.style.color=color||'#fff';}
    console.log('[BLOOD.XD]',msg);
  }
  function togglePanel(){
    panelVisible=!panelVisible;
    if(!panel)return;
    if(panelVisible){
      if(!panelDragged){panel.style.left='50%';panel.style.top='50px';panel.style.transform='translateX(-50%)';}
      panel.style.opacity='1';panel.style.pointerEvents='auto';panel.style.visibility='visible';
    }else{
      panel.style.opacity='0';panel.style.pointerEvents='none';panel.style.visibility='hidden';
    }
  }
  function switchTab(name){
    currentTab=name;
    D.querySelectorAll('.sup-tab').forEach(function(t){t.classList.toggle('active',t.dataset.tab===name);});
    D.querySelectorAll('.sup-wheel-btn').forEach(function(t){t.classList.toggle('active',t.dataset.tab===name);});
    D.querySelectorAll('.sup-pane').forEach(function(p){p.classList.toggle('active',p.dataset.pane===name);});
  }
  function setBackgroundEffect(effect){
    S.backgroundEffect=effect||'none';
    if(panel)panel.dataset.effect=S.backgroundEffect;
    D.querySelectorAll('.sup-effect-btn').forEach(function(btn){
      btn.classList.toggle('active',btn.dataset.effect===S.backgroundEffect ||
        (S.backgroundEffect.indexOf(btn.dataset.effect+'-')===0));
    });
  }
  function resetAll(){
    if(S.active){S.active=false;deactivate();}
    if(repeaterRecorder&&repeaterRecorder.state==='recording'){
      try{repeaterRecorder.stop();}catch(_){}
    }
    stopRepeater();
    if(mp3AudioEl){
      try{mp3AudioEl.pause();mp3AudioEl.currentTime=0;}catch(_){}
    }
    if(mp3ObjectUrl){try{URL.revokeObjectURL(mp3ObjectUrl);}catch(_){}}
    mp3File=null;mp3ObjectUrl=null;mp3Src=null;mp3AudioEl=null;
    if(repeaterUrl){try{URL.revokeObjectURL(repeaterUrl);}catch(_){}}
    repeaterUrl=null;repeaterAudioEl=null;repeaterSrc=null;repeaterChunks=[];
    Object.keys(DEFAULT_STATE).forEach(function(key){
      S[key]=Array.isArray(DEFAULT_STATE[key])?DEFAULT_STATE[key].slice():DEFAULT_STATE[key];
    });
    // The hook is intentionally always linked after a reset; there is no
    // longer a visible activation step in the console.
    S.active=true;
    currentTheme=THEMES[0];
    panelDragged=false;
    if(panel){panel.remove();panel=null;}
    buildUI();
    if(panelVisible){
      panel.style.opacity='1';panel.style.pointerEvents='auto';panel.style.visibility='visible';
    }
    switchTab('Main');
    setStatus('RESET ALL COMPLETE','#57ffdd');
    refreshFAB();
    setTimeout(function(){activate();},140);
  }
  function makeDraggable(handle,target){
    handle.addEventListener('mousedown',function(e){
      if(e.button!==0)return;
      if(e.target.closest&&e.target.closest('.sup-win-btn'))return;
      var r=target.getBoundingClientRect();
      target.style.transform='none';target.style.left=r.left+'px';target.style.top=r.top+'px';
      panelDragged=true;drag.active=true;drag.ox=e.clientX-r.left;drag.oy=e.clientY-r.top;
      e.preventDefault();
    });
    D.addEventListener('mousemove',function(e){
      if(!drag.active)return;
      var nx=Math.max(0,Math.min(e.clientX-drag.ox,window.innerWidth-target.offsetWidth));
      var ny=Math.max(0,Math.min(e.clientY-drag.oy,window.innerHeight-60));
      target.style.left=nx+'px';target.style.top=ny+'px';
    });
    D.addEventListener('mouseup',function(){drag.active=false;});
  }
  var PERCENT_SLIDERS=['reverb','delay','chorusAmount','flangerAmount','distortion','saturation','bitcrush','clarityMix'];
  function sliderText(key,value,dec){
    if(PERCENT_SLIDERS.indexOf(key)!==-1)return Math.round(value*100)+'%';
    if(key==='widerAmount')return Math.round(value)+'%';
    if(key==='reverbPreDelay')return Math.round(value*1000)+' ms';
    if(key==='delayTime')return value.toFixed(dec||2)+' s';
    return value.toFixed(dec||0);
  }
  function updateSliderFill(slider){
    var min=parseFloat(slider.min),max=parseFloat(slider.max),value=parseFloat(slider.value);
    var pct=max===min?0:((value-min)/(max-min))*100;
    slider.style.setProperty('--sup-pct',Math.max(0,Math.min(100,pct))+'%');
  }
  function slRow(label,key,min,max,step,val,dec,cb){
    var wrap=mk('div','sup-sl-wrap');
    var top=mk('div','sup-sl-top');
    top.appendChild(mk('span','sup-sl-lbl',label));
    var vspan=mk('span','sup-sl-vval',sliderText(key,val||0,dec));
    top.appendChild(vspan);wrap.appendChild(top);
    var sl=D.createElement('input');sl.type='range';sl.min=min;sl.max=max;sl.step=step;sl.value=val;sl.className='sup-slider';
    sl.dataset.key=key;sl.dataset.dec=dec;
    updateSliderFill(sl);
    sl.addEventListener('input',function(){
      var v=parseFloat(sl.value);S[key]=v;vspan.textContent=sliderText(key,v,dec);
      updateSliderFill(sl);if(cb)cb(v);
    });
    wrap.appendChild(sl);return wrap;
  }
  function syncSliderValue(key,value){
    S[key]=value;
    D.querySelectorAll('input[data-key="'+key+'"]').forEach(function(sl){
      sl.value=value;updateSliderFill(sl);
      var valueEl=sl.parentNode&&sl.parentNode.querySelector('.sup-sl-vval');
      if(valueEl)valueEl.textContent=sliderText(key,value,parseInt(sl.dataset.dec||'2',10));
    });
  }
  function togRow(label,key,cb){
    var wrap=mk('div','sup-tog-wrap');
    var checkbox=D.createElement('input');checkbox.type='checkbox';checkbox.checked=!!S[key];checkbox.className='sup-cb';
    checkbox.dataset.key=key;
    var lbl=mk('label','sup-tog-lbl',label);
    checkbox.addEventListener('change',function(){S[key]=checkbox.checked;if(cb)cb(checkbox.checked);});
    wrap.appendChild(checkbox);wrap.appendChild(lbl);return wrap;
  }
  function btnRow(label,onClick,extraClass){
    var btn=mk('button','sup-action-btn'+(extraClass?' '+extraClass:''),label);
    btn.addEventListener('click',onClick);return btn;
  }
  function applyThemeToUI(th){
    if(!panel)return;
    currentTheme=th;
    var rgb=accentRgb(th.accent);
    panel.style.background=th.bg;
    panel.style.borderColor=th.border;
    panel.style.boxShadow='0 0 60px '+th.glow+', 0 8px 40px rgba(0,0,0,0.9)';
    panel.style.setProperty('--sup-accent',th.accent);
    panel.style.setProperty('--sup-accent-rgb',rgb);
    panel.style.setProperty('--sup-theme-border',th.border);
    panel.style.setProperty('--sup-theme-glow',th.glow);
    panel.dataset.effect=S.backgroundEffect||'none';
    var title=D.getElementById('sup-title');if(title)title.style.color=th.accent;
    var tabs=D.querySelectorAll('.sup-tab.active');
    tabs.forEach(function(t){t.style.color=th.accent;t.style.borderBottomColor=th.accent;});
    // Update CSS variable for accent
    document.documentElement.style.setProperty('--sup-accent',th.accent);
    document.documentElement.style.setProperty('--sup-accent-rgb',rgb);
    D.querySelectorAll('.sup-effect-btn').forEach(function(btn){
      btn.classList.toggle('active',btn.dataset.effect===S.backgroundEffect ||
        (S.backgroundEffect.indexOf(btn.dataset.effect+'-')===0));
    });
  }

  // ══════════════════════════════════════════════
  //  PANE BUILDERS
  // ══════════════════════════════════════════════

  // ── MAIN pane ──
  function buildMainPane(){
    var pane=mk('div','sup-pane active');pane.dataset.pane='Main';

    // Status
    var sr=mk('div','sup-status-row');
    sr.innerHTML=
      '<div class="sup-status-kicker"><span>MAIN CORE</span><span id="sup-auto-pill" class="sup-auto-pill"><i></i>AUTO-LINK</span></div>'+
      '<div class="sup-status-line"><span id="sup-status-val" style="color:rgba(255,255,255,0.3)">STARTING…</span><span class="sup-status-engine">VOICE ENGINE / READY</span></div>';
    pane.appendChild(sr);

    var signalMap=mk('div','sup-signal-map');
    signalMap.innerHTML=
      '<div class="sup-map-head"><span>LIVE SIGNAL ROUTE</span><span id="sup-map-power">STANDBY</span></div>'+
      '<div class="sup-map-route">'+
        '<div class="sup-map-node"><b>MIC</b><span>INPUT</span></div><i>›</i>'+
        '<div class="sup-map-node"><b id="sup-map-gate">NOISE GATE ON</b><span>ROOM CLEANUP</span></div><i>›</i>'+
        '<div class="sup-map-node"><b id="sup-map-model">NORMAL</b><span>VOICE MODEL</span></div><i>›</i>'+
        '<div class="sup-map-node"><b id="sup-map-set">NORMAL</b><span>TALK SET</span></div><i>›</i>'+
        '<div class="sup-map-node"><b>LIMITER</b><span>SAFE OUT</span></div>'+
      '</div>';
    pane.appendChild(signalMap);

    // VU Meter
    var vuW=mk('div','sup-vu-wrap');
    var vuT=mk('div','sup-vu-track');
    var vuB=mk('div','sup-vu-bar');vuB.id='sup-vu-bar';
    vuT.appendChild(vuB);vuW.appendChild(vuT);
    vuW.appendChild(mk('div','sup-vu-label','AUDIO THROUGH HOOK'));
    pane.appendChild(vuW);

    // GAIN
    var gainBox=mk('div','sup-gain-box');
    var gainTitle=mk('div','sup-gain-title','MASTER GAIN — CLEAR VOICE / CONTROLLED LOUDNESS');
    gainBox.appendChild(gainTitle);
    var gainSlider=D.createElement('input');
    gainSlider.type='range';gainSlider.min='0';gainSlider.max='36';gainSlider.step='1';
    gainSlider.value=S.gainDb;gainSlider.id='sup-gain-slider';gainSlider.className='sup-gain-slider';
    updateSliderFill(gainSlider);
    gainSlider.addEventListener('input',function(){
      S.gainDb=parseFloat(gainSlider.value);
      var r=D.getElementById('sup-gain-val');
      if(r)r.textContent=Math.round(S.gainDb)+' dB'+(S.gainDb===0?' (unity)':S.gainDb>=30?'  HIGH':'');
      updateSliderFill(gainSlider);
      applyGain();
    });
    gainBox.appendChild(gainSlider);
    var gainVal=mk('div','sup-gain-readout');gainVal.id='sup-gain-val';gainVal.textContent=Math.round(S.gainDb)+' dB';
    gainBox.appendChild(gainVal);
    pane.appendChild(gainBox);

    // Final output trim: independent from the character/gain controls above.
    var trimBox=mk('div','sup-gain-box sup-trim-box');
    trimBox.appendChild(mk('div','sup-gain-title','OUTPUT TRIM — KEEP THE SIGNAL CLEAN'));
    var trimSlider=D.createElement('input');
    trimSlider.type='range';trimSlider.min='-18';trimSlider.max='0';trimSlider.step='0.5';
    trimSlider.value=S.outputTrimDb;trimSlider.id='sup-trim-slider';trimSlider.className='sup-gain-slider';
    updateSliderFill(trimSlider);
    trimSlider.addEventListener('input',function(){
      S.outputTrimDb=parseFloat(trimSlider.value);
      var r=D.getElementById('sup-trim-val');
      if(r)r.textContent=S.outputTrimDb.toFixed(1)+' dB';
      updateSliderFill(trimSlider);
      applyOutput();
    });
    trimBox.appendChild(trimSlider);
    var trimVal=mk('div','sup-gain-readout sup-trim-readout');trimVal.id='sup-trim-val';
    trimVal.textContent=S.outputTrimDb.toFixed(1)+' dB';
    trimBox.appendChild(trimVal);
    pane.appendChild(trimBox);

    var safety=mk('div','sup-safety-note');
    safety.innerHTML='<span>●</span> LIMITER ACTIVE &nbsp;·&nbsp; OUTPUT TRIM IS SEPARATE FROM GAIN';
    pane.appendChild(safety);

    // Info
    pane.appendChild(mk('div','sup-f2-hint','F2 = toggle  ·  drag title to move  ·  AUDIO LINK RUNS AUTOMATICALLY'));
    return pane;
  }

  // ── X24 MODULE pane ──
  function buildX16Pane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='X24';

    var hdr=mk('div','sup-x16-header');
    hdr.innerHTML='<div class="sup-x16-logo">X 2 4</div><div class="sup-x16-sub">MODULE / DISCORD VOICE ENGINE</div>';
    pane.appendChild(hdr);

    // X24 toggle button (big)
    var x16Wrap=mk('div','sup-x16-btn-wrap');
    var x16Btn=mk('button','sup-x16-btn'+(S.x16Active?' active':''),'');
    x16Btn.innerHTML='<span class="sup-x16-icon">×24</span><span class="sup-x16-status-text">MODULE '+(S.x16Active?'ONLINE':'OFFLINE')+'</span>';
    x16Btn.addEventListener('click',function(){
      S.x16Active=!S.x16Active;
      x16Btn.classList.toggle('active',S.x16Active);
      x16Btn.querySelector('.sup-x16-status-text').textContent='MODULE '+(S.x16Active?'ONLINE':'OFFLINE');
      applyGain();refreshSignalMap();
      setStatus(S.x16Active?'X24 MODULE ACTIVE — 24× GAIN':'X24 MODULE OFF',S.x16Active?'#ffee00':'rgba(255,255,255,0.5)');
    });
    x16Wrap.appendChild(x16Btn);
    pane.appendChild(x16Wrap);

    // GOD MODE
    var godWrap=mk('div','sup-x16-btn-wrap');
    var godBtn=mk('button','sup-god-btn'+(S.godMode?' active':''),'');
    godBtn.innerHTML='<span>⚡ GOD MODE ⚡</span>';
    godBtn.addEventListener('click',function(){
      S.godMode=!S.godMode;
      godBtn.classList.toggle('active',S.godMode);
      applyGain();applyRage();refreshSignalMap();
      setStatus(S.godMode?'GOD MODE — ABSOLUTE MAX POWER':'GOD MODE OFF',S.godMode?'#ff2222':'rgba(255,255,255,0.5)');
    });
    godWrap.appendChild(godBtn);
    pane.appendChild(godWrap);

    // GG GATE — the only control that changes the speech gate.
    var ggWrap=mk('div','sup-x16-btn-wrap');
    var ggBtn=mk('button','sup-gg-btn'+(S.noiseGate?' active':''),'');
    function syncGGButton(){
      ggBtn.classList.toggle('active',S.noiseGate);
      ggBtn.innerHTML='<span>◉ GG GATE</span><small>'+(S.noiseGate?'ON — SPEECH CLEAN':'OFF — AMBIENCE OPEN')+'</small>';
    }
    syncGGButton();
    ggBtn.addEventListener('click',function(){
      S.noiseGate=!S.noiseGate;
      applyCaptureNoiseControl();
      if(S.noiseGate)startNoiseGate();else stopNoiseGate();
      applyNoiseGate();syncGGButton();refreshSignalMap();
      setStatus(S.noiseGate?'GG GATE ON — BACKGROUND HELD':'GG GATE OFF — AMBIENCE OPEN',
        S.noiseGate?'#57ffdd':'rgba(255,255,255,0.5)');
    });
    ggWrap.appendChild(ggBtn);
    pane.appendChild(ggWrap);

    // Rage
    pane.appendChild(mk('div','sup-section-label','RAGE ENGINE'));
    var rageGrid=mk('div','sup-rage-grid');
    RAGE_TABLE.forEach(function(r,i){
      var btn=mk('button','sup-rage-btn',r[4]);
      btn.style.setProperty('--rc',r[5]);
      if(S.rageLevel===i)btn.classList.add('active');
      btn.addEventListener('click',function(){
        S.rageLevel=i;
        rageGrid.querySelectorAll('.sup-rage-btn').forEach(function(b,j){b.classList.toggle('active',j===i);});
        applyRage();
      });
      rageGrid.appendChild(btn);
    });
    pane.appendChild(rageGrid);

    // Talking Set
    pane.appendChild(mk('div','sup-section-label','TALKING SET'));
    var tsGrid=mk('div','sup-ts-grid');
    Object.keys(TALKING_SETS).forEach(function(tk){
      var ts=TALKING_SETS[tk];
      var btn=mk('button','sup-ts-btn');
      btn.innerHTML='<span>'+ts.label+'</span><small>'+ts.sub+'</small>';
      if(S.talkingSet===tk)btn.classList.add('active');
      btn.addEventListener('click',function(){
        S.talkingSet=tk;
        tsGrid.querySelectorAll('.sup-ts-btn').forEach(function(b){b.classList.remove('active');});
        btn.classList.add('active');applyGain();refreshSignalMap();
      });
      tsGrid.appendChild(btn);
    });
    pane.appendChild(tsGrid);

    // X24 info
    var info=mk('div','sup-x16-info');
    info.innerHTML='<b>X24 MODULE</b> adds 24× linear gain on top of your master gain.<br>'+
      'With <b>GOD MODE</b>, the protected ceiling rises to 240× while the final limiter stays active.<br>'+
      'Use Rage Engine to control compression and waveshaping intensity.';
    pane.appendChild(info);
    return pane;
  }

  // ── PAN / HEAD POSITION pane ──
  function buildPanPane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='Pan';
    pane.appendChild(mk('div','sup-section-label','HOLOGRAPHIC PAN FIELD'));
    var field=mk('div','sup-pan-field');
    field.innerHTML='<div class="sup-pan-grid"></div><div class="sup-pan-head">◉</div>'+
      '<div class="sup-pan-wave left">◁</div><div class="sup-pan-wave right">▷</div>'+
      '<div class="sup-pan-caption">VOICE POSITION / STEREO IMAGE</div>';
    pane.appendChild(field);
    var panState=mk('div','sup-pan-state','CENTER / BOTH SIDES');panState.id='sup-pan-state';
    pane.appendChild(panState);
    var panGrid=mk('div','sup-pan-grid-buttons');
    [
      ['left','LEFT PAN'],['center','CENTER'],['right','RIGHT PAN'],
      ['front','FRONT HEAD'],['behind','BEHIND HEAD']
    ].forEach(function(item){
      var btn=mk('button','sup-big-choice'+(S.spatial===item[0]?' active':''),item[1]);
      btn.dataset.spatial=item[0];
      btn.addEventListener('click',function(){
        S.spatial=item[0];
        panGrid.querySelectorAll('.sup-big-choice').forEach(function(b){b.classList.toggle('active',b.dataset.spatial===item[0]);});
        var state=D.getElementById('sup-pan-state');
        if(state)state.textContent=item[1]+' — VOICE PLACEMENT ACTIVE';
        field.dataset.position=item[0];
        applySpatial();
      });
      panGrid.appendChild(btn);
    });
    pane.appendChild(panGrid);
    pane.appendChild(mk('div','sup-pan-help','Left and right pan the voice. Front and Behind Head shape the stereo placement while the visual field follows your choice.'));
    return pane;
  }

  // ── STEREO WIDER pane ──
  function buildWiderPane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='Wider';
    pane.appendChild(mk('div','sup-section-label','STEREO WIDER'));
    var meter=mk('div','sup-wider-meter');
    meter.innerHTML='<div class="sup-wider-orbit"></div><div class="sup-wider-core">WIDE</div>';
    pane.appendChild(meter);
    var readout=mk('div','sup-wider-readout','0% WIDER');readout.id='sup-wider-readout';
    pane.appendChild(readout);
    pane.appendChild(slRow('WIDER WIDTH','widerAmount',0,200,1,S.widerAmount,0,function(v){
      var r=D.getElementById('sup-wider-readout');if(r)r.textContent=Math.round(v)+'% WIDER';
      applySpatial();
    }));
    var modeGrid=mk('div','sup-mode-grid');
    [['mono', 'MONO', 0],['stereo','STEREO',80],['ultra','ULTRA',180]].forEach(function(item){
      var btn=mk('button','sup-big-choice'+(S.widerAmount===item[2]?' active':''),item[1]);
      btn.addEventListener('click',function(){
        S.widerAmount=item[2];S.haaswider=item[2]>0;
        var sl=pane.querySelector('input[data-key="widerAmount"]');
        if(sl){sl.value=item[2];updateSliderFill(sl);}
        readout.textContent=item[2]+'% WIDER';
        modeGrid.querySelectorAll('.sup-big-choice').forEach(function(b){b.classList.remove('active');});
        btn.classList.add('active');applySpatial();
      });
      modeGrid.appendChild(btn);
    });
    pane.appendChild(modeGrid);
    pane.appendChild(mk('div','sup-pan-help','MONO = centered. STEREO = natural width. ULTRA = maximum Haas spread.'));
    return pane;
  }

  // ── EQ pane ──
  function buildEQPane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='EQ';

    pane.appendChild(mk('div','sup-section-label','EQUALIZER — 15 BAND'));

    // Preset selector
    var presetSel=D.createElement('select');presetSel.className='sup-select';
    Object.keys(EQ_PRESETS).forEach(function(pk){
      var opt=D.createElement('option');opt.value=pk;opt.textContent=pk;
      if(pk===S.eqPreset)opt.selected=true;
      presetSel.appendChild(opt);
    });
    presetSel.addEventListener('change',function(){
      S.eqPreset=presetSel.value;S.eqGains=(EQ_PRESETS[S.eqPreset]||[]).slice();
      applyEQ();
      pane.querySelectorAll('.sup-eq-slider').forEach(function(sl,i){sl.value=S.eqGains[i]||0;updateSliderFill(sl);});
      pane.querySelectorAll('.sup-eq-val').forEach(function(v,i){v.textContent=(S.eqGains[i]||0).toFixed(0);});
    });
    pane.appendChild(presetSel);

    // Flat / Reset button
    var flatBtn=mk('button','sup-action-btn','FLAT');
    flatBtn.addEventListener('click',function(){
      presetSel.value='Flat';S.eqPreset='Flat';S.eqGains=EQ_PRESETS['Flat'].slice();
      applyEQ();
      pane.querySelectorAll('.sup-eq-slider').forEach(function(sl,i){sl.value=0;updateSliderFill(sl);});
      pane.querySelectorAll('.sup-eq-val').forEach(function(v){v.textContent='0';});
    });
    pane.appendChild(flatBtn);

    // EQ Grid with labels and value display
    var eqGrid=mk('div','sup-eq-grid');
    EQ_LABELS.forEach(function(lbl,i){
      var col=mk('div','sup-eq-col');
      var val=mk('div','sup-eq-val',String(S.eqGains[i]||0));
      col.appendChild(val);
      var sl=D.createElement('input');
      sl.type='range';sl.min='-18';sl.max='18';sl.step='0.5';sl.value=S.eqGains[i]||0;
      sl.className='sup-eq-slider';sl.orient='vertical';
      sl.addEventListener('input',function(){
        S.eqGains[i]=parseFloat(sl.value);
        val.textContent=parseFloat(sl.value).toFixed(0);
        applyEQ();
      });
      col.appendChild(sl);col.appendChild(mk('div','sup-eq-lbl',lbl));
      eqGrid.appendChild(col);
    });
    pane.appendChild(eqGrid);

    // Clarity
    pane.appendChild(mk('div','sup-section-label','VOCAL CLARITY'));
    pane.appendChild(togRow('Vocal Clarity','vocalClarity',function(){applyClarity();}));
    pane.appendChild(slRow('Clarity Gain','clarityGain',0,30,0.5,S.clarityGain,1,function(){applyClarity();}));
    pane.appendChild(slRow('Clarity Mix','clarityMix',0,1,0.01,S.clarityMix,2,function(){applyClarity();}));
    return pane;
  }

  // ── VOICE pane ──
  function buildVoicePane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='Voice';

    pane.appendChild(mk('div','sup-section-label','VOICE MODE'));
    var vmGrid=mk('div','sup-voice-grid');
    Object.keys(VOICE_PROFILES).forEach(function(vk){
      var vp=VOICE_PROFILES[vk];
      var btn=mk('button','sup-voice-btn',vp.label);
      if(S.voiceMode===vk)btn.classList.add('active');
      btn.addEventListener('click',function(){
        S.voiceMode=vk;
        vmGrid.querySelectorAll('.sup-voice-btn').forEach(function(b){b.classList.remove('active');});
        btn.classList.add('active');applyVoice();refreshSignalMap();
      });
      vmGrid.appendChild(btn);
    });
    pane.appendChild(vmGrid);
    pane.appendChild(mk('div','sup-section-label','VOICE CHARACTER / MODULATION'));
    pane.appendChild(slRow('CHARACTER SHIFT','pitchShift',-12,12,1,S.pitchShift,0,function(){applyVoice();}));
    pane.appendChild(mk('div','sup-voice-note','Profiles now use resonance, harmonic drive and modulation. Robot, Alien and Ghost have an audible live character—not just an EQ label.'));

    pane.appendChild(mk('div','sup-section-label','BASS / TREBLE'));
    pane.appendChild(togRow('Bass Boost (+8 dB)','bassBoost',function(){applyVoice();}));
    pane.appendChild(togRow('Bass Boss (+16 dB)','bassBoss',function(){applyVoice();}));

    pane.appendChild(mk('div','sup-section-label','SPATIAL'));
    var spatGrid=mk('div','sup-ts-grid');
    ['left','center','right'].forEach(function(sv){
      var btn=mk('button','sup-ts-btn',sv.toUpperCase());
      if(S.spatial===sv)btn.classList.add('active');
      btn.addEventListener('click',function(){
        S.spatial=sv;
        spatGrid.querySelectorAll('.sup-ts-btn').forEach(function(b){b.classList.remove('active');});
        btn.classList.add('active');applySpatial();
      });
      spatGrid.appendChild(btn);
    });
    pane.appendChild(spatGrid);
    pane.appendChild(togRow('Haas Wider','haaswider',function(){applySpatial();}));
    pane.appendChild(slRow('Haas Amount','haasAmount',0.1,5,0.1,S.haasAmount,1,function(){applySpatial();}));
    pane.appendChild(togRow('High-Pass Filter','highpass',function(){applyHighpass();}));
    return pane;
  }

  // ── EFFECTS pane ──
  function buildFXPane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='FX';

    pane.appendChild(mk('div','sup-section-label','ECHO / REVERB — '+PC_REVERB_PROFILE.label));
    var reverbPresets=mk('div','sup-preset-grid');
    [
      ['waittt','PC WAITTT',[PC_REVERB_PROFILE.wet,PC_REVERB_PROFILE.size,PC_REVERB_PROFILE.damping,PC_REVERB_PROFILE.preDelay]],
      ['room','ROOM',[0.24,2.2,0.38,0.018]],
      ['hall','HALL',[0.62,7.5,0.52,0.045]],
      ['cave','CAVE',[0.78,11.5,0.72,0.085]],
      ['void','VOID',[0.92,14,0.86,0.14]]
    ].forEach(function(item){
      var btn=mk('button','sup-big-choice',item[0].toUpperCase());
      btn.addEventListener('click',function(){
        S.reverb=item[1][0];S.reverbSize=item[1][1];S.reverbDamping=item[1][2];S.reverbPreDelay=item[1][3];
        syncSliderValue('reverb',S.reverb);syncSliderValue('reverbSize',S.reverbSize);
        syncSliderValue('reverbDamping',S.reverbDamping);syncSliderValue('reverbPreDelay',S.reverbPreDelay);
        applyReverb();setStatus(item[0].toUpperCase()+' REVERB ACTIVE',currentTheme.accent);
      });
      reverbPresets.appendChild(btn);
    });
    pane.appendChild(reverbPresets);
    pane.appendChild(mk('div','sup-effect-note','PC WAITTT profile: dense stereo room translated from the supplied GGate / CRTIV Reverb / ReverbSolo chain.'));
    pane.appendChild(slRow('Reverb Mix',    'reverb',      0,1,  0.01,S.reverb,      2,function(){applyReverb();}));
    pane.appendChild(slRow('Reverb Size',   'reverbSize',  0.1,14,0.1,S.reverbSize,  1,function(){applyReverb();}));
    pane.appendChild(slRow('Reverb Damping','reverbDamping',0,1, 0.01,S.reverbDamping,2,function(){applyReverb();}));
    pane.appendChild(slRow('Pre-Delay',     'reverbPreDelay',0,0.2,0.001,S.reverbPreDelay,3,function(){applyReverb();}));

    pane.appendChild(mk('div','sup-section-label','REPEATER'));
    var repStatus=mk('div','sup-repeater-status','NO CLIP — AUTO-LINK WAITING FOR MIC');repStatus.id='sup-repeater-status';
    pane.appendChild(repStatus);
    var repControls=mk('div','sup-repeater-controls');
    var recBtn=mk('button','sup-repeater-btn','● RECORD');
    var stopRecBtn=mk('button','sup-repeater-btn','■ STOP RECORD');
    var loopBtn=mk('button','sup-repeater-btn','↻ LOOP PLAY');
    var stopLoopBtn=mk('button','sup-repeater-btn','■ STOP LOOP');
    function repMessage(msg,color){repStatus.textContent=msg;repStatus.style.color=color||'#fff';setStatus(msg,color);}
    recBtn.addEventListener('click',function(){startRepeaterRecording(repMessage);});
    stopRecBtn.addEventListener('click',function(){stopRepeaterRecording(repMessage);});
    loopBtn.addEventListener('click',function(){playRepeater(repMessage);});
    stopLoopBtn.addEventListener('click',function(){stopRepeater(repMessage);});
    [recBtn,stopRecBtn,loopBtn,stopLoopBtn].forEach(function(b){repControls.appendChild(b);});
    pane.appendChild(repControls);
    pane.appendChild(mk('div','sup-repeater-help','Record a clip, stop it, then loop the exact captured phrase through the audio chain.'));

    pane.appendChild(mk('div','sup-section-label','DELAY'));
    pane.appendChild(slRow('Delay Mix', 'delay',    0,1,0.01,S.delay,    2,function(){applyDelay();}));
    pane.appendChild(slRow('Delay Time','delayTime',0,2,0.01,S.delayTime,2,function(){applyDelay();}));

    pane.appendChild(mk('div','sup-section-label','CHORUS'));
    pane.appendChild(slRow('Chorus Mix', 'chorusAmount',0,1,0.01,S.chorusAmount,2,function(){applyChorus();}));
    pane.appendChild(slRow('Chorus Rate','chorusRate',  0.1,8,0.1,S.chorusRate,  1,function(){applyChorus();}));

    pane.appendChild(mk('div','sup-section-label','FLANGER'));
    pane.appendChild(slRow('Flanger Mix', 'flangerAmount',0,1,0.01,S.flangerAmount,2,function(){applyFlanger();}));
    pane.appendChild(slRow('Flanger Rate','flangerRate',  0.1,5,0.1,S.flangerRate,  1,function(){applyFlanger();}));

    pane.appendChild(mk('div','sup-section-label','DISTORTION'));
    pane.appendChild(slRow('Distortion','distortion',0,1,0.01,S.distortion,2,function(){applyDistortion();}));
    pane.appendChild(slRow('Saturation','saturation',0,1,0.01,S.saturation,2,function(){applyDistortion();}));
    pane.appendChild(slRow('Bitcrush',  'bitcrush',  0,1,0.01,S.bitcrush,  2,function(){applyDistortion();}));
    return pane;
  }

  // ── MP3 PLAYER pane ──
  function buildMP3Pane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='MP3';

    pane.appendChild(mk('div','sup-section-label','MP3 PLAYER'));

    // File loader
    var fileWrap=mk('div','sup-mp3-file-wrap');
    var fileLabel=mk('label','sup-mp3-file-btn','📂  LOAD AUDIO FILE');
    var fileInput=D.createElement('input');fileInput.type='file';fileInput.accept='audio/*';fileInput.style.display='none';
    fileInput.addEventListener('change',function(){
      var file=fileInput.files[0];if(!file)return;
      if(mp3ObjectUrl){try{URL.revokeObjectURL(mp3ObjectUrl);}catch(_){}}
      mp3File=file;
      mp3ObjectUrl=URL.createObjectURL(file);
      var trackName=D.getElementById('sup-mp3-track');
      if(trackName)trackName.textContent=file.name;
      replaceMp3Element();
      if(chainBuilt)routeMp3();
      setStatus('MP3 LOADED: '+file.name,'#22c55e');
    });
    fileLabel.appendChild(fileInput);fileWrap.appendChild(fileLabel);
    var trackName=mk('div','sup-mp3-track','No file loaded');trackName.id='sup-mp3-track';
    fileWrap.appendChild(trackName);
    pane.appendChild(fileWrap);

    // Controls
    var ctrlWrap=mk('div','sup-mp3-controls');
    var playBtn=mk('button','sup-mp3-btn','▶ PLAY');
    var pauseBtn=mk('button','sup-mp3-btn','⏸ PAUSE');
    var stopBtn=mk('button','sup-mp3-btn','⏹ STOP');
    playBtn.addEventListener('click',function(){
      if(!mp3AudioEl){setStatus('LOAD A FILE FIRST','#ffaa00');return;}
      if(!chainBuilt){setStatus('AUDIO LINK NOT READY — WAITING FOR DISCORD MIC','#ffaa00');return;}
      if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume().catch(function(){});
      routeMp3();
      mp3AudioEl.play().then(function(){S.mp3Playing=true;setStatus('MP3 PLAYING — FULL CHAIN','#22c55e');})
        .catch(function(){setStatus('MP3 PLAY BLOCKED — CLICK PLAY AGAIN','#ffaa00');});
    });
    pauseBtn.addEventListener('click',function(){if(mp3AudioEl){mp3AudioEl.pause();S.mp3Playing=false;}});
    stopBtn.addEventListener('click',function(){if(mp3AudioEl){mp3AudioEl.pause();mp3AudioEl.currentTime=0;S.mp3Playing=false;}});
    ctrlWrap.appendChild(playBtn);ctrlWrap.appendChild(pauseBtn);ctrlWrap.appendChild(stopBtn);
    pane.appendChild(ctrlWrap);

    // Loop / Volume
    pane.appendChild(togRow('Loop','mp3Loop',function(v){if(mp3AudioEl)mp3AudioEl.loop=v;}));
    var meter=mk('div','sup-digital-meter');
    for(var mi=0;mi<28;mi++)meter.appendChild(mk('span','sup-meter-segment'));
    pane.appendChild(meter);
    pane.appendChild(mk('div','sup-meter-caption','DIGITAL OUTPUT / FULL CHAIN MONITOR'));
    pane.appendChild(slRow('MP3 Volume','mp3Vol',0,2,0.01,S.mp3Vol,2,function(v){if(mp3GainNode)mp3GainNode.gain.value=v;}));

    pane.appendChild(mk('div','sup-section-label','NOTE'));
    var note=mk('div','sup-mp3-note');
    note.textContent='MP3 audio is routed through the FULL audio chain — it gets all your gain, EQ, effects, and goes out to Discord along with your mic.';
    pane.appendChild(note);
    return pane;
  }

  // ── THEME pane ──
  function buildThemePane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='Theme';
    pane.appendChild(mk('div','sup-section-label','18 COLOR THEMES'));
    var grid=mk('div','sup-theme-grid');
    var effectDetail=mk('div','sup-effect-detail');
    var effectOptions={
      fire:[
        ['fire-low','LOW FLAME'],['fire-full','FULL FIRE'],['fire-top','TOP FIRE'],
        ['fire-wave','FIRE WAVE'],['fire-embers','EMBER RAIN'],['fire-blue','BLUE FIRE'],
        ['fire-white','WHITE FIRE'],['fire-neon','NEON FIRE']
      ],
      water:[
        ['water-drops','WATER DROPS'],['water-wave','WATER WAVE'],['water-rain','RAIN FALL'],
        ['water-bubbles','BUBBLE RISE']
      ],
      lava:[
        ['lava-flow','LAVA FLOW'],['lava-bubbles','MAGMA BUBBLES'],['lava-cracks','LAVA CRACKS'],
        ['lava-pulse','MOLTEN PULSE']
      ],
      sakura:[
        ['sakura-fall','PETAL FALL'],['sakura-breeze','SIDE BREEZE'],['sakura-storm','PETAL STORM'],
        ['sakura-bloom','PINK BLOOM']
      ],
      rainbow:[
        ['rainbow-soft','SOFT WAVE'],['rainbow-full','FULL SPECTRUM'],['rainbow-spin','COLOR SPIN'],
        ['rainbow-pulse','PRISM PULSE']
      ],
      aurora:[
        ['aurora-drift','AURORA DRIFT'],['aurora-ribbons','LIGHT RIBBONS'],['aurora-pulse','AURORA PULSE']
      ],
      neon:[
        ['neon-pulse','NEON PULSE'],['neon-grid','NEON GRID'],['neon-bloom','NEON BLOOM']
      ]
    };
    function renderEffectOptions(base){
      effectDetail.innerHTML='';
      var options=effectOptions[base]||[];
      if(!options.length){
        effectDetail.appendChild(mk('div','sup-effect-detail-empty','Choose an effect family for its own animated styles.'));
        return;
      }
      options.forEach(function(option){
        var optionBtn=mk('button','sup-effect-option'+(S.backgroundEffect===option[0]?' active':''),option[1]);
        optionBtn.dataset.effect=option[0];
        optionBtn.addEventListener('click',function(){
          setBackgroundEffect(option[0]);
          effectDetail.querySelectorAll('.sup-effect-option').forEach(function(b){b.classList.remove('active');});
          optionBtn.classList.add('active');
          setStatus(option[1]+' ACTIVE',currentTheme.accent);
        });
        effectDetail.appendChild(optionBtn);
      });
    }
    THEMES.forEach(function(th){
      var btn=mk('button','sup-theme-btn');
      btn.textContent=th.label;btn.style.background=th.bg;btn.style.borderColor=th.border;btn.style.color=th.accent;
      if(S.theme===th.id)btn.classList.add('active');
      btn.addEventListener('click',function(){
        S.theme=th.id;
        grid.querySelectorAll('.sup-theme-btn').forEach(function(b){b.classList.remove('active');});
        btn.classList.add('active');
        if(['fire','water','lava','sakura','rainbow','aurora','neon'].indexOf(th.id)!==-1)setBackgroundEffect(th.id);
        else setBackgroundEffect('none');
        renderEffectOptions(th.id);
        applyThemeToUI(th);
      });
      grid.appendChild(btn);
    });
    pane.appendChild(grid);

    pane.appendChild(mk('div','sup-section-label','PANEL BACKGROUND FX'));
    var fxGrid=mk('div','sup-effect-grid');
    [
      ['none','OFF','Clean color only'],
      ['fire','🔥 FIRE','Animated flames'],
      ['water','💧 WATER','Drops and waves'],
      ['lava','🌋 LAVA','Molten flow'],
      ['sakura','🌸 SAKURA','Falling flowers'],
      ['rainbow','🌈 RAINBOW','Color wave'],
      ['aurora','✦ AURORA','Soft light'],
      ['neon','⚡ NEON','Pulse glow']
    ].forEach(function(item){
      var fxBtn=mk('button','sup-effect-btn'+(S.backgroundEffect===item[0]?' active':''),item[1]);
      fxBtn.dataset.effect=item[0];
      fxBtn.title=item[2];
      fxBtn.addEventListener('click',function(){
        setBackgroundEffect(item[0]);
        renderEffectOptions(item[0]);
        setStatus(item[0]==='none'?'BACKGROUND FX OFF':item[1]+' BACKGROUND ACTIVE',currentTheme.accent);
      });
      fxGrid.appendChild(fxBtn);
    });
    pane.appendChild(fxGrid);
    pane.appendChild(effectDetail);
    renderEffectOptions(S.backgroundEffect.split('-')[0]);
    pane.appendChild(mk('div','sup-effect-note','Choose a color above, then add an animated effect behind the panel.'));
    return pane;
  }

  // ── CREDITS pane ──
  function buildCreditsPane(){
    var pane=mk('div','sup-pane');pane.dataset.pane='Info';
    pane.appendChild(mk('div','sup-credits-logo','BLOOD.XD'));
    pane.appendChild(mk('div','sup-credits-version','v4.6.1 — HARD GATE / LONG ROOM'));
    pane.appendChild(mk('div','sup-credits-sep'));
    pane.appendChild(mk('div','sup-credits-authors','CREATED BY STAM GOD TONY'));
    ['BLOOD.XD is Tony’s mobile loudest hook for Discord voice shaping.',
     'Pans, stereo width and voice profiles work through the live audio chain.',
     'Mono mic → stereo image with wider, head-position and ambience controls.',
     'Tony runs the code. Tony runs the hook. Tony runs the console.',
     'X24 Module · 15-Band EQ · 10 Voice Modes',
     'MP3 Player · Repeater · 6 FX Types · 18 Themes + animated panel FX',
     'Reset All returns every control and color effect to its default.',
     'MADE BY TONY DADDY · BLOOD.XD EDITION'].forEach(function(l){
      pane.appendChild(mk('div','sup-credits-line',l));
    });
    pane.appendChild(mk('div','sup-credits-sep'));
    var keys=mk('div','sup-credits-keys');
    keys.innerHTML='<b>F2</b> Toggle &nbsp;·&nbsp; <b>Drag title</b> Move &nbsp;·&nbsp; <b>AUTO-LINK</b> Retakes Discord mic tracks';
    pane.appendChild(keys);
    return pane;
  }

  // ══════════════════════════════════════════════
  //  STYLES
  // ══════════════════════════════════════════════
  function injectStyles(){
    var oldStyle=D.getElementById('sup-styles');
    if(oldStyle)oldStyle.remove();
    var th=currentTheme;
    var thRgb=accentRgb(th.accent);
    var css=[
      '@import url("https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap");',
      ':root{--sup-accent:'+th.accent+';--sup-accent-rgb:'+thRgb+';}',
      '@keyframes sup-x16-pulse{0%,100%{box-shadow:0 0 20px '+th.accent+',0 0 40px '+th.accent+'}50%{box-shadow:0 0 40px '+th.accent+',0 0 80px '+th.accent+'}}',
      '@keyframes sup-god-pulse{0%,100%{box-shadow:0 0 30px #ff2222,0 0 60px #ff8800}50%{box-shadow:0 0 60px #ff2222,0 0 120px #ff8800}}',
      '@keyframes sup-signal-pulse{0%,100%{opacity:.55;transform:scaleX(.96)}50%{opacity:1;transform:scaleX(1)}}',
      '@keyframes sup-gate-blink{0%,100%{box-shadow:0 0 0 rgba(87,255,221,0)}50%{box-shadow:0 0 14px rgba(87,255,221,.28)}}',

      // Panel
      '#sup-panel{position:fixed;top:50px;left:50%;transform:translateX(-50%);z-index:2147483645;',
        'width:740px;background:'+th.bg+';border:1px solid '+th.border+';',
        'font-family:"Share Tech Mono","Courier New",monospace;color:#fff;overflow:hidden;',
        'display:flex;flex-direction:column;user-select:none;',
        'visibility:hidden;opacity:0;pointer-events:none;',
        'box-shadow:0 0 60px '+th.glow+',0 8px 40px rgba(0,0,0,0.9);}',

      // Title bar
      '#sup-titlebar{display:flex;align-items:center;justify-content:center;',
        'padding:12px 16px 8px;cursor:grab;flex-shrink:0;position:relative;',
        'border-bottom:1px solid rgba(255,255,255,0.08);}',
      '#sup-titlebar:active{cursor:grabbing;}',
      '#sup-title-deco{flex:1;display:flex;align-items:center;gap:4px;}',
      '#sup-title-deco-r{flex:1;display:flex;align-items:center;justify-content:flex-end;gap:4px;}',
      '.sup-deco-bar{height:1px;width:30px;background:rgba(255,255,255,0.3);}',
      '#sup-title{font-size:24px;font-weight:900;letter-spacing:10px;color:'+th.accent+';flex-shrink:0;margin:0 14px;}',
      '#sup-win-btns{position:absolute;right:12px;top:50%;transform:translateY(-50%);display:flex;gap:6px;}',
      '.sup-win-btn{width:18px;height:18px;background:none;border:1px solid rgba(255,255,255,0.25);',
        'color:rgba(255,255,255,0.4);font-size:10px;cursor:pointer;display:flex;align-items:center;',
        'justify-content:center;padding:0;font-family:monospace;transition:all 0.12s;}',
      '.sup-win-btn:hover{background:rgba(255,255,255,0.1);color:#fff;}',
      '.sup-win-btn.close:hover{background:rgba(180,30,30,0.5);border-color:#cc2222;}',

      // Tabs
      '#sup-tabs{display:flex;border-bottom:1px solid rgba(255,255,255,0.1);flex-shrink:0;padding:0 6px;overflow-x:auto;}',
      '#sup-tabs::-webkit-scrollbar{display:none;}',
      '.sup-tab{padding:7px 12px;background:none;border:none;border-bottom:2px solid transparent;',
        'color:rgba(255,255,255,0.4);font-family:"Share Tech Mono","Courier New",monospace;',
        'font-size:10px;letter-spacing:1.5px;cursor:pointer;transition:all 0.12s;white-space:nowrap;flex-shrink:0;}',
      '.sup-tab:hover{color:rgba(255,255,255,0.75);}',
      '.sup-tab.active{color:'+th.accent+';border-bottom:2px solid '+th.accent+';}',

      // Panes
      '#sup-pane-wrap{flex:1;min-height:0;overflow:hidden;max-height:480px;}',
      '.sup-pane{display:none;overflow-y:auto;height:100%;padding:14px 18px 18px;',
        'scrollbar-width:auto;scrollbar-color:rgba(87,255,221,0.72) rgba(255,255,255,0.06);',
        'scrollbar-gutter:stable;}',
      '.sup-pane::-webkit-scrollbar{width:11px;}',
      '.sup-pane::-webkit-scrollbar-track{background:rgba(0,0,0,0.28);border-left:1px solid rgba(255,255,255,0.08);}',
      '.sup-pane::-webkit-scrollbar-thumb{background:linear-gradient(180deg,rgba(87,255,221,0.88),rgba(54,232,242,0.42));',
        'border:2px solid rgba(3,18,29,0.82);border-radius:10px;box-shadow:0 0 9px rgba(87,255,221,0.45);}',
      '.sup-pane::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,#d9ffff,#36e8f2);}',
      '.sup-pane.active{display:block;}',

      // Status
      '.sup-status-row{text-align:center;font-size:10px;letter-spacing:2px;margin-bottom:8px;min-height:16px;}',

      // VU
      '.sup-vu-wrap{margin-bottom:10px;}',
      '.sup-vu-track{height:5px;background:rgba(255,255,255,0.07);border-radius:3px;overflow:hidden;}',
      '#sup-vu-bar{height:100%;width:0%;background:#22c55e;border-radius:3px;transition:width 0.04s,background 0.08s;}',
      '.sup-vu-label{font-size:7px;letter-spacing:3px;color:rgba(255,255,255,0.2);margin-top:3px;text-align:center;}',

      // Power btn
      '.sup-power-btn{display:block;width:100%;padding:13px;border:1px solid rgba(255,255,255,0.22);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.45);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:13px;font-weight:900;',
        'letter-spacing:5px;cursor:pointer;margin-bottom:7px;transition:all 0.15s;}',
      '.sup-power-btn:hover{border-color:rgba(255,255,255,0.5);color:#fff;}',
      '.sup-power-btn.on{border-color:'+th.accent+';color:'+th.accent+';background:rgba(255,255,255,0.05);}',

      // Force reconnect
      '.sup-force-btn{display:block;width:100%;padding:8px;border:1px solid rgba(255,165,0,0.35);',
        'background:rgba(255,165,0,0.04);color:rgba(255,165,0,0.7);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:9px;letter-spacing:2px;',
        'cursor:pointer;margin-bottom:12px;transition:all 0.12s;}',
      '.sup-force-btn:hover{border-color:rgba(255,165,0,0.7);color:#ffa500;}',

      // Gain
      '.sup-gain-box{border:1px solid rgba(255,255,255,0.15);padding:12px 16px;margin-bottom:12px;}',
      '.sup-gain-title{text-align:center;font-size:8px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:10px;}',
      '.sup-gain-slider{-webkit-appearance:none;appearance:none;width:100%;height:8px;',
        'background:linear-gradient(90deg,#222 0%,#777 50%,'+th.accent+' 100%);',
        'border-radius:4px;outline:none;cursor:pointer;margin-bottom:6px;}',
      '.sup-gain-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;',
        'width:22px;height:22px;border-radius:50%;',
        'background:radial-gradient(circle at 40% 35%,#eee,#888);',
        'cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.8);}',
      '.sup-gain-readout{text-align:center;font-size:16px;font-weight:900;letter-spacing:3px;color:#fff;}',

      // Hint
      '.sup-f2-hint{text-align:center;font-size:8px;letter-spacing:1px;color:rgba(255,255,255,0.2);margin-top:8px;line-height:1.8;}',

      // Section labels
      '.sup-section-label{font-size:7px;letter-spacing:5px;font-weight:700;color:rgba(255,255,255,0.28);',
        'margin:12px 0 7px;border-bottom:1px solid rgba(255,255,255,0.07);padding-bottom:3px;}',

      // X16 MODULE
      '.sup-x16-header{text-align:center;margin-bottom:14px;padding:12px 0;}',
      '.sup-x16-logo{font-size:42px;font-weight:900;letter-spacing:16px;color:'+th.accent+';',
        'text-shadow:0 0 30px '+th.accent+',0 0 60px '+th.accent+';}',
      '.sup-x16-sub{font-size:8px;letter-spacing:6px;color:rgba(255,255,255,0.35);margin-top:4px;}',
      '.sup-x16-btn-wrap{display:flex;justify-content:center;margin-bottom:16px;}',
      '.sup-x16-btn{width:280px;padding:22px;border:2px solid rgba(255,255,255,0.2);',
        'background:rgba(255,255,255,0.03);',
        'font-family:"Share Tech Mono","Courier New",monospace;cursor:pointer;transition:all 0.2s;',
        'display:flex;flex-direction:column;align-items:center;gap:6px;}',
      '.sup-x16-btn:hover{border-color:rgba(255,255,255,0.4);}',
      '.sup-x16-btn.active{border-color:'+th.accent+';background:rgba(255,255,255,0.06);animation:sup-x16-pulse 2s infinite;}',
      '.sup-x16-icon{font-size:36px;font-weight:900;color:'+th.accent+';letter-spacing:4px;}',
      '.sup-x16-status-text{font-size:11px;letter-spacing:5px;color:rgba(255,255,255,0.5);}',
      '.sup-x16-btn.active .sup-x16-status-text{color:'+th.accent+';}',
      '.sup-god-btn{width:280px;padding:18px;border:2px solid rgba(255,30,30,0.3);',
        'background:rgba(255,30,30,0.04);color:rgba(255,100,100,0.7);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:16px;font-weight:900;',
        'letter-spacing:3px;cursor:pointer;transition:all 0.2s;}',
      '.sup-god-btn:hover{border-color:rgba(255,30,30,0.6);color:#ff4444;}',
      '.sup-god-btn.active{border-color:#ff2222;color:#ff4444;background:rgba(255,30,30,0.08);animation:sup-god-pulse 1.5s infinite;}',
      '.sup-gg-btn{width:280px;padding:14px 18px;border:2px solid rgba(87,255,221,0.25);',
        'background:rgba(87,255,221,0.035);color:rgba(210,255,250,0.62);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:14px;font-weight:900;',
        'letter-spacing:3px;cursor:pointer;transition:all 0.2s;display:flex;flex-direction:column;gap:5px;}',
      '.sup-gg-btn small{font-size:9px;letter-spacing:2px;color:rgba(255,255,255,0.42);}',
      '.sup-gg-btn:hover{border-color:'+th.accent+';color:'+th.accent+';}',
      '.sup-gg-btn.active{border-color:'+th.accent+';color:'+th.accent+';background:rgba(87,255,221,0.1);box-shadow:0 0 16px rgba(87,255,221,0.2);}',
      '.sup-gg-btn.active small{color:'+th.accent+';}',
      '.sup-x16-info{font-size:9px;letter-spacing:1px;color:rgba(255,255,255,0.3);line-height:1.9;',
        'border:1px solid rgba(255,255,255,0.08);padding:12px;margin-top:4px;}',

      // Rage grid
      '.sup-rage-grid{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:4px;}',
      '.sup-rage-btn{padding:6px 10px;border:1px solid rgba(255,255,255,0.12);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.4);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:8px;letter-spacing:1px;cursor:pointer;transition:all 0.12s;}',
      '.sup-rage-btn:hover{color:#fff;border-color:rgba(255,255,255,0.35);}',
      '.sup-rage-btn.active{color:var(--rc,#fff);border-color:var(--rc,rgba(255,255,255,0.5));background:rgba(255,255,255,0.05);}',

      // Voice grid
      '.sup-voice-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;margin-bottom:6px;}',
      '.sup-voice-btn{padding:7px 4px;border:1px solid rgba(255,255,255,0.12);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.4);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:8px;letter-spacing:1px;cursor:pointer;transition:all 0.12s;text-align:center;}',
      '.sup-voice-btn:hover{color:#fff;}',
      '.sup-voice-btn.active{color:#fff;border-color:rgba(255,255,255,0.6);background:rgba(255,255,255,0.06);}',

      // Slider rows
      '.sup-sl-wrap{margin-bottom:8px;}',
      '.sup-sl-top{display:flex;justify-content:space-between;margin-bottom:3px;}',
      '.sup-sl-lbl{font-size:9px;letter-spacing:1.5px;color:rgba(255,255,255,0.48);}',
      '.sup-sl-vval{font-size:9px;color:rgba(255,255,255,0.3);}',
      '.sup-slider{-webkit-appearance:none;appearance:none;width:100%;height:3px;',
        'background:rgba(255,255,255,0.12);border-radius:2px;outline:none;cursor:pointer;}',
      '.sup-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;',
        'width:12px;height:12px;border-radius:50%;background:#bbb;cursor:pointer;}',

      // Toggle rows
      '.sup-tog-wrap{display:flex;align-items:center;gap:10px;margin-bottom:7px;}',
      '.sup-cb{width:13px;height:13px;cursor:pointer;accent-color:'+th.accent+';}',
      '.sup-tog-lbl{font-size:9px;letter-spacing:1.5px;color:rgba(255,255,255,0.55);}',

      // Buttons
      '.sup-action-btn{padding:6px 14px;border:1px solid rgba(255,255,255,0.2);',
        'background:rgba(255,255,255,0.04);color:rgba(255,255,255,0.6);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:9px;letter-spacing:2px;',
        'cursor:pointer;margin-bottom:8px;transition:all 0.12s;}',
      '.sup-action-btn:hover{color:#fff;border-color:rgba(255,255,255,0.5);}',
      '.sup-reset-tab{color:#ff9a8a;border-color:rgba(255,92,60,.28);}',
      '.sup-reset-tab:hover{color:#fff0ec!important;border-color:#ff6a4a!important;background:rgba(255,65,35,.16);}',

      // Select
      '.sup-select{width:100%;padding:5px 8px;margin-bottom:7px;background:#060606;',
        'border:1px solid rgba(255,255,255,0.15);color:#fff;',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:10px;cursor:pointer;outline:none;}',

      // EQ
      '.sup-eq-grid{display:flex;gap:3px;padding-bottom:4px;}',
      '.sup-eq-col{display:flex;flex-direction:column;align-items:center;gap:2px;flex:1;min-width:0;}',
      '.sup-eq-val{font-size:7px;color:rgba(255,255,255,0.35);height:14px;text-align:center;}',
      '.sup-eq-slider{-webkit-appearance:slider-vertical;writing-mode:vertical-lr;direction:rtl;',
        'width:18px;height:80px;cursor:pointer;accent-color:'+th.accent+';}',
      '.sup-eq-lbl{font-size:7px;color:rgba(255,255,255,0.28);text-align:center;}',

      // Talking set
      '.sup-ts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:8px;}',
      '.sup-ts-btn{padding:8px 4px;border:1px solid rgba(255,255,255,0.15);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.45);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:9px;font-weight:900;',
        'letter-spacing:1px;cursor:pointer;line-height:1.6;transition:all 0.12s;text-align:center;}',
      '.sup-ts-btn small{display:block;font-size:7px;color:rgba(255,255,255,0.25);font-weight:400;}',
      '.sup-ts-btn:hover{border-color:rgba(255,255,255,0.4);color:rgba(255,255,255,0.85);}',
      '.sup-ts-btn.active{border-color:'+th.accent+';color:'+th.accent+';background:rgba(255,255,255,0.06);}',

      // Theme grid
      '.sup-theme-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:7px;}',
      '.sup-theme-btn{padding:12px;border:1px solid;font-family:"Share Tech Mono","Courier New",monospace;',
        'font-size:10px;font-weight:900;letter-spacing:2px;cursor:pointer;transition:opacity 0.12s;}',
      '.sup-theme-btn:hover{opacity:0.7;}',
      '.sup-theme-btn.active{box-shadow:0 0 0 2px rgba(255,255,255,0.35) inset;}',

      // MP3
      '.sup-mp3-file-wrap{margin-bottom:10px;}',
      '.sup-mp3-file-btn{display:block;width:100%;padding:10px;border:1px solid rgba(255,255,255,0.2);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.6);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:10px;letter-spacing:2px;',
        'cursor:pointer;text-align:center;margin-bottom:6px;transition:all 0.12s;}',
      '.sup-mp3-file-btn:hover{color:#fff;border-color:rgba(255,255,255,0.5);}',
      '.sup-mp3-track{font-size:9px;color:rgba(255,255,255,0.35);letter-spacing:1px;text-align:center;',
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.sup-mp3-controls{display:flex;gap:6px;margin-bottom:10px;}',
      '.sup-mp3-btn{flex:1;padding:10px 4px;border:1px solid rgba(255,255,255,0.18);',
        'background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.55);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:9px;letter-spacing:1px;',
        'cursor:pointer;transition:all 0.12s;}',
      '.sup-mp3-btn:hover{color:#fff;border-color:rgba(255,255,255,0.5);}',
      '.sup-mp3-note{font-size:8px;color:rgba(255,255,255,0.25);letter-spacing:1px;line-height:1.8;}',

      // Credits
      '.sup-credits-logo{text-align:center;font-size:24px;font-weight:900;letter-spacing:8px;color:'+th.accent+';margin:14px 0 3px;}',
      '.sup-credits-version{text-align:center;font-size:8px;letter-spacing:3px;color:rgba(255,255,255,0.28);margin-bottom:12px;}',
      '.sup-credits-sep{height:1px;background:rgba(255,255,255,0.07);margin:10px 0;}',
      '.sup-credits-authors{text-align:center;font-size:12px;letter-spacing:5px;color:#fff;margin-bottom:10px;}',
      '.sup-credits-line{font-size:9px;letter-spacing:2px;color:rgba(255,255,255,0.32);margin-bottom:4px;text-align:center;}',
      '.sup-credits-keys{text-align:center;font-size:8px;letter-spacing:1px;color:rgba(255,255,255,0.4);margin-top:10px;line-height:2;}',
      '.sup-credits-keys b{color:#fff;}',

      // FAB
      '#sup-fab{position:fixed;bottom:20px;right:18px;z-index:2147483647;',
        'display:flex;align-items:center;gap:8px;padding:0 16px;height:38px;',
        'background:#050505;border:1px solid rgba(255,255,255,0.28);cursor:pointer;',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:10px;',
        'font-weight:900;letter-spacing:3px;color:#fff;user-select:none;',
        'box-shadow:0 2px 12px rgba(0,0,0,0.8);transition:border-color 0.15s;}',
      '#sup-fab:hover{border-color:rgba(255,255,255,0.6);}',
      '#sup-fab-dot{width:7px;height:7px;border-radius:50%;background:#555;flex-shrink:0;transition:all 0.3s;}',
      '#sup-fab{width:48px;height:48px;padding:0;border-radius:50%;justify-content:center;',
        'background:radial-gradient(circle at 35% 28%,#ff4d70,#650014 48%,#090008 78%);',
        'border:2px solid #ff365f;box-shadow:0 0 16px rgba(255,25,70,.52),inset 0 0 10px rgba(255,255,255,.16);',
        'font-size:0;transition:transform .18s,box-shadow .18s;}',
      '#sup-fab:hover{transform:scale(1.08);box-shadow:0 0 26px rgba(255,25,70,.82),inset 0 0 12px rgba(255,255,255,.2);}',
      '#sup-fab-dot{width:100%;height:100%;display:flex;align-items:center;justify-content:center;',
        'background:none;border-radius:50%;font-size:22px;font-weight:900;letter-spacing:0;color:#fff;',
        'text-shadow:0 0 10px #fff;box-shadow:none;}',
      '#sup-fab-dot.on{color:#b8ffb8;text-shadow:0 0 12px #22c55e;}',

      // Reference-style animated glass surface and clearer controls
      '@keyframes sup-scan{0%{background-position:0 0}100%{background-position:0 120px}}',
      '@keyframes sup-pane-in{from{opacity:.35;transform:translateY(4px)}to{opacity:1;transform:none}}',
      '@keyframes sup-glow{0%,100%{opacity:.18;transform:translate3d(-2%,0,0)}50%{opacity:.32;transform:translate3d(2%,1%,0)}}',
      '#sup-panel{width:min(920px,calc(100vw - 24px));height:min(760px,calc(100vh - 80px));',
        'max-height:calc(100vh - 80px);',
        'border-radius:18px;background-image:linear-gradient(135deg,rgba(7,25,40,.98),rgba(2,8,17,.98));',
        'backdrop-filter:blur(18px);}',
      '#sup-panel::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;',
        'background:repeating-linear-gradient(0deg,transparent 0,transparent 6px,rgba(54,232,242,.055) 7px,transparent 8px);',
        'background-size:100% 90px;animation:sup-scan 8s linear infinite;opacity:.8;}',
      '#sup-panel::after{content:"";position:absolute;z-index:0;pointer-events:none;inset:12% -12% 32%;',
        'background:radial-gradient(ellipse at center,rgba(0,227,255,.25),transparent 62%);',
        'filter:blur(24px);animation:sup-glow 7s ease-in-out infinite;}',
      '#sup-panel>*{position:relative;z-index:1;}',
      '#sup-titlebar{padding:18px 20px 12px;background:linear-gradient(180deg,rgba(0,0,0,.42),transparent);}',
      '#sup-title{font-size:26px;letter-spacing:9px;text-shadow:0 0 18px '+th.accent+';}',
      '#sup-tabs{justify-content:center;flex-wrap:wrap;gap:3px;padding:8px 12px;background:rgba(0,0,0,.22);}',
      '.sup-tab{border:1px solid transparent;border-radius:6px;padding:9px 13px;min-height:34px;}',
      '.sup-tab.active{background:rgba(54,232,242,.11);border-color:rgba(54,232,242,.35);}',
      '#sup-pane-wrap{flex:1 1 auto;height:clamp(260px,480px,calc(100vh - 205px));',
        'min-height:0;max-height:none;overflow:hidden;}',
      '.sup-pane{height:100%;min-height:0;padding:20px 24px 26px;overflow-y:scroll;',
        'overscroll-behavior:contain;-webkit-overflow-scrolling:touch;}',
      '.sup-pane.active{animation:sup-pane-in .22s ease both;}',
      '.sup-status-row{padding:9px 12px;border:1px solid rgba(54,232,242,.18);border-radius:8px;',
        'background:rgba(0,0,0,.2);font-size:11px;text-shadow:0 0 10px currentColor;}',
      '.sup-signal-map{margin:10px 0 12px;padding:10px;border:1px solid rgba(87,255,221,.28);border-radius:10px;',
        'background:linear-gradient(135deg,rgba(3,33,48,.78),rgba(0,7,16,.72));position:relative;overflow:hidden;',
        'box-shadow:inset 0 0 22px rgba(0,226,255,.06),0 0 18px rgba(0,0,0,.22);}',
      '.sup-signal-map::before{content:"";position:absolute;left:0;right:0;top:0;height:1px;',
        'background:linear-gradient(90deg,transparent,var(--sup-accent),transparent);animation:sup-signal-pulse 2.6s ease-in-out infinite;}',
      '.sup-map-head{display:flex;justify-content:space-between;color:rgba(210,250,255,.55);font-size:8px;letter-spacing:2px;margin-bottom:9px;}',
      '#sup-map-power{color:#57ffdd;text-shadow:0 0 8px #57ffdd;}',
      '.sup-map-route{display:grid;grid-template-columns:1fr 12px 1.45fr 12px 1fr 12px 1fr 12px 1fr;align-items:center;gap:3px;}',
      '.sup-map-node{min-width:0;padding:7px 4px;border:1px solid rgba(87,255,221,.18);border-radius:6px;',
        'background:rgba(0,0,0,.26);text-align:center;animation:sup-gate-blink 3.2s ease-in-out infinite;}',
      '.sup-map-node b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#d9ffff;font-size:9px;letter-spacing:1px;}',
      '.sup-map-node span{display:block;margin-top:3px;color:rgba(180,235,240,.46);font-size:7px;letter-spacing:1px;}',
      '.sup-map-route i{font-style:normal;color:var(--sup-accent);font-size:18px;text-align:center;text-shadow:0 0 8px var(--sup-accent);}',
      '.sup-gate-state{margin:8px 0 4px;padding:7px;border:1px solid rgba(255,190,80,.25);border-radius:7px;',
        'text-align:center;font-size:8px;letter-spacing:1.4px;color:#ffbf63;background:rgba(60,28,0,.24);}',
      '.sup-gate-state.open{color:#77ffc8;border-color:rgba(87,255,221,.38);background:rgba(0,65,52,.2);}',
      '.sup-gate-state.closed{color:#ffbf63;animation:sup-gate-blink 2.4s ease-in-out infinite;}',
      '.sup-cleanup-note{text-align:center;margin:6px 4px 2px;color:rgba(210,250,255,.48);font-size:8px;line-height:1.6;letter-spacing:.5px;}',
      '.sup-vu-wrap{padding:12px 14px;border:1px solid rgba(255,255,255,.12);border-radius:10px;',
        'background:linear-gradient(90deg,rgba(0,0,0,.35),rgba(13,71,92,.22),rgba(0,0,0,.35));}',
      '.sup-vu-track{height:8px;background:rgba(0,0,0,.42);}',
      '.sup-power-btn,.sup-force-btn,.sup-action-btn,.sup-mp3-btn,.sup-x16-btn,.sup-god-btn,.sup-gg-btn{border-radius:7px;}',
      '.sup-power-btn{padding:15px;box-shadow:0 0 0 1px rgba(54,232,242,.05) inset;}',
      '.sup-gain-box{border-radius:10px;background:linear-gradient(145deg,rgba(255,255,255,.07),rgba(0,0,0,.16));',
        'border-color:rgba(54,232,242,.2);padding:16px 18px;}',
      '.sup-gain-slider{height:7px;background:linear-gradient(90deg,#19313a 0%,#2a9aa8 55%,'+th.accent+' 100%);}',
      '.sup-gain-readout{font-size:18px;color:'+th.accent+';text-shadow:0 0 10px '+th.accent+';}',
      '.sup-trim-box{margin-top:10px;}',
      '.sup-trim-box .sup-gain-slider{background:linear-gradient(90deg,#e07a7a 0%,#465866 45%,'+th.accent+' 100%);}',
      '.sup-trim-readout{font-size:14px;}',
      '.sup-safety-note{margin:12px 0 3px;text-align:center;color:rgba(255,255,255,.42);font-size:8px;letter-spacing:1.5px;}',
      '.sup-safety-note span{color:#48e39b;text-shadow:0 0 9px #48e39b;}',
      '.sup-section-label{color:rgba(122,235,246,.58);font-size:8px;letter-spacing:4px;margin-top:18px;}',
      '.sup-eq-grid{height:178px;padding:16px 10px 10px;border:1px solid rgba(54,232,242,.2);',
        'border-radius:10px;background:linear-gradient(180deg,rgba(1,20,32,.65),rgba(0,0,0,.22));',
        'gap:5px;align-items:stretch;}',
      '.sup-eq-col{gap:5px;}',
      '.sup-eq-slider{height:132px;width:20px;filter:drop-shadow(0 0 4px rgba(54,232,242,.2));}',
      '.sup-eq-val{color:rgba(255,255,255,.65);font-size:8px;}',
      '.sup-eq-lbl{color:rgba(122,235,246,.6);font-size:8px;}',
      '.sup-sl-wrap{padding:10px 12px;margin-bottom:7px;border:1px solid rgba(255,255,255,.08);',
        'border-radius:8px;background:rgba(255,255,255,.025);}',
      '.sup-slider{height:5px;background:linear-gradient(90deg,rgba(255,255,255,.12),rgba(54,232,242,.55));}',
      '.sup-slider::-webkit-slider-thumb{width:14px;height:14px;background:#d9fbff;box-shadow:0 0 8px '+th.accent+';}',
      '.sup-tog-wrap{padding:9px 12px;border:1px solid rgba(255,255,255,.08);border-radius:8px;',
        'background:rgba(255,255,255,.025);}',
      '.sup-cb{width:16px;height:16px;}',
      '.sup-x16-header{padding:18px;border:1px solid rgba(54,232,242,.18);border-radius:10px;',
        'background:radial-gradient(ellipse at center,rgba(0,227,255,.16),transparent 70%);}',
      '.sup-x16-logo{font-size:48px;}',
      '@keyframes sup-ring-spin{to{transform:rotate(360deg)}}',
      '@keyframes sup-ring-pulse{0%,100%{box-shadow:0 0 0 1px rgba(54,232,242,.2),0 0 18px rgba(54,232,242,.08)}50%{box-shadow:0 0 0 1px rgba(54,232,242,.55),0 0 28px rgba(54,232,242,.2)}}',
      '#sup-panel{isolation:isolate;}',
      '.sup-wheel{position:relative;display:flex;justify-content:center;align-items:center;gap:10px;padding:12px 16px 16px;',
        'border-top:1px solid rgba(54,232,242,.18);background:linear-gradient(180deg,rgba(0,0,0,.18),rgba(0,0,0,.5));}',
      '.sup-wheel::before{content:"";position:absolute;width:226px;height:44px;border:1px solid rgba(54,232,242,.2);',
        'border-radius:50%;animation:sup-ring-pulse 3.2s ease-in-out infinite;pointer-events:none;}',
      '.sup-wheel::after{content:"";position:absolute;width:242px;height:50px;border:1px dashed rgba(54,232,242,.18);',
        'border-radius:50%;animation:sup-ring-spin 16s linear infinite;pointer-events:none;}',
      '.sup-wheel-btn{position:relative;z-index:1;width:38px;height:38px;border-radius:50%;',
        'border:1px solid rgba(255,255,255,.18);background:rgba(3,24,35,.9);color:rgba(255,255,255,.55);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:13px;font-weight:900;cursor:pointer;',
        'transition:transform .16s ease, color .16s ease, border-color .16s ease, box-shadow .16s ease;}',
      '.sup-wheel-btn:hover{transform:translateY(-2px);color:#d9fbff;border-color:rgba(54,232,242,.7);}',
      '.sup-wheel-btn.active{color:'+th.accent+';border-color:'+th.accent+';background:rgba(54,232,242,.14);',
        'box-shadow:0 0 14px rgba(54,232,242,.32),0 0 0 3px rgba(54,232,242,.08);}',
      '.sup-wheel-btn[data-tab="Reset"]{color:#ff9a8a;border-color:rgba(255,92,60,.32);}',
      '.sup-wheel-btn[data-tab="Reset"]:hover{color:#fff0ec;border-color:#ff6a4a;background:rgba(255,65,35,.18);}',
      '.sup-theme-grid{grid-template-columns:repeat(3,1fr);}',
      '.sup-theme-btn{border-radius:8px;min-height:42px;}',
      '.sup-credits-logo{color:'+th.accent+';text-shadow:0 0 18px '+th.accent+';}',
      '.sup-credits-authors{letter-spacing:4px;color:#d9fbff;}',
      '.sup-credits-line{color:rgba(180,235,240,.5);}',
      '@keyframes sup-fiber-flow{0%{background-position:0 0,0 0}100%{background-position:160px 0,0 0}}',
      '@keyframes sup-fire-flicker{0%,100%{transform:scaleY(.96) translateX(-1%);opacity:.28}45%{transform:scaleY(1.06) translateX(2%);opacity:.5}72%{transform:scaleY(.99) translateX(-2%);opacity:.36}}',
      '@keyframes sup-edge-sweep{0%{transform:translateX(-110%)}100%{transform:translateX(110%)}}',
      '.sup-sl-wrap{position:relative;overflow:hidden;border-color:rgba(54,232,242,.2);',
        'background:linear-gradient(135deg,rgba(5,40,53,.52),rgba(0,0,0,.28));}',
      '.sup-sl-wrap::after{content:"";position:absolute;left:-35%;right:-35%;bottom:0;height:1px;',
        'background:linear-gradient(90deg,transparent,rgba(87,255,221,.9),transparent);',
        'animation:sup-edge-sweep 4.5s linear infinite;pointer-events:none;}',
      '.sup-slider{height:14px;border:1px solid rgba(87,255,221,.28);border-radius:8px;',
        'background:linear-gradient(90deg,rgba(87,255,221,.9) 0 var(--sup-pct,0%),rgba(255,255,255,.09) var(--sup-pct,0%) 100%),',
        'repeating-linear-gradient(90deg,rgba(255,255,255,.05) 0,rgba(255,255,255,.05) 2px,transparent 2px,transparent 8px);',
        'box-shadow:0 0 12px rgba(54,232,242,.2),inset 0 0 7px rgba(0,0,0,.5);}',
      '.sup-slider::-webkit-slider-runnable-track{height:12px;background:transparent;border-radius:8px;}',
      '.sup-slider::-moz-range-track{height:12px;background:transparent;border-radius:8px;}',
      '.sup-slider::-webkit-slider-thumb{width:20px;height:20px;border:2px solid #d9ffff;',
        'background:radial-gradient(circle at 38% 35%,#fff,#57ffdd 42%,#0a515b 78%);',
        'box-shadow:0 0 10px rgba(87,255,221,.9);margin-top:-4px;}',
      '.sup-slider::-moz-range-thumb{width:16px;height:16px;border:2px solid #d9ffff;',
        'background:#57ffdd;border-radius:50%;box-shadow:0 0 10px rgba(87,255,221,.9);}',
      '.sup-sl-vval{min-width:48px;text-align:right;color:#d9ffff;font-size:11px;font-weight:900;',
        'text-shadow:0 0 9px rgba(87,255,221,.55);}',
      '.sup-sl-lbl{font-size:10px;color:rgba(210,250,255,.7);}',
      '.sup-pane[data-pane="FX"]::before{content:"";position:absolute;inset:16% -18% 22%;pointer-events:none;',
        'background:radial-gradient(ellipse at 20% 70%,rgba(255,55,5,.34),transparent 28%),',
        'radial-gradient(ellipse at 80% 28%,rgba(255,170,20,.22),transparent 24%);',
        'filter:blur(20px);animation:sup-fire-flicker 2.8s ease-in-out infinite;z-index:0;}',
      '.sup-pane[data-pane="FX"]>*{position:relative;z-index:1;}',
      '.sup-section-label{position:relative;overflow:hidden;border-bottom-color:rgba(87,255,221,.25);',
        'text-shadow:0 0 8px rgba(87,255,221,.32);}',
      '.sup-section-label::after{content:"";position:absolute;left:0;bottom:-1px;width:38%;height:2px;',
        'background:linear-gradient(90deg,var(--sup-accent),transparent);box-shadow:0 0 9px var(--sup-accent);}',
      '.sup-theme-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;}',
      '.sup-theme-btn{position:relative;overflow:hidden;min-height:52px;',
        'background-image:linear-gradient(135deg,rgba(255,255,255,.08),transparent 55%);}',
      '.sup-theme-btn::after{content:"";position:absolute;inset:-50%;background:linear-gradient(110deg,transparent 42%,rgba(255,255,255,.32) 50%,transparent 58%);',
        'transform:translateX(-45%);transition:transform .45s ease;pointer-events:none;}',
      '.sup-theme-btn:hover::after{transform:translateX(45%);}',
      '.sup-effect-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;margin-top:4px;}',
      '.sup-effect-btn{position:relative;min-height:48px;padding:8px 4px;border:1px solid rgba(255,255,255,.16);',
        'border-radius:7px;background:rgba(255,255,255,.035);color:rgba(255,255,255,.58);',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:9px;font-weight:900;',
        'letter-spacing:1px;cursor:pointer;transition:all .18s;overflow:hidden;}',
      '.sup-effect-btn:hover{color:#fff;border-color:var(--sup-accent);transform:translateY(-1px);}',
      '.sup-effect-btn.active{color:#fff;border-color:var(--sup-accent);background:rgba(255,255,255,.12);',
        'box-shadow:0 0 14px rgba(87,255,221,.22),inset 0 0 12px rgba(255,255,255,.07);}',
      '.sup-effect-btn[data-effect="fire"].active{color:#ffb15c;border-color:#ff6a1a;box-shadow:0 0 18px rgba(255,70,10,.36);}',
      '.sup-effect-btn[data-effect="water"].active{color:#8eeeff;border-color:#28cfff;box-shadow:0 0 18px rgba(0,190,255,.34);}',
      '.sup-effect-btn[data-effect="lava"].active{color:#ffb04a;border-color:#ff4b16;box-shadow:0 0 18px rgba(255,75,10,.36);}',
      '.sup-effect-btn[data-effect="sakura"].active{color:#ffb6dd;border-color:#ff64b4;box-shadow:0 0 18px rgba(255,80,180,.34);}',
      '.sup-effect-btn[data-effect="rainbow"].active{color:#ff9bea;border-color:#ff75e6;box-shadow:0 0 18px rgba(255,80,220,.32);}',
      '.sup-effect-btn[data-effect="aurora"].active{color:#8dffe9;border-color:#57ffdd;box-shadow:0 0 18px rgba(50,240,205,.3);}',
      '.sup-effect-btn[data-effect="neon"].active{color:#b4a1ff;border-color:#9b7cff;box-shadow:0 0 18px rgba(140,90,255,.34);}',
      '.sup-effect-note{text-align:center;margin-top:9px;font-size:8px;letter-spacing:1px;',
        'line-height:1.7;color:rgba(210,250,255,.46);}',
      '@keyframes sup-fire-bg{0%,100%{transform:scale(1) translate3d(-1%,1%,0);opacity:.6;}',
        '35%{transform:scale(1.14) translate3d(3%,-2%,0);opacity:.88;}',
        '68%{transform:scale(.96) translate3d(-2%,2%,0);opacity:.72;}}',
      '@keyframes sup-rainbow-bg{0%{transform:rotate(0deg) scale(1.05);filter:hue-rotate(0deg);}',
        '50%{transform:rotate(180deg) scale(1.18);filter:hue-rotate(120deg);}',
        '100%{transform:rotate(360deg) scale(1.05);filter:hue-rotate(360deg);}}',
      '@keyframes sup-aurora-bg{0%,100%{transform:translate3d(-4%,2%,0) scale(1);opacity:.45;}',
        '50%{transform:translate3d(5%,-3%,0) scale(1.18);opacity:.78;}}',
      '@keyframes sup-neon-bg{0%,100%{opacity:.25;transform:scale(.96);}50%{opacity:.68;transform:scale(1.08);}}',
      '#sup-panel[data-effect="fire"]::after{inset:-12% -22% 22%;',
        'background:radial-gradient(ellipse at 18% 88%,rgba(255,45,3,.82),transparent 30%),',
        'radial-gradient(ellipse at 55% 100%,rgba(255,156,18,.56),transparent 31%),',
        'radial-gradient(ellipse at 88% 78%,rgba(255,78,4,.7),transparent 27%),',
        'linear-gradient(0deg,rgba(89,7,0,.38),transparent 56%);filter:blur(18px);',
        'animation:sup-fire-bg 2.2s ease-in-out infinite;}',
      '#sup-panel[data-effect="rainbow"]::after{inset:-38%;',
        'background:conic-gradient(from 0deg,rgba(255,50,170,.5),rgba(65,130,255,.48),rgba(51,255,194,.44),',
        'rgba(255,242,70,.42),rgba(255,50,170,.5));filter:blur(44px);',
        'animation:sup-rainbow-bg 9s linear infinite;}',
      '#sup-panel[data-effect="aurora"]::after{inset:-24% -15% 22%;',
        'background:radial-gradient(ellipse at 18% 60%,rgba(0,255,190,.55),transparent 30%),',
        'radial-gradient(ellipse at 72% 32%,rgba(77,104,255,.48),transparent 29%),',
        'radial-gradient(ellipse at 88% 80%,rgba(230,60,255,.4),transparent 25%);',
        'filter:blur(30px);animation:sup-aurora-bg 7s ease-in-out infinite;}',
      '#sup-panel[data-effect="neon"]::after{inset:8% 8% 18%;',
        'background:radial-gradient(ellipse at center,rgba(155,90,255,.7),transparent 58%);',
        'filter:blur(26px);animation:sup-neon-bg 1.8s ease-in-out infinite;}',
      '#sup-panel[data-effect^="fire-"]::after{inset:-12% -22% 22%;',
        'background:radial-gradient(ellipse at 18% 88%,rgba(255,45,3,.82),transparent 30%),',
        'radial-gradient(ellipse at 55% 100%,rgba(255,156,18,.56),transparent 31%),',
        'radial-gradient(ellipse at 88% 78%,rgba(255,78,4,.7),transparent 27%);',
        'filter:blur(18px);animation:sup-fire-bg 2.2s ease-in-out infinite;}',
      '#sup-panel[data-effect="fire-low"]::after{inset:28% -22% -12%;animation-duration:3.5s;}',
      '#sup-panel[data-effect="fire-top"]::after{inset:-22% -20% 42%;transform-origin:top;animation-duration:2.7s;}',
      '#sup-panel[data-effect="fire-wave"]::after{inset:6% -28% 28%;',
        'background:repeating-radial-gradient(ellipse at 50% 100%,rgba(255,78,5,.65) 0 8%,transparent 10% 18%);',
        'filter:blur(14px);animation:sup-fire-bg 1.8s ease-in-out infinite;}',
      '#sup-panel[data-effect="fire-embers"]::after{inset:0;',
        'background:radial-gradient(circle at 12% 78%,#ff6a00 0 2px,transparent 4px),',
        'radial-gradient(circle at 28% 42%,#ffb52e 0 1px,transparent 3px),',
        'radial-gradient(circle at 62% 84%,#ff3b00 0 2px,transparent 4px),',
        'radial-gradient(circle at 82% 34%,#ffd36a 0 1px,transparent 3px);filter:blur(2px);',
        'animation:sup-embers 4s linear infinite;}',
      '#sup-panel[data-effect="fire-blue"]::after{background:radial-gradient(ellipse at 20% 88%,rgba(0,126,255,.78),transparent 30%),',
        'radial-gradient(ellipse at 70% 100%,rgba(0,245,255,.55),transparent 35%);}',
      '#sup-panel[data-effect="fire-white"]::after{background:radial-gradient(ellipse at 30% 90%,rgba(255,255,255,.82),transparent 28%),',
        'radial-gradient(ellipse at 72% 100%,rgba(155,225,255,.54),transparent 34%);}',
      '#sup-panel[data-effect="fire-neon"]::after{background:radial-gradient(ellipse at 18% 90%,rgba(255,0,190,.7),transparent 28%),',
        'radial-gradient(ellipse at 80% 90%,rgba(142,0,255,.66),transparent 30%),',
        'radial-gradient(ellipse at 50% 100%,rgba(0,255,221,.45),transparent 30%);}',
      '@keyframes sup-water-bg{0%,100%{transform:translate3d(-2%,2%,0) scale(1);opacity:.55;}',
        '50%{transform:translate3d(3%,-3%,0) scale(1.12);opacity:.86;}}',
      '@keyframes sup-lava-bg{0%,100%{transform:translate3d(-1%,2%,0) scale(1);opacity:.6;}',
        '50%{transform:translate3d(2%,-2%,0) scale(1.1);opacity:.92;}}',
      '@keyframes sup-petal-fall{0%{background-position:0 -20px,38px -80px,80px -40px,140px -120px;transform:rotate(0deg);}',
        '100%{background-position:18px 420px,12px 360px,102px 460px,118px 390px;transform:rotate(18deg);}}',
      '#sup-panel[data-effect="water"]::after{inset:-18% -15% 8%;',
        'background:radial-gradient(ellipse at 20% 90%,rgba(0,154,255,.68),transparent 32%),',
        'radial-gradient(ellipse at 78% 74%,rgba(0,247,255,.5),transparent 30%),',
        'repeating-radial-gradient(ellipse at 50% 105%,rgba(90,220,255,.28) 0 2px,transparent 3px 24px);',
        'filter:blur(12px);animation:sup-water-bg 5s ease-in-out infinite;}',
      '#sup-panel[data-effect^="water-"]::after{inset:-10% -12% 4%;',
        'background:repeating-radial-gradient(ellipse at 50% 108%,rgba(66,213,255,.32) 0 2px,transparent 3px 26px),',
        'linear-gradient(180deg,rgba(0,80,160,.18),rgba(0,210,255,.48));filter:blur(8px);',
        'animation:sup-water-bg 4s ease-in-out infinite;}',
      '#sup-panel[data-effect="water-drops"]::after{background:radial-gradient(ellipse at 18% 10%,rgba(160,244,255,.8) 0 2px,transparent 4px),',
        'radial-gradient(ellipse at 47% 32%,rgba(80,206,255,.7) 0 3px,transparent 5px),',
        'radial-gradient(ellipse at 76% 2%,rgba(205,255,255,.8) 0 2px,transparent 4px),',
        'linear-gradient(180deg,transparent,rgba(0,188,255,.35));filter:blur(1px);animation:sup-petal-fall 3.2s linear infinite;}',
      '#sup-panel[data-effect="water-rain"]::after{background:repeating-linear-gradient(105deg,transparent 0 18px,rgba(140,235,255,.4) 19px 21px,transparent 22px 45px);',
        'filter:blur(1px);animation:sup-petal-fall 1.8s linear infinite;}',
      '#sup-panel[data-effect="water-bubbles"]::after{background:radial-gradient(circle at 18% 90%,rgba(160,245,255,.58) 0 5px,transparent 7px),',
        'radial-gradient(circle at 52% 96%,rgba(90,220,255,.5) 0 8px,transparent 10px),',
        'radial-gradient(circle at 82% 88%,rgba(205,255,255,.52) 0 4px,transparent 6px);filter:blur(1px);animation:sup-water-bg 3s ease-in-out infinite;}',
      '#sup-panel[data-effect="lava"]::after{inset:18% -15% -12%;',
        'background:radial-gradient(ellipse at 15% 100%,rgba(255,35,0,.9),transparent 28%),',
        'radial-gradient(ellipse at 50% 98%,rgba(255,177,0,.7),transparent 32%),',
        'radial-gradient(ellipse at 88% 100%,rgba(255,65,0,.84),transparent 28%),',
        'linear-gradient(0deg,rgba(92,5,0,.5),transparent 68%);filter:blur(13px);animation:sup-lava-bg 2.6s ease-in-out infinite;}',
      '#sup-panel[data-effect^="lava-"]::after{inset:8% -16% -10%;',
        'background:repeating-linear-gradient(115deg,transparent 0 30px,rgba(255,85,0,.24) 31px 34px,transparent 35px 68px),',
        'radial-gradient(ellipse at 50% 100%,rgba(255,140,0,.75),transparent 42%);filter:blur(9px);animation:sup-lava-bg 2.2s ease-in-out infinite;}',
      '#sup-panel[data-effect="lava-cracks"]::after{background:repeating-linear-gradient(135deg,transparent 0 24px,rgba(255,184,36,.75) 25px 28px,transparent 29px 58px),',
        'linear-gradient(0deg,rgba(255,36,0,.58),transparent 70%);filter:blur(2px);}',
      '#sup-panel[data-effect="lava-bubbles"]::after{background:radial-gradient(circle at 20% 88%,#ffb000 0 5px,transparent 8px),',
        'radial-gradient(circle at 44% 98%,#ff4a00 0 8px,transparent 11px),radial-gradient(circle at 78% 84%,#ffd35a 0 4px,transparent 7px);',
        'filter:blur(2px);animation:sup-lava-bg 1.8s ease-in-out infinite;}',
      '#sup-panel[data-effect="sakura"]::after{inset:-20% -10% 0;',
        'background:radial-gradient(ellipse at 50% 20%,rgba(255,98,181,.35),transparent 35%),',
        'radial-gradient(ellipse at 50% 100%,rgba(255,43,139,.22),transparent 55%);filter:blur(18px);animation:sup-aurora-bg 6s ease-in-out infinite;}',
      '#sup-panel[data-effect^="sakura-"]::after{inset:-18% -12% 0;',
        'background:radial-gradient(ellipse at 12% 2%,rgba(255,186,226,.92) 0 4px,transparent 6px),',
        'radial-gradient(ellipse at 38% 18%,rgba(255,105,184,.82) 0 5px,transparent 7px),',
        'radial-gradient(ellipse at 64% -4%,rgba(255,221,240,.9) 0 3px,transparent 6px),',
        'radial-gradient(ellipse at 88% 25%,rgba(255,110,190,.8) 0 4px,transparent 7px);',
        'filter:blur(.5px);animation:sup-petal-fall 5.5s linear infinite;}',
      '#sup-panel[data-effect="sakura-breeze"]::after{animation:sup-petal-fall 3.2s linear infinite;transform:skewX(-9deg);}',
      '#sup-panel[data-effect="sakura-storm"]::after{animation:sup-petal-fall 1.8s linear infinite;filter:blur(.2px);}',
      '#sup-panel[data-effect="sakura-bloom"]::after{filter:blur(7px);opacity:.72;animation:sup-aurora-bg 2.4s ease-in-out infinite;}',
      '#sup-panel[data-effect^="rainbow-"]::after{inset:-38%;',
        'background:conic-gradient(from 0deg,rgba(255,50,170,.5),rgba(65,130,255,.48),rgba(51,255,194,.44),',
        'rgba(255,242,70,.42),rgba(255,50,170,.5));filter:blur(44px);animation:sup-rainbow-bg 9s linear infinite;}',
      '#sup-panel[data-effect="rainbow-soft"]::after{filter:blur(70px);opacity:.5;animation-duration:15s;}',
      '#sup-panel[data-effect="rainbow-pulse"]::after{animation:sup-rainbow-bg 4s linear infinite,sup-neon-bg 2s ease-in-out infinite;}',
      '#sup-panel[data-effect^="aurora-"]::after{inset:-24% -15% 22%;',
        'background:radial-gradient(ellipse at 18% 60%,rgba(0,255,190,.55),transparent 30%),',
        'radial-gradient(ellipse at 72% 32%,rgba(77,104,255,.48),transparent 29%),',
        'radial-gradient(ellipse at 88% 80%,rgba(230,60,255,.4),transparent 25%);',
        'filter:blur(30px);animation:sup-aurora-bg 7s ease-in-out infinite;}',
      '#sup-panel[data-effect="aurora-ribbons"]::after{filter:blur(18px);transform:skewY(-8deg);animation-duration:5s;}',
      '#sup-panel[data-effect="aurora-pulse"]::after{animation:sup-aurora-bg 2.4s ease-in-out infinite;}',
      '#sup-panel[data-effect^="neon-"]::after{inset:8% 8% 18%;',
        'background:radial-gradient(ellipse at center,rgba(155,90,255,.7),transparent 58%);',
        'filter:blur(26px);animation:sup-neon-bg 1.8s ease-in-out infinite;}',
      '#sup-panel[data-effect="neon-grid"]::after{background:repeating-linear-gradient(0deg,rgba(120,110,255,.24) 0 1px,transparent 1px 15px),',
        'repeating-linear-gradient(90deg,rgba(0,255,221,.18) 0 1px,transparent 1px 15px);filter:blur(8px);}',
      '@keyframes sup-embers{0%{transform:translate3d(0,15%,0) scale(.9);opacity:.3;}',
        '50%{transform:translate3d(2%,-2%,0) scale(1.08);opacity:.8;}',
        '100%{transform:translate3d(-2%,-18%,0) scale(1.15);opacity:.16;}}',
      '.sup-section-label{font-size:11px;letter-spacing:3px;color:rgba(170,246,255,.78);',
        'text-shadow:0 0 12px rgba(87,255,221,.38);margin-top:22px;padding-bottom:7px;}',
      '.sup-sl-lbl{font-size:12px;color:rgba(225,252,255,.76);letter-spacing:1.2px;}',
      '.sup-sl-vval{font-size:12px;color:#d9ffff;text-shadow:0 0 8px rgba(87,255,221,.45);}',
      '.sup-ts-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;}',
      '.sup-ts-btn{min-height:62px;padding:13px 8px;font-size:13px;border-radius:9px;',
        'border-color:rgba(87,255,221,.22);box-shadow:inset 0 0 14px rgba(0,255,221,.035);}',
      '.sup-ts-btn small{font-size:10px;margin-top:4px;color:rgba(210,250,255,.6);}',
      '.sup-rage-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;}',
      '.sup-rage-btn{min-height:58px;padding:12px 8px;font-size:11px;border-radius:9px;',
        'background:linear-gradient(145deg,rgba(255,255,255,.06),rgba(0,0,0,.3));}',
      '.sup-voice-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;}',
      '.sup-voice-btn{min-height:48px;padding:12px 5px;font-size:11px;border-radius:8px;}',
      '.sup-big-choice{min-height:54px;padding:12px 7px;border:1px solid rgba(87,255,221,.25);',
        'border-radius:9px;background:linear-gradient(145deg,rgba(8,54,65,.6),rgba(0,0,0,.3));',
        'color:rgba(220,253,255,.72);font-family:"Share Tech Mono","Courier New",monospace;',
        'font-size:11px;font-weight:900;letter-spacing:1.5px;cursor:pointer;transition:all .16s;',
        'box-shadow:inset 0 0 12px rgba(87,255,221,.04);}',
      '.sup-big-choice:hover,.sup-big-choice.active{color:#fff;border-color:var(--sup-accent);',
        'background:linear-gradient(145deg,rgba(20,120,135,.46),rgba(0,0,0,.24));',
        'box-shadow:0 0 17px rgba(87,255,221,.22),inset 0 0 14px rgba(255,255,255,.08);}',
      '.sup-preset-grid,.sup-mode-grid,.sup-pan-grid-buttons{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-bottom:10px;}',
      '.sup-pan-field{position:relative;height:230px;margin:8px 0 10px;border:1px solid rgba(87,255,221,.28);',
        'border-radius:15px;overflow:hidden;background:radial-gradient(circle at center,rgba(55,235,221,.18),transparent 16%),',
        'linear-gradient(135deg,rgba(0,22,33,.84),rgba(4,5,26,.88));',
        'box-shadow:inset 0 0 28px rgba(87,255,221,.1),0 0 18px rgba(54,232,242,.1);}',
      '.sup-pan-grid{position:absolute;inset:14px;background:repeating-linear-gradient(0deg,transparent 0 31px,rgba(87,255,221,.14) 32px),',
        'repeating-linear-gradient(90deg,transparent 0 31px,rgba(87,255,221,.14) 32px);transform:perspective(220px) rotateX(55deg) scale(1.25);}',
      '.sup-pan-head{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);width:58px;height:58px;',
        'display:flex;align-items:center;justify-content:center;border:2px solid #d9ffff;border-radius:50%;',
        'color:#fff;font-size:23px;background:radial-gradient(circle,#57ffdd 0 10%,#092d3a 55%,transparent 57%);',
        'box-shadow:0 0 14px #57ffdd,0 0 38px rgba(87,255,221,.55);transition:left .3s,top .3s;}',
      '.sup-pan-field[data-position="left"] .sup-pan-head{left:22%;}',
      '.sup-pan-field[data-position="right"] .sup-pan-head{left:78%;}',
      '.sup-pan-field[data-position="front"] .sup-pan-head{top:26%;transform:translate(-50%,-50%) scale(1.18);}',
      '.sup-pan-field[data-position="behind"] .sup-pan-head{top:72%;transform:translate(-50%,-50%) scale(.82);opacity:.75;}',
      '.sup-pan-wave{position:absolute;top:45%;color:#57ffdd;font-size:25px;opacity:.65;text-shadow:0 0 10px #57ffdd;animation:sup-pan-wave 1.6s ease-in-out infinite;}',
      '.sup-pan-wave.left{left:9%;}.sup-pan-wave.right{right:9%;animation-delay:.8s;}',
      '.sup-pan-caption{position:absolute;bottom:11px;left:0;right:0;text-align:center;font-size:9px;letter-spacing:2px;color:rgba(210,250,255,.56);}',
      '.sup-pan-state{text-align:center;margin:7px 0 12px;font-size:13px;color:#d9ffff;letter-spacing:2px;text-shadow:0 0 10px #57ffdd;}',
      '.sup-pan-help,.sup-voice-note,.sup-repeater-help{font-size:10px;line-height:1.8;letter-spacing:1px;color:rgba(210,250,255,.56);text-align:center;margin:10px 0;}',
      '.sup-wider-meter{position:relative;height:220px;border:1px solid rgba(87,255,221,.25);border-radius:15px;',
        'overflow:hidden;background:radial-gradient(circle,rgba(87,255,221,.2),transparent 30%),rgba(0,12,23,.75);',
        'box-shadow:inset 0 0 28px rgba(87,255,221,.12);}',
      '.sup-wider-orbit{position:absolute;inset:23px;border:2px solid rgba(87,255,221,.58);border-left-color:transparent;',
        'border-right-color:transparent;border-radius:50%;transform:rotate(-22deg);animation:sup-ring-spin 5s linear infinite;}',
      '.sup-wider-orbit::before,.sup-wider-orbit::after{content:"";position:absolute;top:50%;width:16px;height:16px;',
        'border-radius:50%;background:#57ffdd;box-shadow:0 0 15px #57ffdd;transform:translateY(-50%);}',
      '.sup-wider-orbit::before{left:-8px;}.sup-wider-orbit::after{right:-8px;}',
      '.sup-wider-core{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;',
        'font-size:24px;font-weight:900;letter-spacing:5px;color:#d9ffff;text-shadow:0 0 16px #57ffdd;}',
      '.sup-wider-readout{text-align:center;margin:10px 0 12px;font-size:18px;font-weight:900;letter-spacing:3px;color:#57ffdd;',
        'text-shadow:0 0 12px #57ffdd;}',
      '.sup-digital-meter{display:flex;align-items:flex-end;gap:3px;height:46px;padding:7px 8px;margin:12px 0 3px;',
        'border:1px solid rgba(87,255,221,.22);border-radius:7px;background:rgba(0,0,0,.42);}',
      '.sup-meter-segment{flex:1;height:35%;background:#1e5960;box-shadow:0 0 5px rgba(87,255,221,.35);animation:sup-meter 1.1s ease-in-out infinite alternate;}',
      '.sup-meter-segment:nth-child(3n){height:58%;background:#36e8f2;animation-delay:-.3s;}',
      '.sup-meter-segment:nth-child(5n){height:86%;background:#ffb52e;animation-delay:-.6s;}',
      '.sup-meter-segment:nth-child(9n){height:98%;background:#ff4b65;animation-delay:-.1s;}',
      '.sup-meter-caption{text-align:center;font-size:8px;letter-spacing:2px;color:rgba(210,250,255,.42);}',
      '.sup-repeater-status{text-align:center;min-height:32px;padding:8px;border:1px solid rgba(255,165,0,.25);',
        'border-radius:8px;color:#ffb15c;background:rgba(40,16,0,.24);font-size:10px;letter-spacing:1.5px;}',
      '.sup-repeater-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:9px;}',
      '.sup-repeater-btn{min-height:48px;border:1px solid rgba(255,130,70,.32);border-radius:8px;',
        'background:linear-gradient(145deg,rgba(97,35,18,.55),rgba(0,0,0,.28));color:#ffd0a6;',
        'font-family:"Share Tech Mono","Courier New",monospace;font-size:10px;font-weight:900;letter-spacing:1px;cursor:pointer;}',
      '.sup-repeater-btn:hover{border-color:#ff9a3d;color:#fff;box-shadow:0 0 14px rgba(255,100,20,.25);}',
      '.sup-effect-detail{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-top:10px;padding:10px;',
        'border:1px solid rgba(255,255,255,.12);border-radius:9px;background:rgba(0,0,0,.2);}',
      '.sup-effect-option{min-height:38px;padding:6px 4px;border:1px solid rgba(255,255,255,.16);border-radius:6px;',
        'background:rgba(255,255,255,.04);color:rgba(235,255,255,.62);font-family:"Share Tech Mono","Courier New",monospace;',
        'font-size:8px;letter-spacing:1px;cursor:pointer;}',
      '.sup-effect-option:hover,.sup-effect-option.active{color:#fff;border-color:var(--sup-accent);background:rgba(87,255,221,.12);}',
      '.sup-effect-detail-empty{grid-column:1/-1;text-align:center;font-size:9px;letter-spacing:1px;color:rgba(210,250,255,.5);}',
      '@keyframes sup-pan-wave{0%,100%{transform:scale(.85);opacity:.4;}50%{transform:scale(1.2);opacity:1;}}',
      '@keyframes sup-meter{from{opacity:.5;transform:scaleY(.7);}to{opacity:1;transform:scaleY(1);}}',
      '.sup-wheel{flex-wrap:wrap;gap:7px;}',
      '.sup-wheel-btn{width:42px;height:42px;font-size:11px;}',
      '#sup-panel[data-effect="none"]:has(.sup-pane[data-pane="Theme"].active)::after{background:radial-gradient(ellipse at center,rgba(255,90,220,.28),transparent 62%);}',
      '#sup-panel[data-effect="none"]:has(.sup-pane[data-pane="FX"].active)::after{background:radial-gradient(ellipse at center,rgba(255,80,10,.28),transparent 62%);}',

      // Theme-wide color layer. Every shared surface, line, meter, control,
      // scrollbar and active state follows the selected theme accent.
      '#sup-panel{--sup-accent:'+th.accent+';--sup-accent-rgb:'+thRgb+';--sup-theme-border:'+th.border+';--sup-theme-glow:'+th.glow+';}',
      '#sup-panel #sup-titlebar,#sup-panel #sup-tabs{border-color:rgba(var(--sup-accent-rgb),.25);}',
      '#sup-panel .sup-deco-bar{background:linear-gradient(90deg,transparent,var(--sup-accent));}',
      '#sup-panel #sup-title-deco-r .sup-deco-bar{background:linear-gradient(90deg,var(--sup-accent),transparent);}',
      '#sup-panel .sup-status-row,#sup-panel .sup-signal-map,#sup-panel .sup-vu-wrap,#sup-panel .sup-gain-box,',
      '#sup-panel .sup-sl-wrap,#sup-panel .sup-tog-wrap,#sup-panel .sup-x16-header,#sup-panel .sup-x16-info,',
      '#sup-panel .sup-eq-grid,#sup-panel .sup-pan-field,#sup-panel .sup-wider-meter,#sup-panel .sup-digital-meter,',
      '#sup-panel .sup-repeater-status,#sup-panel .sup-effect-detail{border-color:rgba(var(--sup-accent-rgb),.3);}',
      '#sup-panel .sup-status-row{background:linear-gradient(135deg,rgba(var(--sup-accent-rgb),.12),rgba(0,0,0,.22));}',
      '#sup-panel .sup-signal-map{background:linear-gradient(135deg,rgba(var(--sup-accent-rgb),.16),rgba(0,0,0,.58));box-shadow:inset 0 0 22px rgba(var(--sup-accent-rgb),.1),0 0 18px rgba(0,0,0,.22);}',
      '#sup-panel .sup-signal-map::before{background:linear-gradient(90deg,transparent,var(--sup-accent),transparent);}',
      '#sup-panel .sup-vu-wrap{background:linear-gradient(90deg,rgba(0,0,0,.35),rgba(var(--sup-accent-rgb),.18),rgba(0,0,0,.35));}',
      '#sup-panel .sup-vu-track{background:rgba(var(--sup-accent-rgb),.12);}',
      '#sup-panel .sup-sl-wrap,#sup-panel .sup-tog-wrap{background:linear-gradient(135deg,rgba(var(--sup-accent-rgb),.12),rgba(0,0,0,.28));box-shadow:inset 0 0 16px rgba(var(--sup-accent-rgb),.08);}',
      '#sup-panel .sup-sl-wrap::after{background:linear-gradient(90deg,transparent,var(--sup-accent),transparent);}',
      '#sup-panel .sup-gain-box{background:linear-gradient(145deg,rgba(var(--sup-accent-rgb),.14),rgba(0,0,0,.24));}',
      '#sup-panel .sup-x16-header{background:radial-gradient(ellipse at center,rgba(var(--sup-accent-rgb),.2),transparent 70%);}',
      '#sup-panel .sup-eq-grid{background:linear-gradient(180deg,rgba(var(--sup-accent-rgb),.13),rgba(0,0,0,.28));}',
      '#sup-panel .sup-wheel{background:linear-gradient(180deg,rgba(var(--sup-accent-rgb),.1),rgba(0,0,0,.56));}',
      '#sup-panel .sup-map-node{border-color:rgba(var(--sup-accent-rgb),.28);}',
      '#sup-panel .sup-map-node b{color:rgba(var(--sup-accent-rgb),.95);}',
      '#sup-panel .sup-map-route i{color:var(--sup-accent);text-shadow:0 0 8px var(--sup-accent);}',
      '#sup-panel .sup-pane{scrollbar-color:rgba(var(--sup-accent-rgb),.8) rgba(var(--sup-accent-rgb),.08);}',
      '#sup-panel .sup-pane::-webkit-scrollbar-track{background:rgba(var(--sup-accent-rgb),.07);border-left-color:rgba(var(--sup-accent-rgb),.2);}',
      '#sup-panel .sup-pane::-webkit-scrollbar-thumb{background:linear-gradient(180deg,var(--sup-accent),rgba(var(--sup-accent-rgb),.38));border-color:rgba(0,0,0,.62);box-shadow:0 0 10px rgba(var(--sup-accent-rgb),.6);}',
      '#sup-panel .sup-pane::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,#fff,var(--sup-accent));}',
      '#sup-panel .sup-section-label{color:rgba(var(--sup-accent-rgb),.82);border-bottom-color:rgba(var(--sup-accent-rgb),.28);text-shadow:0 0 12px rgba(var(--sup-accent-rgb),.5);}',
      '#sup-panel .sup-section-label::after{background:linear-gradient(90deg,var(--sup-accent),transparent);box-shadow:0 0 9px var(--sup-accent);}',
      '#sup-panel .sup-tab.active,#sup-panel .sup-wheel-btn.active{color:var(--sup-accent);border-color:var(--sup-accent);}',
      '#sup-panel .sup-tab.active{background:rgba(var(--sup-accent-rgb),.12);}',
      '#sup-panel .sup-wheel{border-top-color:rgba(var(--sup-accent-rgb),.3);}',
      '#sup-panel .sup-wheel::before{border-color:rgba(var(--sup-accent-rgb),.35);}',
      '#sup-panel .sup-wheel::after{border-color:rgba(var(--sup-accent-rgb),.3);}',
      '#sup-panel .sup-wheel-btn:hover{color:var(--sup-accent);border-color:rgba(var(--sup-accent-rgb),.8);}',
      '#sup-panel .sup-action-btn,#sup-panel .sup-mp3-btn,#sup-panel .sup-voice-btn,#sup-panel .sup-ts-btn,',
      '#sup-panel .sup-rage-btn,#sup-panel .sup-big-choice,#sup-panel .sup-effect-btn,#sup-panel .sup-effect-option,',
      '#sup-panel .sup-x16-btn,#sup-panel .sup-god-btn,#sup-panel .sup-gg-btn{border-color:rgba(var(--sup-accent-rgb),.3);}',
      '#sup-panel .sup-action-btn:hover,#sup-panel .sup-mp3-btn:hover,#sup-panel .sup-voice-btn:hover,',
      '#sup-panel .sup-ts-btn:hover,#sup-panel .sup-rage-btn:hover,#sup-panel .sup-big-choice:hover,',
      '#sup-panel .sup-effect-btn:hover,#sup-panel .sup-effect-option:hover,#sup-panel .sup-x16-btn:hover,',
      '#sup-panel .sup-god-btn:hover,#sup-panel .sup-gg-btn:hover{color:var(--sup-accent);border-color:var(--sup-accent);box-shadow:0 0 16px rgba(var(--sup-accent-rgb),.22);}',
      '#sup-panel .sup-action-btn.active,#sup-panel .sup-voice-btn.active,#sup-panel .sup-ts-btn.active,',
      '#sup-panel .sup-rage-btn.active,#sup-panel .sup-big-choice.active,#sup-panel .sup-effect-btn.active,',
      '#sup-panel .sup-effect-option.active,#sup-panel .sup-x16-btn.active,#sup-panel .sup-gg-btn.active{color:var(--sup-accent);border-color:var(--sup-accent);background:rgba(var(--sup-accent-rgb),.13);}',
      '#sup-panel .sup-slider{background:linear-gradient(90deg,rgba(var(--sup-accent-rgb),.18),rgba(var(--sup-accent-rgb),.82));}',
      '#sup-panel .sup-slider::-webkit-slider-thumb{background:radial-gradient(circle at 38% 35%,#fff,var(--sup-accent) 42%,rgba(var(--sup-accent-rgb),.35) 78%);box-shadow:0 0 10px var(--sup-accent);}',
      '#sup-panel .sup-slider::-moz-range-thumb{background:var(--sup-accent);box-shadow:0 0 10px var(--sup-accent);}',
      '#sup-panel .sup-gain-slider{background:linear-gradient(90deg,rgba(var(--sup-accent-rgb),.18),rgba(var(--sup-accent-rgb),.9));}',
      '#sup-panel .sup-gain-readout,#sup-panel .sup-sl-vval,#sup-panel .sup-pan-state,#sup-panel .sup-pan-wave,',
      '#sup-panel .sup-wider-readout,#sup-panel .sup-wider-core,#sup-panel .sup-credits-logo{color:var(--sup-accent);text-shadow:0 0 12px rgba(var(--sup-accent-rgb),.7);}',
      '#sup-panel .sup-pan-field{background:radial-gradient(circle at center,rgba(var(--sup-accent-rgb),.2),transparent 16%),linear-gradient(135deg,rgba(var(--sup-accent-rgb),.12),rgba(0,0,0,.72));}',
      '#sup-panel .sup-pan-grid{background:repeating-linear-gradient(0deg,transparent 0 31px,rgba(var(--sup-accent-rgb),.2) 32px),repeating-linear-gradient(90deg,transparent 0 31px,rgba(var(--sup-accent-rgb),.2) 32px);}',
      '#sup-panel .sup-pan-head{border-color:var(--sup-accent);background:radial-gradient(circle,var(--sup-accent) 0 10%,rgba(var(--sup-accent-rgb),.2) 55%,transparent 57%);box-shadow:0 0 14px var(--sup-accent),0 0 38px rgba(var(--sup-accent-rgb),.55);}',
      '#sup-panel .sup-wider-orbit{border-color:rgba(var(--sup-accent-rgb),.7);border-left-color:transparent;border-right-color:transparent;}',
      '#sup-panel .sup-wider-orbit::before,#sup-panel .sup-wider-orbit::after{background:var(--sup-accent);box-shadow:0 0 15px var(--sup-accent);}',
      '#sup-panel .sup-meter-segment{background:rgba(var(--sup-accent-rgb),.42);box-shadow:0 0 5px rgba(var(--sup-accent-rgb),.55);}',
      '#sup-panel .sup-meter-segment:nth-child(3n){background:var(--sup-accent);}',
      '#sup-panel .sup-auto-pill{border-color:rgba(var(--sup-accent-rgb),.5);color:var(--sup-accent);background:rgba(var(--sup-accent-rgb),.1);}',
      '#sup-panel .sup-auto-pill i{background:var(--sup-accent);box-shadow:0 0 8px var(--sup-accent);}',
      '#sup-panel .sup-status-engine{color:rgba(var(--sup-accent-rgb),.66);}',
      '#sup-panel .sup-status-kicker{color:rgba(var(--sup-accent-rgb),.72);}',
      '#sup-panel .sup-status-kicker{display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;font-size:9px;letter-spacing:3px;}',
      '#sup-panel .sup-auto-pill{display:inline-flex;align-items:center;gap:5px;padding:4px 7px;border:1px solid;border-radius:999px;font-size:8px;letter-spacing:1.5px;}',
      '#sup-panel .sup-auto-pill i{width:6px;height:6px;border-radius:50%;display:inline-block;opacity:.65;}',
      '#sup-panel .sup-auto-pill.live i{opacity:1;animation:sup-signal-pulse 1.5s ease-in-out infinite;}',
      '#sup-panel .sup-status-line{display:flex;align-items:center;justify-content:space-between;gap:10px;}',
      '#sup-panel .sup-status-line #sup-status-val{font-weight:900;letter-spacing:1.5px;}',
      '#sup-panel .sup-status-engine{font-size:8px;letter-spacing:1.5px;white-space:nowrap;}',
    ].join('');
    var styleEl=D.createElement('style');
    styleEl.id='sup-styles';
    styleEl.textContent=css;
    (D.head||D.documentElement).appendChild(styleEl);
  }

  // ══════════════════════════════════════════════
  //  PANEL BUILD
  // ══════════════════════════════════════════════
  function buildUI(){
    if(D.getElementById('sup-panel'))return;
    injectStyles();

    panel=mk('div','');panel.id='sup-panel';panel.dataset.effect=S.backgroundEffect||'none';

    // Title bar
    var titlebar=mk('div','');titlebar.id='sup-titlebar';
    var tLeft=mk('div','');tLeft.id='sup-title-deco';
    tLeft.appendChild(mk('span','sup-deco-bar'));tLeft.appendChild(mk('span','sup-deco-bar'));
    var titleEl=mk('div','');titleEl.id='sup-title';titleEl.textContent='BLOOD.XD';
    var tRight=mk('div','');tRight.id='sup-title-deco-r';
    tRight.appendChild(mk('span','sup-deco-bar'));tRight.appendChild(mk('span','sup-deco-bar'));
    var winBtns=mk('div','');winBtns.id='sup-win-btns';
    var minB=mk('button','sup-win-btn','—');minB.addEventListener('click',togglePanel);
    var closeB=mk('button','sup-win-btn close','✕');closeB.addEventListener('click',togglePanel);
    winBtns.appendChild(minB);winBtns.appendChild(closeB);
    titlebar.appendChild(tLeft);titlebar.appendChild(titleEl);titlebar.appendChild(tRight);titlebar.appendChild(winBtns);
    panel.appendChild(titlebar);
    makeDraggable(titlebar,panel);

    // Tabs
    var tabsEl=mk('div','');tabsEl.id='sup-tabs';
    var TABS=['Main','X24','Pan','Wider','EQ','Voice','FX','MP3','Theme','Info'];
    TABS.forEach(function(t){
      var tab=mk('button','sup-tab',t);tab.dataset.tab=t;
      if(t==='Main')tab.classList.add('active');
      tab.addEventListener('click',function(){
        switchTab(t);
        // Re-apply theme accent on active tab
        D.querySelectorAll('.sup-tab').forEach(function(tb){
          tb.style.color=tb.classList.contains('active')?currentTheme.accent:'';
          tb.style.borderBottomColor=tb.classList.contains('active')?currentTheme.accent:'transparent';
        });
      });
      tabsEl.appendChild(tab);
    });
    var resetTab=mk('button','sup-tab sup-reset-tab','RESET ALL');
    resetTab.type='button';resetTab.title='Restore every control, theme, and effect';
    resetTab.addEventListener('click',resetAll);
    tabsEl.appendChild(resetTab);
    panel.appendChild(tabsEl);

    // Panes
    var paneWrap=mk('div','');paneWrap.id='sup-pane-wrap';
    paneWrap.appendChild(buildMainPane());
    paneWrap.appendChild(buildX16Pane());
    paneWrap.appendChild(buildPanPane());
    paneWrap.appendChild(buildWiderPane());
    paneWrap.appendChild(buildEQPane());
    paneWrap.appendChild(buildVoicePane());
    paneWrap.appendChild(buildFXPane());
    paneWrap.appendChild(buildMP3Pane());
    paneWrap.appendChild(buildThemePane());
    paneWrap.appendChild(buildCreditsPane());
    panel.appendChild(paneWrap);

    // Screenshot-style bottom wheel: the color controls stay inside Theme,
    // while the main navigation remains a compact icon dock.
    var wheel=mk('nav','sup-wheel');
    [
      ['Main','◈','MAIN'],
      ['X24','24','POWER'],
      ['Pan','◁▷','PAN'],
      ['Wider','↔','WIDER'],
      ['EQ','▥','EQ'],
      ['Voice','◉','VOICE'],
      ['FX','✦','FX'],
      ['MP3','▱','PLAYER'],
      ['Theme','◌','COLOR'],
      ['Info','i','INFO'],
      ['Reset','↺','RESET ALL']
    ].forEach(function(item){
      var wb=mk('button','sup-wheel-btn'+(item[0]==='Main'?' active':''),item[1]);
      wb.type='button';wb.dataset.tab=item[0];wb.title=item[2];wb.setAttribute('aria-label',item[2]);
      wb.addEventListener('click',function(){
        if(item[0]==='Reset')resetAll();else switchTab(item[0]);
      });
      wheel.appendChild(wb);
    });
    panel.appendChild(wheel);

    (D.body||D.documentElement).appendChild(panel);
  }

  // ── FAB ──
  function buildFAB(){
    if(D.getElementById('sup-fab'))return;
    var fab=mk('div','');fab.id='sup-fab';
    fab.innerHTML='<span id="sup-fab-dot">T</span>';
    fab.title='Open BLOOD.XD';
    fab.addEventListener('click',togglePanel);
    (D.body||D.documentElement).appendChild(fab);
  }
  function refreshFAB(){
    var dot=D.getElementById('sup-fab-dot');
    if(dot)dot.classList.toggle('on',S.active);
  }

  // ── F2 ──
  D.addEventListener('keydown',function(e){if(e.key==='F2'){e.preventDefault();togglePanel();}},true);

  // ── INIT ──
  function init(){
    // Nextor Cord supplies its own right-side control panel. Keep this
    // extension's DSP and WebRTC hook, but do not create a second popup/FAB.
    S.active=true;
    setStatus('READY — JOIN A VOICE CHANNEL','#22c55e');
    setTimeout(function(){activate();},350);
  }

  // Public bridge consumed by the bundled Nextor Cord HTML panel (srcdoc).
  // All values are validated and bounded before touching the live Web Audio graph.
  function applyAllFromBridge(){
    if(!chainBuilt)return;
    applyGain();applyOutput();applyRage();applyEQ();applyVoice();applySpatial();
    applyReverb();applyDelay();applyChorus();applyFlanger();applyDistortion();
    applyHighpass();applyClarity();applyNoiseGate();
    if(limiterNode)limiterNode.threshold.value=clamp(S.limiterCeiling,-12,-1);
  }
  window.NextorBloodXD={
    getState:function(){var o={};Object.keys(S).forEach(function(k){o[k]=Array.isArray(S[k])?S[k].slice():S[k];});o.active=!!(S.active&&chainBuilt);return o;},
    setX24:function(on){S.x16Active=!!on;applyGain();},
    setTalkingSet:function(name){if(TALKING_SETS[name]){S.talkingSet=name;applyGain();}},
    setConfig:function(cfg){
      if(!cfg||typeof cfg!=='object')return;
      if(Object.prototype.hasOwnProperty.call(cfg,'bypass')){
        if(cfg.bypass){restoreAllConns();S.bridgeBypass=true;}
        else if(S.bridgeBypass){S.bridgeBypass=false;activate(true);}
      }
      if('gainDb'in cfg)S.gainDb=clamp(Number(cfg.gainDb)||0,-20,12);
      if('rageLevel'in cfg)S.rageLevel=clamp(Math.round(Number(cfg.rageLevel)||0),0,4);
      if('outputTrimDb'in cfg)S.outputTrimDb=clamp(Number(cfg.outputTrimDb)||0,-18,0);
      if('voiceMode'in cfg&&VOICE_PROFILES[cfg.voiceMode])S.voiceMode=cfg.voiceMode;
      if('pitchShift'in cfg)S.pitchShift=clamp(Number(cfg.pitchShift)||0,-12,12);
      if('eqGains'in cfg&&Array.isArray(cfg.eqGains))S.eqGains=Array.from({length:15},function(_,i){return clamp(Number(cfg.eqGains[i])||0,-12,12);});
      ['reverb','delay','chorusAmount','flangerAmount','distortion','saturation','bitcrush','clarityMix'].forEach(function(k){if(k in cfg)S[k]=clamp(Number(cfg[k])||0,0,1);});
      if('delayTime'in cfg)S.delayTime=clamp(Number(cfg.delayTime)||0,0,2);
      if('noiseGate'in cfg)S.noiseGate=!!cfg.noiseGate;
      if('vocalClarity'in cfg)S.vocalClarity=!!cfg.vocalClarity;
      if('highpass'in cfg)S.highpass=!!cfg.highpass;
      if('gateThreshold'in cfg)S.gateThreshold=clamp(Number(cfg.gateThreshold)||0.02,0.002,0.2);
      if('compThreshold'in cfg)S.compThreshold=clamp(Number(cfg.compThreshold)||-18,-40,-6);
      if('compRatio'in cfg)S.compRatio=clamp(Number(cfg.compRatio)||4,1,12);
      if('limiterCeiling'in cfg)S.limiterCeiling=clamp(Number(cfg.limiterCeiling)||-6,-12,-1);
      if('godMode'in cfg)S.godMode=!!cfg.godMode;
      if('spatial'in cfg&&['left','right','center','behind'].indexOf(cfg.spatial)>=0)S.spatial=cfg.spatial;
      if('widerAmount'in cfg)S.widerAmount=clamp(Number(cfg.widerAmount)||0,0,100);
      if('haaswider'in cfg)S.haaswider=!!cfg.haaswider;
      if(S.noiseGate)startNoiseGate();else stopNoiseGate();
      applyAllFromBridge();
    },
    panic:function(){
      S.gainDb=0;S.outputTrimDb=-6;S.x16Active=false;S.godMode=false;S.rageLevel=0;S.compThreshold=-18;S.compRatio=4;S.limiterCeiling=-6;
      S.talkingSet='normal';S.voiceMode='normal';S.pitchShift=0;S.eqGains=Array(15).fill(0);
      S.reverb=0;S.delay=0;S.chorusAmount=0;S.flangerAmount=0;S.distortion=0;S.saturation=0;S.bitcrush=0;
      S.noiseGate=false;S.vocalClarity=false;S.highpass=true;stopNoiseGate();if(S.bridgeBypass){S.bridgeBypass=false;activate(true);}applyAllFromBridge();
    },
    getMeters:function(){
      if(!analyserNode||!chainBuilt)return {rms:0,db:-120,active:false};
      var b=new Uint8Array(analyserNode.fftSize);analyserNode.getByteTimeDomainData(b);var sum=0;
      for(var i=0;i<b.length;i++){var v=(b[i]-128)/128;sum+=v*v;}
      var rms=Math.sqrt(sum/b.length);return {rms:rms,db:rms>0?20*Math.log10(rms):-120,active:true};
    }
  };

  if(D.readyState==='loading'){D.addEventListener('DOMContentLoaded',function(){setTimeout(init,500);});}
  else{setTimeout(init,500);}

  console.log('[BLOOD.XD v4.6.0] Clean Room / Voice FX Hook — created by Stam God Tony — F2 to toggle');
})();
