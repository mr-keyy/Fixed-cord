(() => {
  'use strict';
  const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
  try { Object.defineProperty(Navigator.prototype, 'userAgent', { configurable: true, get: () => UA }); } catch (_) {}
  try { Object.defineProperty(Navigator.prototype, 'platform', { configurable: true, get: () => 'Win32' }); } catch (_) {}
  try { Object.defineProperty(Navigator.prototype, 'maxTouchPoints', { configurable: true, get: () => 0 }); } catch (_) {}
  try {
    const brands = [{brand:'Chromium',version:'130'},{brand:'Google Chrome',version:'130'},{brand:'Not_A Brand',version:'99'}];
    const uaData = Object.freeze({brands, mobile:false, platform:'Windows', getHighEntropyValues: async (hints) => {
      const all = {brands, mobile:false, platform:'Windows', platformVersion:'10.0.0', architecture:'x86', bitness:'64', model:'', uaFullVersion:'130.0.0.0', fullVersionList:brands};
      const out={}; for (const h of hints || []) if (h in all) out[h]=all[h]; return out;
    }, toJSON:()=>({brands,mobile:false,platform:'Windows'})});
    Object.defineProperty(Navigator.prototype,'userAgentData',{configurable:true,get:()=>uaData});
  } catch (_) {}
  try {
    const original = window.matchMedia.bind(window);
    window.matchMedia = (q) => {
      if (/\(\s*pointer\s*:\s*coarse\s*\)/i.test(q) || /\(\s*hover\s*:\s*none\s*\)/i.test(q)) return {matches:false, media:q, onchange:null, addListener(){}, removeListener(){}, addEventListener(){}, removeEventListener(){}, dispatchEvent(){return false}};
      return original(q);
    };
  } catch (_) {}
  const addViewport = () => {
    try {
      let m=document.querySelector('meta[name="viewport"]');
      if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m);}
      m.content='width=1280, initial-scale=0.3, user-scalable=yes';
    } catch (_) {}
  };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',addViewport,{once:true}); else addViewport();
  try { console.log('[NEXTOR] desktop compatibility shim installed'); } catch (_) {}
})();
