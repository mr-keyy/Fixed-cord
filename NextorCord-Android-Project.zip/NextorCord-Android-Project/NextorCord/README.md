# Nextor Cord – enhanced prototype

This project is an Android WebView Discord shell with a desktop Chrome user-agent, desktop viewport shim, persistent cookies, file chooser, WebView microphone permission bridge, and a JavaScript audio-control overlay.

## Build
- Android Studio, JDK 17, Android SDK 35, Gradle 8.9.
- Open this folder as a project and build `app` > `assembleDebug`.
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
- For a signed release, configure a private keystore in Android Studio's Generate Signed Bundle/APK wizard. Never commit the keystore or passwords.

## Implemented audio features
The WebAudio prototype includes mic getUserMedia interception, 80 Hz high-pass, adjustable gain with 50 ms ramp, noise gate, 10-band peaking EQ, compressor, final dynamics-compressor limiter, waveshaper saturation, echo feedback, output gain, meters and six presets. A floating N button opens the control panel.

## Limitations (important)
This is not a complete implementation of every mockup feature. Pitch/formant shifting, robot/alien morph, spectral noise subtraction, de-hum/de-hiss, convolution/shimmer reverb, multiband compression, true-peak/LUFS-compliant metering, native 8D/binaural processing, and guaranteed Discord WebRTC compatibility are not implemented. The meter values are sample/RMS estimates, not certified LUFS or true peak. WebView desktop spoofing cannot guarantee Discord will support voice on every Android/WebView version. The engine falls back to the original microphone if processing fails. Keep the app foregrounded during voice sessions; Android may restrict microphone foreground services in the background.

The interface deliberately labels unavailable functions instead of pretending they work. Test in a private voice channel at low gain first. Excessive gain causes clipping and distortion; it cannot create unlimited clean loudness.
