# Nextor Cord
Desktop Discord WebView wrapper with an experimental Web Audio mic processor.

Build with JDK 17, Android SDK 35, Gradle 8.9:
`gradle --no-daemon assembleDebug`

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

Important: Discord desktop voice in Android WebView is unsupported and may not work on every device. Mic interception is best-effort and experimental; Discord may bypass it or change its capture path. Extreme gain causes distortion and can damage hearing/speakers. This is a debug APK build setup, not a private-key-signed release.


## Startup animation
The uploaded `nextor-cord-loader-updated.html` is included as
`app/src/main/assets/startup.html`. The app displays it locally on launch.
Its progress animation advances from 0% to 100% over 5,000 ms using
`requestAnimationFrame`; at completion it calls a temporary Android bridge.
The bridge is removed before Discord is loaded. Microphone permission is
requested after the animation if it has not already been granted.
