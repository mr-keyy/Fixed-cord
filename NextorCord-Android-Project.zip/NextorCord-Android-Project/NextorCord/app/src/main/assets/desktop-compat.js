(() => {
 const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
 try { Object.defineProperty(Navigator.prototype,'userAgent',{get:()=>ua,configurable:true}); } catch(e){}
 try { Object.defineProperty(Navigator.prototype,'platform',{get:()=>'Win32',configurable:true}); } catch(e){}
 try { Object.defineProperty(Navigator.prototype,'maxTouchPoints',{get:()=>0,configurable:true}); } catch(e){}
 try { const old=window.matchMedia.bind(window); window.matchMedia=q=>((q.includes('pointer: coarse')||q.includes('hover: none'))?({matches:false,media:q, onchange:null,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){},dispatchEvent(){return false}}):old(q)); } catch(e){}
 const addViewport=()=>{if(!document.head)return;let m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m)}m.content='width=1280, initial-scale=0.3, minimum-scale=0.2, maximum-scale=3, user-scalable=yes';};
 new MutationObserver(addViewport).observe(document.documentElement,{childList:true,subtree:true}); addViewport();
})();