/* Experimental mic Web Audio chain. Interception is best-effort, not guaranteed for Discord. */
(() => {
 if(window.__NEXTOR__)return; window.__NEXTOR__=true;
 const log=(...x)=>console.log("[NEXTOR]",...x), s={gain:1,gate:-50,comp:4,eq:0};
 const original=navigator.mediaDevices?.getUserMedia?.bind(navigator.mediaDevices);
 if(!original){log("getUserMedia unavailable");return;}
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number.isFinite(v)?v:a));
 function process(raw){
  try{
   const c=new (AudioContext||webkitAudioContext)({sampleRate:48000}), src=c.createMediaStreamSource(raw);
   const hp=c.createBiquadFilter();hp.type="highpass";hp.frequency.value=80;
   const gate=c.createDynamicsCompressor();gate.threshold.value=s.gate;gate.ratio.value=8;
   const eq=c.createBiquadFilter();eq.type="peaking";eq.frequency.value=3000;eq.Q.value=1;eq.gain.value=s.eq;
   const comp=c.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=s.comp;
   const gain=c.createGain();gain.gain.value=s.gain;
   const limit=c.createDynamicsCompressor();limit.threshold.value=-1;limit.knee.value=0;limit.ratio.value=20;limit.attack.value=.001;
   const dest=c.createMediaStreamDestination();src.connect(hp).connect(gate).connect(eq).connect(comp).connect(gain).connect(limit).connect(dest);
   window.__NEXTOR_SET__=(k,v)=>{if(!(k in s))return;s[k]=v;const t=c.currentTime;
    if(k==="gain"){gain.gain.cancelScheduledValues(t);gain.gain.setTargetAtTime(clamp(v,0,8),t,.05);}
    if(k==="gate")gate.threshold.setTargetAtTime(clamp(v,-90,0),t,.03);
    if(k==="comp")comp.ratio.setTargetAtTime(clamp(v,1,20),t,.03);
    if(k==="eq")eq.gain.setTargetAtTime(clamp(v,-20,20),t,.03);
   };
   return dest.stream;
  }catch(e){log("processor failed; using raw stream",e);return raw;}
 }
 navigator.mediaDevices.getUserMedia=async function(constraints){
  if(!constraints?.audio)return original(constraints);
  const raw=await original({...constraints,audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false,sampleRate:48000}});
  return process(raw)||raw;
 };
 log("experimental processor installed");
})();
