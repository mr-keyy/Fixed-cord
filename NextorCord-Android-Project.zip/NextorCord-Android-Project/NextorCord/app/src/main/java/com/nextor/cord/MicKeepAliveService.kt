package com.nextor.cord

import android.app.*
import android.content.Intent
import android.os.*

class MicKeepAliveService : Service() {
    private var lock: PowerManager.WakeLock? = null
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("nextor", "Nextor voice", NotificationManager.IMPORTANCE_LOW))
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "nextor") else Notification.Builder(this)
        startForeground(1, n.setContentTitle("Nextor Cord").setContentText("Voice session helper").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        lock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NextorCord:Voice")
        lock?.acquire(10 * 60 * 1000L)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onDestroy() { lock?.let { if (it.isHeld) it.release() }; super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
