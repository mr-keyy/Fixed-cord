package com.nextor.cord

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.content.ActivityNotFoundException
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var preampDb = 24
    private var engineReady = false
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val desktopUrl = "https://discord.com/app"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestRuntimePermissions()

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 9, 12))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            addJavascriptInterface(NextorBridge(), "NextorNative")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val audio = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray()
                        if (audio.isNotEmpty() && hasAudioPermission()) request.grant(audio) else request.deny()
                    }
                }
                override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = callback
                    return try {
                        val intent = params?.createIntent() ?: return false
                        startActivityForResult(intent, 72)
                        true
                    } catch (_: ActivityNotFoundException) {
                        uploadCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    val scheme = request.url.scheme?.lowercase() ?: return true
                    if (scheme in listOf("intent", "market", "discord")) return true
                    if (scheme != "https" && scheme != "http") return true
                    val host = request.url.host?.lowercase() ?: return true
                    val discordHost = host == "discord.com" || host.endsWith(".discord.com") || host == "discordapp.com" || host.endsWith(".discordapp.com")
                    if (!discordHost) return true
                    if (url.contains("/download", true) || url.contains("/mobile", true) || url.contains("/app-download", true)) {
                        view.post { view.loadUrl(desktopUrl) }
                        return true
                    }
                    return false
                }
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (url.contains("discord.com/download", true) || url.contains("get-the-app", true)) {
                        view.loadUrl(desktopUrl)
                        return
                    }
                    injectEngine()
                    engineReady = true
                    CookieManager.getInstance().flush()
                }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val shim = assets.open("desktop-compat.js").bufferedReader().use { it.readText() }
            WebViewCompat.addDocumentStartJavaScript(web, shim, setOf("https://discord.com", "https://*.discord.com"))
        }
        setContentView(web)
        web.loadUrl(desktopUrl)
        startMicService()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                // The user chooses whether to exempt the app; no automatic settings mutation.
                Toast.makeText(this, "For longer background sessions, review battery optimization settings.", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 72) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(permissions.toTypedArray(), 41)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && hasAudioPermission()) startMicService()
    }

    private fun hasAudioPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startMicService() {
        if (!hasAudioPermission()) return
        try {
            val intent = Intent(this, MicKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            android.util.Log.w("NEXTOR", "Foreground microphone service could not start: ${e.message}")
        }
    }

    private fun injectEngine() {
        val js = assets.open("nextor-engine.js").bufferedReader().use { it.readText() }
        web.evaluateJavascript(js, null)
    }

    inner class NextorBridge {
        @android.webkit.JavascriptInterface
        fun log(message: String) { android.util.Log.d("NEXTOR", message.take(1500)) }
        @android.webkit.JavascriptInterface
        fun openControls() { runOnUiThread { showControls() } }
        @android.webkit.JavascriptInterface
        fun setPreamp(value: Int) { preampDb = value.coerceIn(0, 72) }
    }

    private fun showControls() {
        val dialog = Dialog(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(18, 18, 18))
        }
        val heading = TextView(this).apply {
            text = "NEXTOR CONTROL DECK"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
        }
        layout.addView(heading)
        val valueText = TextView(this).apply {
            text = "PREAMP  $preampDb dB"
            textSize = 15f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 18, 0, 8)
        }
        layout.addView(valueText)
        val slider = SeekBar(this).apply {
            max = 72
            progress = preampDb
        }
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    preampDb = progress
                    valueText.text = "PREAMP  $preampDb dB"
                    web.evaluateJavascript("window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        layout.addView(slider)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun action(label: String, js: String) {
            val b = Button(this).apply { text = label; setOnClickListener { web.evaluateJavascript(js, null) } }
            row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        action("PANIC", "window.NextorEngine && window.NextorEngine.panic()")
        action("BYPASS", "window.NextorEngine && window.NextorEngine.setConfig({bypass:true})")
        action("LIVE", "window.NextorEngine && window.NextorEngine.setConfig({bypass:false})")
        layout.addView(row)
        val note = TextView(this).apply {
            text = "Audio processing starts when Discord requests microphone access. Keep this app foregrounded for reliable voice sessions."
            setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; setPadding(0, 14, 0, 0)
        }
        layout.addView(note)
        dialog.setContentView(layout)
        dialog.show()
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.window?.setGravity(Gravity.BOTTOM)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) {
            web.goBack()
        } else {
            android.app.AlertDialog.Builder(this)
                .setTitle("Exit Nextor Cord?")
                .setMessage("Your Discord voice session will close.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Exit") { _, _ -> finish() }
                .show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            preampDb = (preampDb + if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 2 else -2).coerceIn(0, 72)
            if (::web.isInitialized) web.evaluateJavascript(
                "window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null
            )
            Toast.makeText(this, "Nextor preamp: $preampDb dB", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onPause() {
        if (::web.isInitialized) web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.stopLoading(); web.destroy() }
        super.onDestroy()
    }
}
