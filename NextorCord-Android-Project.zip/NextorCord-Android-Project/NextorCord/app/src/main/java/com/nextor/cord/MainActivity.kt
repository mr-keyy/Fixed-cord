package com.nextor.cord

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var splashWeb: WebView? = null
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private var preampDb = 24
    private var gain = 100
    private var bypass = false
    private var panicActive = false
    private var engineReady = false
    private var appShown = false
    private val handler = Handler(Looper.getMainLooper())
    private val desktopUrl = "https://discord.com/app"
    private val splashAsset = "file:///android_asset/nextor-cord-loader-updated.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestRuntimePermissions()

        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(9, 9, 12)) }
        web = createDiscordWebView()
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        // Always-visible Nextor control button; controls no longer depend on a hidden JS callback.
        val controlButton = TextView(this).apply {
            text = "N"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(225, 18, 52))
                setStroke(dp(2), Color.rgb(255, 110, 130))
            }
            elevation = dp(8).toFloat()
            contentDescription = "Open Nextor Cord audio controls"
            setOnClickListener { showControls() }
        }
        val buttonParams = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END or Gravity.BOTTOM).apply {
            setMargins(0, 0, dp(18), dp(24))
        }
        root.addView(controlButton, buttonParams)
        setContentView(root)
        showStartupAnimation()
        startMicService()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createDiscordWebView(): WebView {
        return WebView(this).apply {
            setBackgroundColor(Color.rgb(9, 9, 12))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            addJavascriptInterface(NextorBridge(), "NextorNative")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val audio = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray()
                        if (audio.isNotEmpty() && hasAudioPermission()) request.grant(audio) else request.deny()
                    }
                }

                override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = callback
                    return try {
                        val intent = params?.createIntent() ?: return false
                        startActivityForResult(intent, 72)
                        true
                    } catch (_: ActivityNotFoundException) {
                        uploadCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    val scheme = request.url.scheme?.lowercase() ?: return true
                    if (scheme in listOf("intent", "market", "discord")) return true
                    if (scheme != "https" && scheme != "http") return true
                    val host = request.url.host?.lowercase() ?: return true
                    val isDiscord = host == "discord.com" || host.endsWith(".discord.com") || host == "discordapp.com" || host.endsWith(".discordapp.com")
                    if (!isDiscord) return true
                    if (url.contains("/download", true) || url.contains("/mobile", true) || url.contains("/app-download", true)) {
                        view.post { view.loadUrl(desktopUrl) }
                        return true
                    }
                    return false
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (url.contains("discord.com/download", true) || url.contains("get-the-app", true)) {
                        view.loadUrl(desktopUrl)
                        return
                    }
                    injectEngine()
                    CookieManager.getInstance().flush()
                }

                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    android.util.Log.e("NEXTOR", "WebView renderer exited; crashed=${detail.didCrash()}")
                    try {
                        (view.parent as? ViewGroup)?.removeView(view)
                        view.destroy()
                    } catch (_: Exception) { }
                    if (!isFinishing) Toast.makeText(this@MainActivity, "Discord page stopped. Please restart Nextor Cord.", Toast.LENGTH_LONG).show()
                    return true
                }
            }
        }
    }

    private fun showStartupAnimation() {
        val splash = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 2, 2))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        splashWeb = splash
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        var finished = false
        fun revealApp() {
            if (finished || isFinishing || isDestroyed) return
            finished = true
            appShown = true
            try {
                root.removeView(splash)
                splash.stopLoading()
                splash.destroy()
            } catch (_: Exception) { }
            splashWeb = null
            web.visibility = View.VISIBLE
            web.loadUrl(desktopUrl)
        }
        splash.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // The supplied HTML animates its own progress from 0 to 100 over exactly 5 seconds.
                handler.postDelayed({ revealApp() }, 5000)
            }
        }
        // Fallback in case the local HTML asset was not copied into app/src/main/assets.
        handler.postDelayed({ revealApp() }, 7500)
        try {
            splash.loadUrl(splashAsset)
        } catch (e: Exception) {
            android.util.Log.e("NEXTOR", "Could not load startup animation", e)
            handler.postDelayed({ revealApp() }, 5000)
        }
    }

    private fun injectEngine() {
        try {
            val js = assets.open("nextor-engine.js").bufferedReader().use { it.readText() }
            web.evaluateJavascript(js, null)
            engineReady = true
            applyAudioConfig()
        } catch (e: Exception) {
            engineReady = false
            android.util.Log.e("NEXTOR", "nextor-engine.js missing or invalid", e)
            runOnUiThread { Toast.makeText(this, "Audio engine asset missing: add nextor-engine.js to app/src/main/assets", Toast.LENGTH_LONG).show() }
        }
    }

    private fun applyAudioConfig() {
        if (!::web.isInitialized) return
        val js = "window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb,gainDb:$gain,bypass:$bypass})"
        web.evaluateJavascript(js, null)
    }

    inner class NextorBridge {
        @android.webkit.JavascriptInterface
        fun log(message: String) { android.util.Log.d("NEXTOR", message.take(1500)) }
        @android.webkit.JavascriptInterface
        fun openControls() { runOnUiThread { showControls() } }
        @android.webkit.JavascriptInterface
        fun setPreamp(value: Int) { preampDb = value.coerceIn(0, 72) }
    }

    private fun showControls() {
        val dialog = Dialog(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = GradientDrawable().apply {
                setColor(Color.rgb(17, 17, 22))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(95, 35, 48))
            }
        }
        val title = TextView(this).apply {
            text = "NEXTOR CORD  •  CONTROL DECK"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        panel.addView(title)
        panel.addView(makeSlider("MIC GAIN", gain, 400, " dB / level") { value ->
            gain = value
            applyAudioConfig()
        })
        panel.addView(makeSlider("PREAMP", preampDb, 72, " dB") { value ->
            preampDb = value
            applyAudioConfig()
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        actions.addView(actionButton("PANIC", Color.rgb(190, 20, 40)) {
            panicActive = true
            web.evaluateJavascript("window.NextorEngine && window.NextorEngine.panic()", null)
            Toast.makeText(this, "Panic activated", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        actions.addView(actionButton(if (bypass) "BYPASS: ON" else "BYPASS", Color.rgb(75, 75, 85)) {
            bypass = !bypass
            applyAudioConfig()
            Toast.makeText(this, if (bypass) "Audio processing bypassed" else "Audio processing live", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        actions.addView(actionButton("LIVE", Color.rgb(20, 145, 85)) {
            bypass = false
            panicActive = false
            applyAudioConfig()
            Toast.makeText(this, "Live mode", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        panel.addView(actions)

        val info = TextView(this).apply {
            text = if (engineReady) "Audio engine loaded. Changes apply when the engine is active." else "Discord is open, but the audio engine has not loaded. Check nextor-engine.js in app/src/main/assets."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, 0)
        }
        panel.addView(info)
        dialog.setContentView(panel)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(28)), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.window?.let { window ->
            window.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            val params = window.attributes
            params.y = dp(14)
            window.attributes = params
        }
    }

    private fun makeSlider(label: String, initial: Int, maxValue: Int, suffix: String, onChange: (Int) -> Unit): View {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, 0) }
        val value = TextView(this).apply { text = "$label  $initial$suffix"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val seek = SeekBar(this).apply { max = maxValue; progress = initial; isEnabled = true }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { value.text = "$label  $progress$suffix"; onChange(progress) }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        block.addView(value)
        block.addView(seek)
        return block
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
        setOnClickListener { action() }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 72) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        try { requestPermissions(permissions.toTypedArray(), 41) }
        catch (e: Exception) { android.util.Log.e("NEXTOR", "Permission request failed", e) }
    }

    private fun hasAudioPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && hasAudioPermission()) startMicService()
    }

    private fun startMicService() {
        if (!hasAudioPermission()) return
        try {
            val intent = Intent(this, MicKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) { android.util.Log.w("NEXTOR", "Mic service could not start: ${e.message}") }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            preampDb = (preampDb + if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 2 else -2).coerceIn(0, 72)
            applyAudioConfig()
            Toast.makeText(this, "Nextor preamp: $preampDb dB", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }
    override fun onPause() { if (::web.isInitialized) web.onPause(); super.onPause() }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (splashWeb != null && !appShown) return
        if (::web.isInitialized && web.canGoBack()) web.goBack()
        else android.app.AlertDialog.Builder(this).setTitle("Exit Nextor Cord?")
            .setMessage("Your Discord voice session will close.")
            .setNegativeButton("Cancel", null).setPositiveButton("Exit") { _, _ -> finish() }.show()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { splashWeb?.stopLoading(); splashWeb?.destroy() } catch (_: Exception) { }
        if (::web.isInitialized) try {
            web.stopLoading()
            web.loadUrl("about:blank")
            web.removeJavascriptInterface("NextorNative")
            web.webChromeClient = null
            web.webViewClient = WebViewClient()
            web.destroy()
        } catch (e: Exception) { android.util.Log.w("NEXTOR", "WebView cleanup failed", e) }
        super.onDestroy()
    }
}
